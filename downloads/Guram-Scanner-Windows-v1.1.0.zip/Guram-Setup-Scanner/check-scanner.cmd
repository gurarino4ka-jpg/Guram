@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
if errorlevel 1 goto missing
where node >nul 2>nul
if errorlevel 1 goto node_missing
node -e "process.exit(Number(process.versions.node.split('.')[0]) >= 24 ? 0 : 1)"
if errorlevel 1 goto node_old
if not exist "scanner\cli.mjs" goto missing
if not exist "scanner.config.json" goto missing
set "NODE_USE_ENV_PROXY=1"
echo Проверка соединения и один полный цикл по всем доступным криптоинструментам.
echo Полный цикл может занять несколько минут; дождитесь завершения.
echo Отсутствие сетапа не является ошибкой подключения.
echo.
node "scanner\cli.mjs" --once
set "scanner_exit=%errorlevel%"
echo.
echo Программа завершена. Код: %scanner_exit%
goto finish
:node_missing
echo Node.js не найден. Установите Node.js 24 LTS с https://nodejs.org/
set "scanner_exit=1"
goto finish
:node_old
echo Нужен Node.js 24 или новее. Установите Node.js 24 LTS с https://nodejs.org/
set "scanner_exit=1"
goto finish
:missing
echo Полностью распакуйте ZIP в обычную папку и повторите запуск.
set "scanner_exit=1"
:finish
echo.
pause
endlocal & exit /b %scanner_exit%
