$ErrorActionPreference = 'Stop'
$scannerTask = Get-ScheduledTask -TaskName 'GuramSetupScanner' -ErrorAction SilentlyContinue
if ($null -ne $scannerTask) {
    Unregister-ScheduledTask -TaskName 'GuramSetupScanner' -Confirm:$false
    Write-Host 'Autostart removed: GuramSetupScanner.'
} else {
    Write-Host 'Autostart task is not installed.'
}
