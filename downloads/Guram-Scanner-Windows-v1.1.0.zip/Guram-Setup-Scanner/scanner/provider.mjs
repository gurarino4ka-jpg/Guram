/** Public chart GETs only. No login, account endpoints, keys or trading API. */
import {createHash} from 'node:crypto';
import {isSupportedSymbol} from './symbols.mjs';
const ORIGIN='https://app.bookflow.sh';
const PERIODS=Object.freeze({'5':300000,'15':900000,'30':1800000,'60':3600000,'1D':86400000});
const CATALOG_SOURCE=ORIGIN+'/api/v2/markets';
// Slow streams first; the M5 snapshot is always the final HTTP observation.
const HIGHER_TIMEFRAMES=['60','1D','30','15'];
const DEFAULTS=Object.freeze({symbols:'all_crypto',timeoutMs:12000,countback:300,catalogRefreshSeconds:900,requestConcurrency:3,requestSpacingMs:200,now:Date.now,fetchImpl:globalThis.fetch});
const DAY=86400000,WEEK=7*DAY;
const hash=s=>createHash('sha256').update(s).digest('hex');
const time=x=>Number.isSafeInteger(x)&&x>=0;
const fail=(code,message,extra={})=>Object.assign(new Error(message),{code,...extra});
export const WEEKLY_CALENDAR={anchor:'monday_00_utc',openOffsetMs:4*DAY,verified:true,source:'Native TradingView D1-to-W1 calendar exercise, 24 boundaries across BTC/ETH/SOL/ZEC',sourceEvidenceSHA256:'1e14d8bf35de193120f63d7c5f1b344344b213aaee47c85186905193e9b8ff39'};

export function normalizeHistory(data,{symbol,timeframe,requestStartedAt,receivedAt,source}={}){
 const period=PERIODS[timeframe];
 if(!isSupportedSymbol(symbol)||!period||!time(requestStartedAt)||!time(receivedAt)||receivedAt<requestStartedAt)throw fail('invalid_capture','Некорректное время снимка.');
 if(!data||data.s!=='ok'||!Array.isArray(data.t)||data.t.length<1||data.t.length>10000||['o','h','l','c'].some(k=>!Array.isArray(data[k])||data[k].length!==data.t.length)||data.v!==undefined&&(!Array.isArray(data.v)||data.v.length!==data.t.length))throw fail('invalid_history','Источник не вернул согласованные массивы свечей.');
 const all=[],issues=[];let lastGap=-1;
 for(let i=0;i<data.t.length;i++){
  const openTime=data.t[i]*1000,values=[data.o[i],data.h[i],data.l[i],data.c[i]],volume=data.v?.[i]??null;
  if(!time(openTime)||openTime%period!==0||values.some(n=>typeof n!=='number'||!Number.isFinite(n)||n<=0)||values[1]<Math.max(values[0],values[3])||values[2]>Math.min(values[0],values[3])||volume!==null&&(typeof volume!=='number'||!Number.isFinite(volume)||volume<0))throw fail('invalid_ohlc','Источник вернул некорректную свечу.');
  if(openTime>requestStartedAt)throw fail('future_candle','Источник вернул свечу из будущего.');
  if(i&&openTime<=all.at(-1).openTime)throw fail('unordered_history','Нарушен порядок свечей.');
  if(i&&openTime!==all.at(-1).closeTime){lastGap=i;issues.push({code:'history_gap',timeframe,after:all.at(-1).closeTime,before:openTime});}
  all.push({openTime,closeTime:openTime+period,open:values[0],high:values[1],low:values[2],close:values[3],volume});
 }
 // Never infer patterns across absent bars. Retain the latest contiguous run.
 const contiguous=lastGap>=0?all.slice(lastGap):all;
 const closed=contiguous.filter(b=>b.closeTime<=requestStartedAt);
 const forming=contiguous.filter(b=>b.closeTime>requestStartedAt).map(b=>({...b,forming:true,frozenForming:true,observedAt:requestStartedAt}));
 const expected=Math.floor(requestStartedAt/period)*period;
 if(closed.at(-1)?.closeTime!==expected)issues.push({code:'latest_closed_candle_missing',timeframe,expected,actual:closed.at(-1)?.closeTime??null});
 if(closed.length<5)issues.push({code:'insufficient_contiguous_history',timeframe,bars:closed.length});
 return {symbol,timeframe,closed,forming,issues,source,requestStartedAt,receivedAt};
}

export function deriveWeekly(daily,{asOf}={}){
 if(!Array.isArray(daily)||!time(asOf))throw fail('invalid_daily','Для W1 нужны дневные свечи.');
 const grouped=new Map();
 for(const b of daily){if(b.forming||b.frozenForming||b.closeTime>asOf)continue;const openTime=Math.floor((b.openTime-4*DAY)/WEEK)*WEEK+4*DAY;if(!grouped.has(openTime))grouped.set(openTime,[]);grouped.get(openTime).push(b);}
 const bars=[];
 for(const [openTime,items] of grouped){items.sort((a,b)=>a.openTime-b.openTime);if(openTime+WEEK>asOf||items.length!==7||items.some((b,i)=>b.openTime!==openTime+i*DAY||b.closeTime!==b.openTime+DAY))continue;
  bars.push({openTime,closeTime:openTime+WEEK,open:items[0].open,high:Math.max(...items.map(b=>b.high)),low:Math.min(...items.map(b=>b.low)),close:items[6].close,volume:items.some(b=>b.volume===null)?null:items.reduce((n,b)=>n+b.volume,0),derivedFrom:'1D',calendarAnchor:'monday_00_utc'});
 }
 bars.sort((a,b)=>a.openTime-b.openTime);let suffix=0;for(let i=1;i<bars.length;i++)if(bars[i].openTime!==bars[i-1].closeTime)suffix=i;
 return {bars:bars.slice(suffix),calendar:WEEKLY_CALENDAR,issues:bars.length<5?[{code:'insufficient_weekly_history',bars:bars.length}]:[]};
}

export function parseRetryAfter(value,now=Date.now()){
 if(typeof value!=='string'||!value.trim())return null;
 const ms=/^\d+(\.\d+)?$/.test(value.trim())?Number(value)*1000:Date.parse(value)-now;
 return Number.isFinite(ms)?Math.min(3600000,Math.max(0,ms)):null;
}

async function readPublicJSON(url,{fetchImpl,timeoutMs,now,signal,onRateLimit=()=>{},requestStartedAt=now()}){
 const controller=new AbortController();
 const onAbort=()=>controller.abort();signal?.addEventListener('abort',onAbort,{once:true});
 if(signal?.aborted)controller.abort();
 const timer=setTimeout(()=>controller.abort(),timeoutMs);
 try{
  if(controller.signal.aborted)throw fail('request_aborted','Сбор публичных данных остановлен.');
  const response=await fetchImpl(url,{method:'GET',credentials:'omit',redirect:'error',headers:{accept:'application/json'},signal:controller.signal});
  if(!response.ok){
   const error=fail('http_error','Источник вернул HTTP '+response.status,{status:response.status,retryAfterMs:parseRetryAfter(response.headers?.get?.('retry-after'),now())});
   if(response.status===429)onRateLimit(error);
   throw error;
  }
  const bodyText=await response.text();
  if(controller.signal.aborted)throw fail(signal?.aborted?'request_aborted':'request_timeout','Не удалось получить публичные данные вовремя.');
  if(Buffer.byteLength(bodyText)>8*1024*1024)throw fail('response_too_large','Слишком большой ответ источника.');
  let data;try{data=JSON.parse(bodyText);}catch{throw fail('invalid_json','Источник вернул ответ не в формате JSON.');}
  return {data,bodySHA256:hash(bodyText),requestStartedAt,receivedAt:now(),source:String(url)};
 }catch(error){
  if(typeof error.code==='string')throw error;
  throw fail(controller.signal.aborted?(signal?.aborted?'request_aborted':'request_timeout'):'network_error','Не удалось получить публичные данные.',{cause:error});
 }finally{clearTimeout(timer);signal?.removeEventListener('abort',onAbort);}
}

/** The venue catalog, rather than a tag or a chart name, admits crypto pairs. */
function normalizeCatalog(response){
 const {data,source,requestStartedAt,receivedAt,bodySHA256}=response;
 if(!Array.isArray(data)||data.length>10000)throw fail('invalid_catalog','Источник не вернул список рынков.');
 const markets=[],excluded=[],ids=new Set(),symbols=new Set();let totalCrypto=0;
 for(const row of data){
  const config=row?.config,settings=row?.settings,symbol=config?.baseAsset,id=row?.id;
  const base={id:typeof id==='string'?id:null,marketId:typeof id==='string'?id:null,symbol:typeof symbol==='string'?symbol:null,category:typeof config?.category==='string'?config.category:null};
  const reasons=[];
  if(config?.category!=='crypto')reasons.push('non_crypto');
  else{
   totalCrypto++;
   if(typeof id!=='string'||!id.length||id.length>200||/[\x00-\x1f\x7f]/.test(id))reasons.push('invalid_market_id');
   if(!isSupportedSymbol(symbol))reasons.push('invalid_symbol');
   if(config.type!=='base'||config.quoteAsset!=='USD'||config.settlementToken!=='USD')reasons.push('unsupported_contract');
   if(['isClosed','isPaused','isCloseOnly'].some(key=>typeof settings?.[key]!=='boolean'))reasons.push('invalid_market_status');
   if(settings?.isClosed===true)reasons.push('market_closed');
   if(settings?.isPaused===true)reasons.push('market_paused');
   if(settings?.isCloseOnly===true)reasons.push('close_only');
   if(ids.has(id))reasons.push('duplicate_market_id');
   if(symbols.has(symbol))reasons.push('duplicate_symbol');
  }
  if(reasons.length){excluded.push({...base,code:reasons[0],reasons});continue;}
  ids.add(id);symbols.add(symbol);
  const name=typeof config.name==='string'?config.name:symbol+'/USD';
  markets.push({...base,name,displayName:name,ticker:typeof config.ticker==='string'?config.ticker:null,quoteAsset:'USD',settlementToken:'USD',type:'base',status:'open'});
 }
 return {symbols:markets.map(m=>m.symbol),markets,excluded,totalMarkets:data.length,totalCrypto,availableCrypto:markets.length,requestStartedAt,observedAt:receivedAt,source,bodySHA256};
}

export async function discoverCryptoMarkets({fetchImpl=globalThis.fetch,timeoutMs=12000,now=Date.now,signal}={}){
 if(typeof fetchImpl!=='function'||typeof now!=='function'||!Number.isSafeInteger(timeoutMs)||timeoutMs<1||timeoutMs>30000)throw fail('invalid_settings','Недопустимые параметры каталога.');
 return normalizeCatalog(await readPublicJSON(CATALOG_SOURCE,{fetchImpl,timeoutMs,now,signal}));
}

const describeError=(error,extra,observedAt)=>({...extra,code:error.code??'network_error',message:error.message??'Не удалось получить публичные данные.',status:error.status??null,retryAfterMs:error.retryAfterMs??null,observedAt});
const boundary=(at,timeframe)=>Math.floor(at/PERIODS[timeframe]);
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));

function validateCaptureOptions(options){
 const {symbols,timeoutMs,countback,catalogRefreshSeconds,requestConcurrency,requestSpacingMs,fetchImpl,now}=options;
 if(symbols!=='all_crypto'&&(!Array.isArray(symbols)||!symbols.length||symbols.length>2000||new Set(symbols).size!==symbols.length||symbols.some(s=>!isSupportedSymbol(s)))||
  !Number.isSafeInteger(timeoutMs)||timeoutMs<1||timeoutMs>30000||!Number.isSafeInteger(countback)||countback<5||countback>1000||
  !Number.isSafeInteger(catalogRefreshSeconds)||catalogRefreshSeconds<1||catalogRefreshSeconds>86400||!Number.isSafeInteger(requestConcurrency)||requestConcurrency<1||requestConcurrency>3||
  !Number.isSafeInteger(requestSpacingMs)||requestSpacingMs<0||requestSpacingMs>60000||typeof fetchImpl!=='function'||typeof now!=='function')throw fail('invalid_settings','Недопустимые параметры сбора свечей.');
}

function assembleMarket(symbol,parts,asOf,definition,issues=[]){
 const byTf=Object.fromEntries(parts.map(record=>[record.timeframe,record]));
 const missing=Object.keys(PERIODS).filter(tf=>!byTf[tf]);
 const provenance={symbol,asOf,definition:definition??null,sourceHashes:parts.map(record=>record.sourceHash)};
 if(missing.length)return {...provenance,status:'unavailable',issues:[...issues,{code:'incomplete_capture',timeframes:missing}],streams:{},forming:{},quote:null};
 const streams=Object.fromEntries(parts.map(record=>[record.timeframe,record.closed]));
 const forming=Object.fromEntries(parts.map(record=>[record.timeframe,record.forming.at(-1)??null]));
 const weekly=deriveWeekly(streams['1D'],{asOf});streams['1W']=weekly.bars;
 const last=byTf['5'].forming.at(-1)??byTf['5'].closed.at(-1);
 const quote=last?{price:last.close,observedAt:last.forming?byTf['5'].requestStartedAt:last.closeTime,source:byTf['5'].source,sourceKind:last.forming?'public_forming_M5_snapshot':'public_closed_M5',brokerExecutionQuote:false}:null;
 return {...provenance,receivedAt:Math.max(...parts.map(record=>record.receivedAt)),streams,forming,quote,weeklyCalendar:weekly.calendar,issues:[...issues,...parts.flatMap(record=>record.issues),...weekly.issues]};
}

/** Keep one instance for a polling loop: only M5 is fetched on every cycle. */
export function createPublicMarketProvider(settings={}){
 const defaults={...DEFAULTS,...settings};
 const state={cache:new Map(),catalog:null,cooldownUntil:0,startGate:Promise.resolve(),nextStartWallTime:0,nextSymbolIndex:0,busy:false};

 async function capture(options={}){
  const args={...defaults,...options};validateCaptureOptions(args);
  if(state.busy)throw fail('capture_in_progress','Предыдущий сбор публичных данных ещё выполняется.');
  state.busy=true;
  try{return await captureCycle(args);}finally{state.busy=false;}
 }

 async function captureCycle(args){
  const {symbols,timeoutMs,countback,now,fetchImpl,signal,catalogRefreshSeconds,requestConcurrency,requestSpacingMs,onProgress=()=>{},onMarket=()=>{},onUniverse=()=>{}}=args;
  const startedAt=now(),errors=[],marketsBySymbol=new Map();let stopped=false,completed=0,requestsCompleted=0;
  function stoppedError(){
   if(signal?.aborted)return fail('request_aborted','Сбор публичных данных остановлен.');
   if(stopped||now()<state.cooldownUntil)return fail('rate_limit_cooldown','Публичный источник ограничил частоту запросов.',{status:429,retryAfterMs:Math.max(0,state.cooldownUntil-now())});
   return null;
  }
  // A shared start gate spaces actual HTTP starts, including concurrent workers.
  async function request(url){
   let release;const before=state.startGate;state.startGate=new Promise(resolve=>{release=resolve;});
   await before;
   try{
    let blocked=stoppedError();if(blocked)throw blocked;
    const waitMs=Math.max(0,state.nextStartWallTime-Date.now());if(waitMs)await delay(waitMs);
    blocked=stoppedError();if(blocked)throw blocked;
    state.nextStartWallTime=Date.now()+requestSpacingMs;
   }finally{release();}
   const requestStartedAt=now(),requestURL=typeof url==='function'?url(requestStartedAt):url;
   return readPublicJSON(requestURL,{fetchImpl,timeoutMs,now,signal,requestStartedAt,onRateLimit:error=>{
    stopped=true;state.cooldownUntil=Math.max(state.cooldownUntil,now()+(error.retryAfterMs??60000));
   }});
  }

  let universe,selectedSymbols;
  if(symbols==='all_crypto'){
   try{
    let cacheHit=true;
    if(!state.catalog||now()>=state.catalog.observedAt+catalogRefreshSeconds*1000){state.catalog=normalizeCatalog(await request(CATALOG_SOURCE));cacheHit=false;}
    universe={mode:'all_crypto',status:state.catalog.symbols.length?'ready':'empty',...structuredClone(state.catalog),cacheHit,expiresAt:state.catalog.observedAt+catalogRefreshSeconds*1000};
    selectedSymbols=[...universe.symbols];
    if(!selectedSymbols.length)errors.push(describeError(fail('empty_crypto_universe','В каталоге нет доступных криптовалютных USD рынков.'),{source:CATALOG_SOURCE},now()));
   }catch(error){
    errors.push(describeError(error,{source:CATALOG_SOURCE},now()));
    universe={mode:'all_crypto',status:'unavailable',symbols:[],markets:[],excluded:[],totalMarkets:null,totalCrypto:null,availableCrypto:0,source:CATALOG_SOURCE,observedAt:null,bodySHA256:null,error:errors.at(-1)};selectedSymbols=[];
   }
  }else{
   selectedSymbols=[...symbols];
   universe={mode:'explicit',status:'ready',symbols:[...symbols],markets:[],excluded:[],source:null,observedAt:startedAt,availableCrypto:symbols.length};
  }
  await onUniverse({selectedSymbols:[...selectedSymbols],universe:structuredClone(universe)});
  const definitions=new Map(universe.markets.map(m=>[m.symbol,m]));
  const progressTotal=selectedSymbols.length*Object.keys(PERIODS).length;
  async function getRecord(symbol,timeframe){
   const key=JSON.stringify([symbol,timeframe,countback,definitions.get(symbol)?.marketId??null]),existing=state.cache.get(key);
   let record,cached=false;
   if(timeframe!=='5'&&existing&&existing.boundary===boundary(now(),timeframe)){record=structuredClone(existing.record);cached=true;}
   else{
    const period=PERIODS[timeframe];
    const response=await request(requestAt=>{
     const url=new URL('/api/datafeed-api/history',ORIGIN);
     url.search=new URLSearchParams({symbol,resolution:timeframe,from:String(Math.max(0,Math.floor(requestAt/1000)-countback*period/1000)),to:String(Math.floor(requestAt/1000)),countback:String(countback)}).toString();
     return url;
    });
    record=normalizeHistory(response.data,{symbol,timeframe,requestStartedAt:response.requestStartedAt,receivedAt:response.receivedAt,source:response.source});
    record.sourceHash={timeframe,source:response.source,method:'GET',requestStartedAt:response.requestStartedAt,observedAt:response.receivedAt,bodySHA256:response.bodySHA256};
    if(timeframe!=='5')state.cache.set(key,{boundary:boundary(record.requestStartedAt,timeframe),record:structuredClone(record)});
   }
   requestsCompleted++;await onProgress({completed:requestsCompleted,total:progressTotal,symbol,timeframe,cached});
   return record;
  }
  async function completeSymbol(symbol,skipError){
   const byTf=new Map(),symbolErrors=[];
   if(skipError)symbolErrors.push(describeError(skipError,{symbol},now()));
   else{
    let timeframe;
    try{
     for(timeframe of HIGHER_TIMEFRAMES)byTf.set(timeframe,await getRecord(symbol,timeframe));
     // A boundary can pass while another request is in flight. Refresh before
     // combining those streams; cached partial bars keep their original time.
     for(let pass=0;pass<4;pass++){
      for(timeframe of HIGHER_TIMEFRAMES)if(boundary(byTf.get(timeframe).requestStartedAt,timeframe)!==boundary(now(),timeframe))byTf.set(timeframe,await getRecord(symbol,timeframe));
      timeframe='5';byTf.set(timeframe,await getRecord(symbol,timeframe));
      if(HIGHER_TIMEFRAMES.every(tf=>boundary(byTf.get(tf).requestStartedAt,tf)===boundary(now(),tf)))break;
      byTf.delete('5');
      if(pass===3)throw fail('capture_boundary_changed','Граница свечи изменилась во время сбора; нужен новый снимок.');
     }
    }catch(error){const detail=describeError(error,{symbol,timeframe},now());symbolErrors.push(detail);requestsCompleted++;await onProgress({completed:requestsCompleted,total:progressTotal,symbol,timeframe,error:detail});}
   }
   errors.push(...symbolErrors);
   const market=assembleMarket(symbol,[...byTf.values()],now(),definitions.get(symbol),symbolErrors);
   marketsBySymbol.set(symbol,market);completed++;
   await onMarket(market,{completed,total:selectedSymbols.length,symbol,currentSymbol:symbol,errors:structuredClone(symbolErrors),selectedSymbols:[...selectedSymbols],universe:structuredClone(universe)});
  }
  const offset=selectedSymbols.length?state.nextSymbolIndex%selectedSymbols.length:0;
  const queue=[...selectedSymbols.slice(offset),...selectedSymbols.slice(0,offset)];let cursor=0,attempted=0;
  await Promise.all(Array.from({length:Math.min(requestConcurrency,queue.length)},async()=>{
   while(cursor<queue.length){
    const blocked=stoppedError();if(blocked)break;
    const symbol=queue[cursor++];attempted++;await completeSymbol(symbol);
   }
  }));
  // Retain a fair starting point after a partial cycle, including a 429.
  if(queue.length)state.nextSymbolIndex=(offset+attempted)%queue.length;
  while(cursor<queue.length)await completeSymbol(queue[cursor++],stoppedError()??fail('incomplete_capture','Сбор рынка не завершён.'));
  const finishedAt=now();
  return {schemaVersion:1,asOf:finishedAt,receivedAt:finishedAt,startedAt,markets:selectedSymbols.map(symbol=>marketsBySymbol.get(symbol)),selectedSymbols,universe,errors,sourceOrigin:ORIGIN,publicReadOnly:true,ordersSubmitted:0,cooldownUntil:state.cooldownUntil};
 }
 return {captureMarket:capture};
}

/** One-shot compatibility. Polling callers should retain the factory instance. */
export async function captureMarket(options={}){return createPublicMarketProvider().captureMarket(options);}

