import fs from 'node:fs/promises';
import {validateSymbolList} from './symbols.mjs';
export const DEFAULT_CONFIG=Object.freeze({symbols:'all_crypto',catalogRefreshSeconds:900,requestConcurrency:3,requestSpacingMs:200,pollSeconds:60,port:8787,dataDir:'data',balanceUSD:10000,riskPercent:1,maxDailyLossPercent:2,minimumRR:2,maximumExtendedRR:4,countback:300,timeoutMs:12000,signalFreshnessSeconds:180,codex:{enabled:true,command:'codex',mode:'review',maxCallsPerDay:8,cooldownSeconds:900,timeoutSeconds:180,signalMaxAgeSeconds:180}});
const integer=(v,min,max)=>Number.isSafeInteger(v)&&v>=min&&v<=max;
export function validateConfig(input={}){
 if(!input||typeof input!=='object'||Array.isArray(input))throw Error('Настройки должны быть JSON-объектом.');
 const allowed=new Set(Object.keys(DEFAULT_CONFIG));for(const k of Object.keys(input))if(!allowed.has(k))throw Error('Неизвестная настройка: '+k);
 const c={...structuredClone(DEFAULT_CONFIG),...input,codex:{...DEFAULT_CONFIG.codex,...input.codex}};
 if(c.symbols!=='all_crypto')c.symbols=validateSymbolList(c.symbols);
 for(const [k,min,max] of [['catalogRefreshSeconds',30,86400],['requestConcurrency',1,3],['requestSpacingMs',0,5000],['pollSeconds',30,3600],['port',1024,65535],['countback',100,1000],['timeoutMs',1000,30000],['signalFreshnessSeconds',30,300]])if(!integer(c[k],min,max))throw Error('Недопустимая настройка '+k);
 if(typeof c.dataDir!=='string'||!c.dataDir.trim()||c.dataDir.includes('\0'))throw Error('Недопустимая папка данных.');
 if(typeof c.balanceUSD!=='number'||!Number.isFinite(c.balanceUSD)||c.balanceUSD<=0||c.balanceUSD>1e9)throw Error('Укажите положительный расчётный баланс balanceUSD.');
 // These are the approved strategy limits, not an online account ledger.
 if(c.riskPercent!==1||c.maxDailyLossPercent!==2||c.minimumRR!==2||c.maximumExtendedRR!==4)throw Error('Согласованные параметры: риск 1%, дневной предел 2%, минимум RR 2, расширенная цель до RR 4.');
 if(!c.codex||typeof c.codex!=='object'||Array.isArray(input.codex))throw Error('Недопустимые настройки Codex.');
 for(const k of Object.keys(c.codex))if(!Object.hasOwn(DEFAULT_CONFIG.codex,k))throw Error('Неизвестная настройка Codex: '+k);
 if(typeof c.codex.enabled!=='boolean'||!['review','demo-ui'].includes(c.codex.mode)||typeof c.codex.command!=='string'||!c.codex.command.trim()||c.codex.command.includes('\0'))throw Error('Недопустимый режим Codex.');
 for(const [k,min,max] of [['maxCallsPerDay',1,100],['cooldownSeconds',0,86400],['timeoutSeconds',30,600],['signalMaxAgeSeconds',30,300]])if(!integer(c.codex[k],min,max))throw Error('Недопустимая настройка Codex '+k);
 return c;
}
export async function loadConfig(path){return validateConfig(JSON.parse(await fs.readFile(path,'utf8')));}
