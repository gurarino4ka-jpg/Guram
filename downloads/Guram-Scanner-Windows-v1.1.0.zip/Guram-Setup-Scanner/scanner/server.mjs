import http from 'node:http';

const allowedHosts=new Set(['127.0.0.1','localhost']);
const headers={
 'cache-control':'no-store, max-age=0',
 'x-content-type-options':'nosniff',
 'referrer-policy':'no-referrer',
 'cross-origin-resource-policy':'same-origin',
 'content-security-policy':"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'",
};

export function currentSnapshot(snapshot,{now=Date.now(),staleAfterMs=180000}={}){
 const copy=structuredClone(snapshot);
 if(!copy||copy.mode==='demo'||copy.status==='stopped')return copy;
 const generated=typeof copy.generatedAt==='number'?copy.generatedAt:Date.parse(copy.generatedAt);
 if(Number.isFinite(generated)&&now-generated<=staleAfterMs&&generated<=now+1000){
  // A later pair's update does not refresh an earlier pair's candles or signal.
  // Full-universe scans may legitimately span more than one signal lifetime.
  const signalAgeMs=Math.max(30000,Number(copy.config?.signalFreshnessSeconds??180)*1000);
  copy.symbols=(copy.symbols||[]).map(item=>{
   if(['offline','unavailable','data_error','error','pending','scanning'].includes(item.status))return {...item,confirmed:[]};
   const at=typeof item.asOf==='number'?item.asOf:Date.parse(item.asOf),quoteAt=item.quote?.observedAt;
   const stale=!Number.isFinite(at)||at>now+1000||now-at>staleAfterMs||Number.isFinite(quoteAt)&&(quoteAt>now+1000||now-quoteAt>120000);
   if(stale)return {...item,status:'stale',confirmed:[],issues:[...(item.issues||[]),{code:'symbol_data_stale',message:'Свечи этой пары ещё не обновлены. Обновление других пар не подтверждает её прежний сигнал.'}]};
   const current=(item.confirmed||[]).filter(s=>{const t=s.availableAt??s.confirmedAt??at;return Number.isSafeInteger(t)&&t<=now&&now-t<=signalAgeMs;});
   return current.length===(item.confirmed||[]).length?item:{...item,status:item.status==='setups_found'?'watching':item.status,confirmed:current,watch:[...(item.watch||[]),{code:'signal_expired',message:'Ранее найденный сигнал устарел; ожидаем новую проверку этой пары.'}]};
  });
  copy.confirmedCount=copy.symbols.reduce((n,x)=>n+(x.confirmed?.length||0),0);
  return copy;
 }
 copy.status='stale';copy.stale=true;copy.confirmedCount=0;
 copy.symbols=(copy.symbols||[]).map(item=>({...item,status:'stale',confirmed:[],issues:[...(item.issues||[]),'Нет свежего завершённого цикла. Прежние сигналы доступны только в истории.']}));
 return copy;
}

/** Local GET-only dashboard. No filesystem routes, account API or mutations. */
export async function startDashboard({port=8787,getSnapshot,renderDashboard,now=Date.now,staleAfterMs=180000}={}){
 if(!Number.isInteger(port)||port<0||port>65535||typeof getSnapshot!=='function'||typeof renderDashboard!=='function')throw new TypeError('Local dashboard configuration required.');
 const server=http.createServer(async(req,res)=>{
  const send=(status,type,body)=>{res.writeHead(status,{...headers,'content-type':type});res.end(body);};
  try{
   if(req.method!=='GET')return send(405,'text/plain; charset=utf-8','Метод не разрешён');
   const host=new URL('http://'+(req.headers.host||''));
   if(!allowedHosts.has(host.hostname))return send(403,'text/plain; charset=utf-8','Только локальный доступ');
   if(req.headers.origin){const origin=new URL(req.headers.origin);if(!allowedHosts.has(origin.hostname)||origin.port!==String(server.address()?.port))return send(403,'text/plain; charset=utf-8','Другой источник запрещён');}
   const path=new URL(req.url,'http://127.0.0.1').pathname;
   if(path==='/favicon.ico'){res.writeHead(204,headers);return res.end();}
   if(path==='/health')return send(200,'application/json; charset=utf-8',JSON.stringify({running:true,publicReadOnly:true,ordersSubmitted:0}));
   if(!['/','/status','/api/status'].includes(path))return send(404,'text/plain; charset=utf-8','Не найдено');
   const snapshot=currentSnapshot(await getSnapshot(),{now:now(),staleAfterMs});
   if(path==='/')return send(200,'text/html; charset=utf-8',renderDashboard(snapshot));
   return send(200,'application/json; charset=utf-8',JSON.stringify(snapshot));
  }catch{return send(500,'text/plain; charset=utf-8','Не удалось подготовить локальный отчёт');}
 });
 await new Promise((resolve,reject)=>{const failed=error=>{server.off('listening',ready);reject(error);};const ready=()=>{server.off('error',failed);resolve();};server.once('error',failed);server.once('listening',ready);server.listen(port,'127.0.0.1');});
 const assigned=server.address().port;
 return {server,port:assigned,url:'http://127.0.0.1:'+assigned,close:()=>new Promise((resolve,reject)=>{server.closeAllConnections?.();server.close(error=>error?reject(error):resolve());})};
}
