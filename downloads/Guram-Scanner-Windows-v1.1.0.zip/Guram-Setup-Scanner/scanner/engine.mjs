/** Pure course-rule scanner. It produces observed technical setups, never
 * orders or an assertion that a broker will accept the indicative quantity.
 * Every structural reference is a strict 2+1+2 WICK fractal; its actionable
 * pool/break level is the central BODY edge (D199). */
import {createHash} from 'node:crypto';
import {detectBodyFractals,detectStructureBreaks,detectFvgs,classifySweep} from './strategy/structure.mjs';
import {div,floorToStep,toExactDecimal} from './strategy/decimal.mjs';
import {isSupportedSymbol} from './symbols.mjs';

const PERIOD={'5':300000,'15':900000,'30':1800000,'60':3600000,'1D':86400000,'1W':604800000};
const copy=structuredClone;
const positive=n=>typeof n==='number'&&Number.isFinite(n)&&n>0;
const time=n=>Number.isSafeInteger(n)&&n>=0;
const hash=x=>createHash('sha256').update(JSON.stringify(x)).digest('hex');
const sideFor=d=>d==='up'?'long':'short';
const directionFor=s=>s==='long'?'up':'down';
const distance=(s,e,p)=>s==='long'?e-p:p-e;
const reward=(s,e,p)=>s==='long'?p-e:e-p;
const touched=(b,l,u)=>b.low<=u&&b.high>=l;
const barOk=b=>b&&time(b.openTime)&&time(b.closeTime)&&b.closeTime>b.openTime&&['open','high','low','close'].every(k=>positive(b[k]))&&b.high>=Math.max(b.open,b.close)&&b.low<=Math.min(b.open,b.close);
const last=(a,p=()=>true)=>a.filter(p).at(-1)||null;
const reason=(code,message,extra={})=>({code,message,...extra});
const finiteSettings=(s,key,def,min,max)=>{const n=s[key]??def;if(typeof n!=='number'||!Number.isFinite(n)||n<min||n>max)throw Error('invalid_setting_'+key);return n;};

function closedStream(input,tf,asOf){
 const period=PERIOD[tf],bars=[],issues=[];
 if(!Array.isArray(input))return {bars,issues:[reason('missing_'+tf,'Нет свечей '+tf)],usable:false};
 for(const b of input){
  if(b?.forming||b?.frozenForming||b?.formingObservation||b?.closeTime>asOf)continue;
  const offset=tf==='1W'?4*86400000:0;
  if(!barOk(b)||b.closeTime-b.openTime!==period||(b.openTime-offset)%period!==0||bars.length&&b.openTime<bars.at(-1).closeTime)return {bars:[],issues:[reason('invalid_'+tf,'Некорректная последовательность свечей '+tf)],usable:false};
  bars.push(copy(b));
 }
 // A historical outage cannot hide a more recent pivot. Only the complete
 // suffix after the last gap participates in new structural decisions.
 let gap=-1;for(let i=1;i<bars.length;i++)if(bars[i].openTime!==bars[i-1].closeTime)gap=i;
 if(gap>=0){issues.push(reason('history_gap_'+tf,'Используется непрерывный участок истории после пропуска '+tf));bars.splice(0,gap);}
 const expected=(tf==='1W'?4*86400000:0)+Math.floor((asOf-(tf==='1W'?4*86400000:0))/period)*period;
 const usable=bars.length>=5&&bars.at(-1)?.closeTime===expected;
 if(!usable)issues.push(reason('stale_or_short_'+tf,'Недостаточно свежих закрытых свечей '+tf));
 return {bars,issues,usable};
}

/** This automatic view is labelled as technical evidence. It does not claim
 * that an analyst reviewed the largest discretionary POI in the course. */
export function analyzeScale(bars,{timeframe,asOf,previous}={}){
 const fractals=detectBodyFractals(bars,{asOf}).events,breaks=detectStructureBreaks(bars,{asOf,fractalEvents:fractals}).events;
 const highs=fractals.filter(p=>p.type==='high'),lows=fractals.filter(p=>p.type==='low');
 const pairChange=a=>a.length<2?null:a.at(-1).price>a.at(-2).price?'higher':a.at(-1).price<a.at(-2).price?'lower':'equal';
 const comparison={highs:pairChange(highs),lows:pairChange(lows)};
 const pairDirection=comparison.highs==='higher'&&comparison.lows==='higher'?'up':comparison.highs==='lower'&&comparison.lows==='lower'?'down':null;
 const latestBreak=breaks.at(-1)||null,lastClose=bars.at(-1)?.closeTime??null;
 let direction=pairDirection,range=null,directionSource='last_two_confirmed_body_levels';
 const previousUsable=previous?.geometry==='strict-wick-2+1+2'&&time(previous.lastClosedAt)&&previous.lastClosedAt<=lastClose&&['up','down',null].includes(previous.direction);
 if(timeframe==='60'&&previousUsable){
  direction=previous.direction;range=copy(previous.range||null);directionSource='persisted_closed_H1_context';
  if(lastClose>previous.lastClosedAt){const newer=breaks.filter(b=>b.availableAt>previous.lastClosedAt);const external=newer.filter(b=>!range||(b.direction==='up'?b.closePrice>range.upper.price:b.closePrice<range.lower.price));if(external.length){direction=external.at(-1).direction;directionSource='closed_H1_structure_break_beyond_persisted_outer_range';range=null;}}
 }else if(timeframe==='60'&&latestBreak&&(!pairDirection||latestBreak.availableAt>=Math.max(highs.at(-1)?.availableAt||0,lows.at(-1)?.availableAt||0))){direction=latestBreak.direction;directionSource='closed_H1_structure_break';}
 if(!range){
  // The supplied continuous history bounds this technical approximation.
  // Outer confirmed pools avoid promoting every new internal pivot to a range.
  const high=highs.reduce((a,p)=>!a||p.price>a.price?p:a,null),low=lows.reduce((a,p)=>!a||p.price<a.price?p:a,null);
  if(high&&low&&high.price>low.price)range={upper:copy(high),lower:copy(low),activatedAt:lastClose,selection:'outer_confirmed_pools_in_available_history',technicalApproximation:true,requiresNarrativeReview:true};
 }
 return {timeframe,direction,pairDirection,comparison,directionSource,range,lastClosedAt:lastClose,latestBreak,fractals,breaks,
  geometry:'strict-wick-2+1+2',levelBasis:'central_body_edge',status:direction?'technical_direction':'unclear',
  analystReviewClaimed:false,sourceTimeframe:timeframe};
}

function activeFvgs(bars,asOf){
 return detectFvgs(bars,{asOf}).events.map(z=>{
  const later=bars.filter(b=>b.openTime>=z.availableAt),accepted= later.find(b=>z.direction==='bullish'?b.close<z.lower:b.close>z.upper);
  return {...z,kind:'fvg',timeframe:'60',sourceTimeframe:'60',status:accepted?'covered_and_H1_accepted':'active',acceptedAt:accepted?.closeTime??null,
   acceptedDirection:accepted?(z.direction==='bullish'?'down':'up'):null};
 });
}

/** A pool is consumed at its FIRST observable full/half-wick sweep. H1 is
 * checked before the short M5 window, preventing old swept pools from becoming
 * fresh again after a restart or truncated fine-timeframe history. */
export function observeSweeps(pools,{h1=[],m5=[],forming5,asOf,previousSweeps={}}={}){
 const out=[],states={};
 for(const pool of pools){
  const p={...copy(pool),timeframe:'60',kind:'liquidity_pool'},prior=previousSweeps[pool.id];
  let first=null;
  const priorGeometry=prior?.pool&&hash({price:prior.pool.price,high:prior.pool.rawHigh,low:prior.pool.rawLow})===hash({price:p.price,high:p.rawHigh,low:p.rawLow});
  if(priorGeometry&&time(prior.availableAt)&&prior.availableAt<=asOf)first=copy(prior);
  const coarse=h1.find(b=>b.openTime>=pool.availableAt&&classifySweep(pool,pool.type==='high'?b.high:b.low).qualified===true);
  const fine=m5.find(b=>b.openTime>=pool.availableAt&&classifySweep(pool,pool.type==='high'?b.high:b.low).qualified===true);
  if(coarse&&(!first||coarse.closeTime<first.availableAt))first={id:'sweep:'+pool.id,availableAt:coarse.closeTime,windowOpenTime:coarse.openTime,pool:p,bar:copy(coarse),timeframe:'60',precision:'H1_window'};
  // Fine bars refine only the known first coarse window, never a later resweep.
  if(fine&&(!first||fine.closeTime<=first.availableAt&&fine.openTime>=(first.windowOpenTime??0)))first={id:'sweep:'+pool.id,availableAt:fine.closeTime,windowOpenTime:fine.openTime,pool:p,bar:copy(fine),timeframe:'5',precision:'M5_window'};
  if(!first&&(!time(forming5?.observedAt)||forming5.observedAt<=asOf)&&barOk(forming5)&&forming5.openTime>=pool.availableAt&&forming5.openTime<=asOf&&forming5.closeTime>asOf&&classifySweep(pool,pool.type==='high'?forming5.high:forming5.low).qualified===true)first={id:'sweep:'+pool.id,availableAt:asOf,windowOpenTime:forming5.openTime,pool:p,bar:copy(forming5),timeframe:'5',precision:'live_partial_M5'};
  if(first){const observed=classifySweep(p,p.type==='high'?first.bar.high:first.bar.low);first.kind=observed.kind;states[p.id]=first;out.push(first);}
 }
 return {events:out.sort((a,b)=>a.availableAt-b.availableAt),state:states};
}

/** Entry-zone traversal uses M30 acceptance. H1 acceptance remains separately
 * required before removing a zone from the target list. */
export function fvgTraversal(zone,zones,m30,asOf){
 const bullish=zone.direction==='bullish';
 const nearer=zones.filter(z=>z.id!==zone.id&&z.status==='active'&&z.direction===zone.direction&&z.availableAt<=asOf&&(bullish?z.lower>=zone.upper:z.upper<=zone.lower));
 const passed=[],blocked=[];
 for(const z of nearer){const close=m30.find(b=>b.openTime>=z.availableAt&&b.closeTime<=asOf&&(bullish?b.close<z.lower:b.close>z.upper));
  (close?passed:blocked).push({zoneId:z.id,lower:z.lower,upper:z.upper,acceptedAt:close?.closeTime??null});}
 return {allowed:blocked.length===0,acceptanceTimeframe:'30',passed,blocked};
}

function breakEvidence(event,bars,fractals,tf){
 if(!event)return null;
 const ref=fractals.find(p=>p.id===event.referenceFractalId),bar=bars.find(b=>b.closeTime===event.availableAt);
 return {id:event.id,timeframe:tf,direction:event.direction,availableAt:event.availableAt,bar:copy(bar),reference:copy(ref),
  lastConfirmedFractal:true,bodyCloseBeyondLevel:true};
}

export function targetsFor(side,entry,pools,fvgs,sweeps,entryZone){
 const consumed=new Set(sweeps.map(x=>x.pool.id)),out=[];
 for(const p of pools){if(consumed.has(p.id)||p.type!==(side==='long'?'high':'low')||reward(side,entry,p.price)<=0)continue;
  out.push({id:p.id,kind:'liquidity_pool',timeframe:'60',price:p.price,availableAt:p.availableAt,levelBasis:'central_body_edge',pool:copy(p)});}
 for(const z of fvgs){if(z.status!=='active'||z.id===entryZone?.id)continue;
  const level=side==='long'?z.lower:z.upper;
  if(reward(side,entry,level)>0)out.push({id:z.id,kind:'fvg',timeframe:'60',price:level,lower:z.lower,upper:z.upper,availableAt:z.availableAt,
   nearestBoundary:true,H1Accepted:false});
 }
 return out.sort((a,b)=>reward(side,entry,a.price)-reward(side,entry,b.price)||a.availableAt-b.availableAt);
}

/** Risk is an indicative linear USD calculation, not a verified order size. */
export function planLevels({side,entry,zone,h1Fractals,targets,balanceUSD=10000,riskPercent=1,asOf}={}){
 const reasons=[];if(!['long','short'].includes(side)||!positive(entry)||!positive(balanceUSD)||riskPercent!==1)return {status:'rejected',reasons:[reason('invalid_risk_inputs','Нужны положительный баланс, цена и стандартный риск 1%.')]};
 let stop,reference,inside=zone?.status==='active'&&entry>=zone.lower&&entry<=zone.upper;
 if(inside){const edge=side==='long'?zone.lower:zone.upper,d=distance(side,entry,edge);if(!(d>0))return {status:'rejected',reasons:[reason('zero_FVG_stop','Вход на защитной границе FVG не даёт положительного стопа.')]};stop=side==='long'?entry-d*1.1:entry+d*1.1;reference={kind:'FVG_boundary_plus_ten_percent',zoneId:zone.id,boundary:edge,reservePercent:10};}
 else {const p=last(h1Fractals||[],p=>p.type===(side==='long'?'low':'high')&&p.availableAt<=asOf);if(!p)return {status:'rejected',reasons:[reason('missing_H1_stop_fractal','Нет последнего подтверждённого H1 фрактала для стопа.')]};stop=side==='long'?(p.price+p.rawLow)/2:(p.price+p.rawHigh)/2;reference={kind:'H1_wick_midpoint',fractalId:p.id,bodyLevel:p.price,wickTip:side==='long'?p.rawLow:p.rawHigh,reservePercent:0};}
 const d=distance(side,entry,stop);if(!(d>0)||!positive(stop))return {status:'rejected',stopLoss:stop,reasons:[reason('stop_wrong_side','Стоп за последним H1 фракталом находится не с защитной стороны входа.')]};
 const ahead=(targets||[]).filter(t=>reward(side,entry,t.price)>0&&t.availableAt<=asOf).sort((a,b)=>reward(side,entry,a.price)-reward(side,entry,b.price));
 if(!ahead.length)return {status:'rejected',stopLoss:stop,reasons:[reason('missing_real_H1_target','Нет реальной ближайшей цели на H1.')]};
 const nearest=ahead[0],nearestRR=reward(side,entry,nearest.price)/d;let target=nearest,extended=false;
 if(nearestRR<2){
  if(nearest.kind==='fvg')return {status:'rejected',stopLoss:stop,nearestTarget:nearest,nearestRR,reasons:[reason('unpassed_FVG_blocks_RR_extension','До ближайшей H1 FVG меньше 2R; переход за неё требует полного прохода и закрытия H1 за дальней границей.')]};
  return {status:'rejected',stopLoss:stop,nearestTarget:nearest,nearestRR,reasons:[reason('unpassed_nearest_POI_blocks_RR_extension','До ближайшей H1 цели меньше 2R; следующая цель требует доказанного прохождения первой.')]};
 }
 const rr=reward(side,entry,target.price)/d,risk=balanceUSD*.01;
 const quantity=Number(toExactDecimal(floorToStep(div(String(risk),String(d)),'0.000000001')));
 return {status:'planned',entry,stopLoss:stop,takeProfit:target.price,rr,riskUSD:risk,quantity,
  actualIndicativeRiskUSD:quantity*d,notionalUSD:quantity*entry,minimumLeverageAtThisBalance:quantity*entry/balanceUSD,
  riskPercent:1,balanceUSD,quantityBrokerVerified:false,quantityPrecision:'display/request precision only; no broker grid asserted',
  stopReference:reference,target:copy(target),nearestTarget:copy(nearest),targetExtended:extended,insideFVG:Boolean(inside),
  breakeven:{triggerPrice:side==='long'?entry+d*1.5:entry-d*1.5,initialR:d,lockGrossUSD:10,fixedAfterMove:true},reasons};
}

export function recoveryRatio(side,b){const span=b.high-b.low;if(!(span>0)||(side==='long'?b.low>=b.open:b.high<=b.open))return 0;return side==='long'?(b.close-b.low)/span:(b.high-b.close)/span;}
function impulseInfo(b,bars){const i=bars.findIndex(x=>x.openTime===b?.openTime),prev=bars.slice(Math.max(0,i-7),i);if(!b||prev.length<7)return {impulsive:false,lookback:7,reason:'seven_previous_closed_bars_required'};const median=a=>a.sort((x,y)=>x-y)[3],mb=median(prev.map(x=>Math.abs(x.close-x.open))),mr=median(prev.map(x=>x.high-x.low));return {impulsive:Math.abs(b.close-b.open)>=2*mb&&b.high-b.low>=2*mr,lookback:7,bodyRatio:mb?Math.abs(b.close-b.open)/mb:null,rangeRatio:mr?(b.high-b.low)/mr:null,wickHeavy:Math.abs(b.close-b.open)<mb&&b.high-b.low>=2*mr};}
function m15Observation(side,price,target,bars,breaks){
 const near=Math.abs(target-price)/Math.abs(target)<=.005;
 if(!near)return {usedForEntry:false,nearFirstPOI:false,thresholdPercent:.5};
 const three=bars.slice(-3),dir=directionFor(side),opposite=breaks.find(b=>three.length&&b.availableAt>=three[0].openTime&&b.direction!==dir),updates=three.length===3&&three.slice(1).every((b,i)=>side==='long'?b.high>three[i].high:b.low<three[i].low);
 return {usedForEntry:false,observationOnly:true,nearFirstPOI:true,thresholdPercent:.5,confident:updates&&!opposite,
  candleCloseTimes:three.map(b=>b.closeTime),oppositeBreak:opposite||null,
  note:updates&&!opposite?'M15 подтверждает уверенное движение по теням.':'Рядом с POI нет уверенной последовательности M15; наблюдаем следующие три закрытия.'};
}

export function analyzeSymbol(input={}){
 const {symbol,streams={},forming={},asOf,quote,sourceHashes=[],previousState={},settings={}}=input;
 const report={symbol,asOf,quote:copy(quote||null),sourceHashes:copy(sourceHashes),price:quote?.price??null,direction:null,
  status:'watching',context:{},confirmed:[],watch:[],rejected:[],zones:[],issues:[],nextState:{schemaVersion:1,asOf,sweeps:{},usedSweepIds:[],h1Context:null},
  searchEnabled:true,ordersSubmitted:0,executionEnabled:false,automaticExecutionEnabled:false};
 try{
  if(!isSupportedSymbol(symbol)||!time(asOf))throw Error('invalid_symbol_or_time');
  const maxQuoteAgeMs=finiteSettings(settings,'maxQuoteAgeSeconds',120,10,300)*1000,balanceUSD=finiteSettings(settings,'balanceUSD',10000,.01,1e12),
   freshnessMs=finiteSettings(settings,'signalFreshnessSeconds',180,15,1800)*1000;
  if(!positive(quote?.price)||!time(quote.observedAt)||quote.observedAt>asOf||asOf-quote.observedAt>maxQuoteAgeMs||typeof quote.source!=='string'||!quote.source)throw Error('fresh_quote_required');
  const previousValid=previousState?.schemaVersion===1&&previousState.symbol===symbol&&time(previousState.asOf)&&previousState.asOf<=asOf;
  const state=previousValid?previousState:{};
  const clean={};for(const tf of ['5','15','30','60','1D','1W']){clean[tf]=closedStream(streams[tf],tf,asOf);report.issues.push(...clean[tf].issues);}
  if(['5','30','60'].some(tf=>!clean[tf].usable)){report.status='data_error';report.watch.push(reason('await_fresh_history','Поиск входа остановлен до получения свежих M5/M30/H1.'));return report;}
  const bars=Object.fromEntries(Object.entries(clean).map(([k,v])=>[k,v.bars]));
  // Check complete native overlaps. Forming bars are never combined with
  // completed bars to manufacture a breakout or the fifth fractal candle.
  const by30=new Map(bars['30'].map(b=>[b.openTime,b]));for(const h of bars['60']){const a=by30.get(h.openTime),b=by30.get(h.openTime+1800000);if(a&&b&&['open','close','high','low'].some(k=>h[k]!==({open:a.open,close:b.close,high:Math.max(a.high,b.high),low:Math.min(a.low,b.low)})[k]))throw Error('H1_M30_source_overlap_mismatch');}
  const h1=analyzeScale(bars['60'],{timeframe:'60',asOf,previous:state.h1Context}),m30=analyzeScale(bars['30'],{timeframe:'30',asOf}),m5=analyzeScale(bars['5'],{timeframe:'5',asOf}),m15=analyzeScale(bars['15'],{timeframe:'15',asOf});
  const daily=clean['1D'].usable?analyzeScale(bars['1D'],{timeframe:'1D',asOf}):null,weekly=clean['1W'].usable?analyzeScale(bars['1W'],{timeframe:'1W',asOf}):null;
  report.direction=h1.direction;report.context={h1:{direction:h1.direction,pairDirection:h1.pairDirection,range:h1.range,lastBreak:h1.latestBreak,directionSource:h1.directionSource,lastClosedAt:h1.lastClosedAt},
   daily:daily?{direction:daily.direction,pairDirection:daily.pairDirection,comparison:daily.comparison,technicalOnly:true}:null,
   weekly:weekly?{direction:weekly.direction,pairDirection:weekly.pairDirection,comparison:weekly.comparison,technicalOnly:true}:null,
   globalContextAvailable:Boolean(daily&&weekly),method:'native-scale confirmed wick fractals, central body levels, closed H1 direction changes',
   discretionaryNarrativeAutomated:false,requiresNarrativeReview:true,rangeSelection:'outer confirmed pools within supplied continuous history; course narrative requires review',weeklyReviewMoscow:'Sunday 23:00; fresh daily/weekly data also read on startup'};
  const fvgs=activeFvgs(bars['60'],asOf),sweeps=observeSweeps(h1.fractals,{h1:bars['60'],m5:bars['5'],forming5:forming['5'],asOf,previousSweeps:state.sweeps||{}}),used=new Set(state.usedSweepIds||[]);
  report.zones=[...h1.fractals.map(p=>({...copy(p),kind:'liquidity_pool',timeframe:'60',status:sweeps.state[p.id]?'swept':'active'})),...fvgs].slice(-150);
  report.nextState={schemaVersion:1,symbol,asOf,h1Context:{geometry:h1.geometry,direction:h1.direction,range:h1.range,lastClosedAt:h1.lastClosedAt},sweeps:sweeps.state,usedSweepIds:[...used]};
  const candidates=[],latest30=m30.breaks.at(-1),latest5=m5.breaks.at(-1),last30close=bars['30'].at(-1).closeTime,last5close=bars['5'].at(-1).closeTime;
  const addCandidate=c=>{if(!candidates.some(x=>x.id===c.id))candidates.push(c);};
  const firstBreakAfter=(scale,after,id)=>scale.breaks.find(b=>b.availableAt>after)?.id===id;
  const latestOpposite=(side,after)=>m30.breaks.some(b=>b.availableAt>after&&b.direction!==directionFor(side));
  // General route: first confirmed M30 structure after one observable H1 sweep.
  for(const sweep of sweeps.events){
   if(used.has(sweep.id))continue;
   const shift=m30.breaks.find(b=>b.availableAt>=sweep.availableAt);
   if(!shift){if(asOf-sweep.availableAt<2*86400000)report.watch.push(reason('sweep_waiting_M30','Пул снят; ждём закрытый слом M30.',{poolId:sweep.pool.id,sweepAt:sweep.availableAt}));continue;}
   if(shift.availableAt!==last30close||latest30?.id!==shift.id)continue;
   const side=sideFor(shift.direction),zone=last(fvgs,z=>z.status==='active'&&z.direction===(side==='long'?'bullish':'bearish')&&z.lower<=quote.price&&quote.price<=z.upper);
   addCandidate({id:`${symbol}:sweep_M30:${sweep.id}:${shift.id}`,route:'sweep_m30',side,availableAt:shift.availableAt,
    zone,sweep,break:breakEvidence(shift,bars['30'],m30.fractals,'30'),evidence:{sweep:copy(sweep),confirmation:breakEvidence(shift,bars['30'],m30.fractals,'30')}});
  }
  // H1 FVG routes use only post-formation reactions. The latest break must be
  // fresh, otherwise a restart would turn yesterday's setup into a new alert.
  for(const z of fvgs){
   const side=z.direction==='bullish'?'long':'short',dir=directionFor(side),later5=bars['5'].filter(b=>b.openTime>=z.availableAt);
   const protectiveClose=last(bars['30'],b=>b.openTime>=z.availableAt&&(side==='long'?b.close<z.lower:b.close>z.upper));
   const traversal=fvgTraversal(z,fvgs,bars['30'],asOf);
   const touch=last(later5,b=>b.closeTime<(latest30?.availableAt??0)&&touched(b,z.lower,z.upper));
   if(z.status==='active'&&!protectiveClose&&traversal.allowed&&touch&&latest30?.direction===dir&&latest30.availableAt===last30close&&latest30.availableAt>touch.closeTime&&firstBreakAfter(m30,touch.closeTime,latest30.id)&&!latestOpposite(side,touch.closeTime)){
    addCandidate({id:`${symbol}:fvg_M30:${z.id}:${latest30.id}`,route:'fvg_m30',side,zone:z,availableAt:latest30.availableAt,
     break:breakEvidence(latest30,bars['30'],m30.fractals,'30'),evidence:{zone:copy(z),traversal,reaction:copy(touch),confirmation:breakEvidence(latest30,bars['30'],m30.fractals,'30')}});
   }
   const ambiguousReaction=last(later5,b=>b.low<=z.midpoint&&b.high>=z.midpoint&&(side==='long'?b.low>=b.open:b.high<=b.open));
   if(z.status==='active'&&ambiguousReaction?.closeTime===last5close)report.watch.push(reason('midpoint_no_adverse_excursion','Касание середины FVG не доказывает откуп/продажу: у M5 нет встречного хода от открытия. Ждём новую реакцию и последующий слом.',{zoneId:z.id,timeframe:'5',technicalOnly:true}));
   const reaction=last(later5,b=>b.closeTime<(latest5?.availableAt??0)&&b.low<=z.midpoint&&b.high>=z.midpoint&&recoveryRatio(side,b)>=.5&&(side==='long'?b.close>=z.midpoint:b.close<=z.midpoint));
   if(z.status==='active'&&!protectiveClose&&traversal.allowed&&reaction&&latest5?.direction===dir&&latest5.availableAt===last5close&&latest5.availableAt>reaction.closeTime&&firstBreakAfter(m5,reaction.closeTime,latest5.id)&&!latestOpposite(side,reaction.closeTime)){
    addCandidate({id:`${symbol}:fvg_midpoint_M5:${z.id}:${reaction.closeTime}:${latest5.id}`,route:'fvg_midpoint_m5',side,zone:z,availableAt:latest5.availableAt,
     break:breakEvidence(latest5,bars['5'],m5.fractals,'5'),evidence:{zone:copy(z),traversal,reaction:{...copy(reaction),timeframe:'5',recoveryFraction:recoveryRatio(side,reaction),midpointTouched:true},confirmation:breakEvidence(latest5,bars['5'],m5.fractals,'5')}});
   }
   // Inversion: M30 closes beyond the far boundary; the opposite idea is
   // cancelled. Retest from the outside then needs its own closed M5 break.
   const flippedSide=side==='long'?'short':'long',flippedDir=directionFor(flippedSide),boundary=side==='long'?z.lower:z.upper;
   const lastReclaim=last(bars['30'],b=>b.openTime>=z.availableAt&&(side==='long'?b.close>z.upper:b.close<z.lower));
   const crossed=bars['30'].find(b=>b.openTime>=z.availableAt&&b.closeTime>(lastReclaim?.closeTime??0)&&(side==='long'?b.close<z.lower:b.close>z.upper));
   const reclaimed=crossed&&bars['30'].some(b=>b.openTime>=crossed.closeTime&&(side==='long'?b.close>z.upper:b.close<z.lower));
   if(crossed&&!reclaimed&&(flippedSide==='short'?quote.price<=boundary:quote.price>=boundary)){
    const retest=last(later5,b=>b.closeTime<(latest5?.availableAt??0)&&b.openTime>=crossed.closeTime&&touched(b,boundary,boundary)&&(flippedSide==='short'?b.close<=boundary:b.close>=boundary));
    if(retest&&latest5?.direction===flippedDir&&latest5.availableAt===last5close&&latest5.availableAt>retest.closeTime&&firstBreakAfter(m5,retest.closeTime,latest5.id)&&!latestOpposite(flippedSide,crossed.closeTime)){
     addCandidate({id:`${symbol}:fvg_retest_M5:${z.id}:${crossed.closeTime}:${retest.closeTime}:${latest5.id}`,route:'fvg_retest_m5',side:flippedSide,zone:z,availableAt:latest5.availableAt,
      break:breakEvidence(latest5,bars['5'],m5.fractals,'5'),evidence:{zone:copy(z),M30BoundaryClose:copy(crossed),retest:copy(retest),confirmation:breakEvidence(latest5,bars['5'],m5.fractals,'5')}});
    }
   }
   if(z.status==='active'&&!touch&&Math.abs(quote.price-z.midpoint)/quote.price<=.01)report.watch.push(reason('wait_FVG_reaction','Ждём новую реакцию от H1 FVG и слом соответствующего таймфрейма.',{zoneId:z.id,lower:z.lower,upper:z.upper,midpoint:z.midpoint,direction:side}));
  }
  // If H1 has no usable direction, only its own completed break may establish
  // the entry; M5/M30 do not invent the main narrative.
  if(h1.latestBreak?.availableAt===bars['60'].at(-1).closeTime&&(!h1.pairDirection||state.h1Context?.direction===null)){const b=h1.latestBreak;addCandidate({id:`${symbol}:H1_only:${b.id}`,route:'h1_only',side:sideFor(b.direction),zone:null,availableAt:b.availableAt,break:breakEvidence(b,bars['60'],h1.fractals,'60'),evidence:{confirmation:breakEvidence(b,bars['60'],h1.fractals,'60')}});}
  const emitted=new Set();
  for(const candidate of candidates){
   const c={...candidate,symbol,entry:quote.price,confirmedAt:candidate.availableAt,sourceHashes:copy(sourceHashes),quoteObservedAt:quote.observedAt,
    contextRelation:h1.direction?directionFor(candidate.side)===h1.direction?'with_H1_direction':'counter_H1_direction':'H1_unclear',reasons:[]};
   if(asOf-c.availableAt>freshnessMs)continue;
   if(!h1.direction&&candidate.route!=='h1_only'){report.rejected.push({...c,status:'rejected',reasons:[reason('H1_unclear_requires_H1_break','Нет ясности H1: ждём подтверждения на H1.')]});continue;}
   if(!daily||!weekly){report.rejected.push({...c,status:'rejected',reasons:[reason('global_context_data_missing','Для первого анализа нужны свежие D1 и W1.')]});continue;}
   if(c.zone&&c.route!=='fvg_retest_m5'){
    const crossed=bars['30'].some(b=>b.openTime>=c.zone.availableAt&&(c.side==='long'?b.close<c.zone.lower:b.close>c.zone.upper));
    const traversal=fvgTraversal(c.zone,fvgs,bars['30'],c.availableAt);
    if(crossed||!traversal.allowed){report.rejected.push({...c,status:'rejected',reasons:[reason(crossed?'M30_boundary_invalidates_original_FVG':'nearer_FVG_requires_M30_acceptance',crossed?'Закрытие M30 за защитной границей отменило исходное направление FVG.':'Ближняя FVG ещё не полностью пройдена закрытием M30.',{traversal})]});continue;}
   }
   const targetList=targetsFor(c.side,c.entry,h1.fractals,fvgs,sweeps.events,c.zone),planned=planLevels({side:c.side,entry:c.entry,zone:c.zone,h1Fractals:h1.fractals,targets:targetList,balanceUSD,asOf});
   if(planned.status!=='planned'){report.rejected.push({...c,...planned,status:'rejected'});continue;}
   const afterConfirmation=bars['5'].filter(b=>b.openTime>=c.availableAt);
   if((!time(forming['5']?.observedAt)||forming['5'].observedAt<=asOf)&&barOk(forming['5'])&&forming['5'].openTime>=c.availableAt&&forming['5'].openTime<=asOf&&forming['5'].closeTime>asOf)afterConfirmation.push(forming['5']);
   if(afterConfirmation.some(b=>c.side==='long'?b.high>=planned.takeProfit:b.low<=planned.takeProfit)){
    report.rejected.push({...c,...planned,status:'rejected',reasons:[reason('target_already_reached_after_confirmation','Цель уже достигнута после подтверждения; повторный запоздалый вход не выдаётся.')]});continue;
   }
   const opposing=fvgs.find(z=>z.status==='active'&&z.id!==c.zone?.id&&z.direction===(c.side==='long'?'bearish':'bullish')&&c.entry>=z.lower&&c.entry<=z.upper);
   if(opposing){report.watch.push({...c,...planned,status:'waiting',reasons:[reason('inside_opposing_H1_FVG','Цена находится внутри встречной H1 FVG; нужен её полный проход и принятие H1 либо новая реакция.',{zoneId:opposing.id})]});continue;}
   const m15note=m15Observation(c.side,c.entry,planned.nearestTarget.price,bars['15'],m15.breaks),impulse=impulseInfo(c.break?.bar,c.break?.timeframe==='5'?bars['5']:bars['30']);
   if(c.route==='sweep_m30'&&m15note.nearFirstPOI&&(!clean['15'].usable||m15note.confident!==true)){report.watch.push({...c,...planned,status:'waiting',m15Observation:m15note,reasons:[reason('wait_three_M15_closes_near_POI','Рядом с первой POI движение неуверенное: наблюдаем следующие три M15 свечи.')]});continue;}
   const proofKey=`${c.side}:${c.break.id}:${planned.stopReference.kind}:${planned.takeProfit}`;
   if(emitted.has(proofKey))continue;emitted.add(proofKey);
   report.confirmed.push({...c,...planned,status:'confirmed_setup',availableAt:c.availableAt,confirmedAt:c.availableAt,m15Observation:m15note,impulse,
    interpretation:'Технический сетап по формализованным правилам; не торговая заявка.',
    requiresHumanNarrativeReview:true,narrativeReviewReason:'Outer H1 pools are a bounded technical approximation of the discretionary course range; no analyst review is claimed.',
    evidence:{...c.evidence,stop:copy(planned.stopReference),target:copy(planned.target),h1Direction:h1.direction,dailyDirection:daily.direction,weeklyDirection:weekly.direction},
    riskScope:'Расчёт по указанному пользователем балансу; счёт и фактический дневной P&L не считываются.',ordersSubmitted:0,executionEnabled:false});
   if(c.sweep)used.add(c.sweep.id);
  }
  report.nextState.usedSweepIds=[...used].slice(-2000);
  report.status=report.confirmed.length?'setups_found':report.rejected.length?'conditions_not_met':'watching';
  if(!report.confirmed.length&&!report.watch.length)report.watch.push(reason('wait_structure_and_POI','Ждём снятие H1 ликвидности и слом M30 либо разрешённую реакцию FVG со сломом M5.'));
  report.watch=report.watch.slice(-30);report.rejected=report.rejected.slice(-20);return report;
 }catch(error){report.status='data_error';report.issues.push(reason(error.message||'invalid_input','Поиск остановлен: данные или параметры не прошли проверку.'));return report;}
}

export function analyzeMarket(capture,{settings={},previousState={}}={}){
 const markets=(capture?.markets||[]).map(m=>analyzeSymbol({...m,asOf:m.asOf??capture.asOf,settings,previousState:previousState[m.symbol]||{}}));
 return {asOf:capture?.asOf,status:markets.some(m=>m.confirmed.length)?'setups_found':markets.every(m=>m.status==='data_error')?'data_error':'watching',
  markets,confirmed:markets.flatMap(m=>m.confirmed),nextState:Object.fromEntries(markets.map(m=>[m.symbol,m.nextState])),ordersSubmitted:0,executionEnabled:false};
}
