/** A chart identifier is a single asset code, never a pathname or URL.
 * Syntax is not market admission: the provider's official crypto catalog
 * determines which codes are available on UpScale/Bookflow. */
export const ALL_CRYPTO='all_crypto';
export function isSupportedSymbol(value){
 return typeof value==='string'&&/^[A-Z0-9][A-Z0-9._-]{0,31}$/.test(value)&&!['__PROTO__','PROTOTYPE','CONSTRUCTOR'].includes(value);
}
export function validateSymbolList(values,{allowEmpty=false}={}){
 if(!Array.isArray(values)||(!allowEmpty&&!values.length)||values.length>2000||new Set(values).size!==values.length||values.some(v=>!isSupportedSymbol(v)))throw new TypeError('Нужен список уникальных кодов криптовалют без путей, URL или специальных команд.');
 return [...values];
}
