import {completedSessionLevels} from './strategy/sessions.mjs';

/** Completed Tokyo/London/New York windows are observations, never a new
 * standalone entry rule. The course didn't resolve body/wick selection for
 * session extrema separately, so expose both without silently choosing a TP. */
export function appendMarketHoursContext(report,market){
 if(!report||!Array.isArray(market?.streams?.['60'])||!Number.isSafeInteger(market.asOf)||report.status==='data_error')return report;
 const bars=market.streams['60'].filter(b=>!b.forming&&!b.frozenForming&&b.closeTime<=market.asOf);
 try{
  const bodies=completedSessionLevels(bars,{asOf:market.asOf,basis:'body'}),wicks=completedSessionLevels(bars,{asOf:market.asOf,basis:'wick'}),byId=new Map(wicks.levels.map(x=>[x.id,x]));
  const completed=bodies.levels.filter(x=>byId.has(x.id)).map(x=>({id:x.id,name:x.session,date:x.date,timeZone:x.timeZone,startsAt:x.start,endsAt:x.end,availableAt:x.availableAt,
   bodyHigh:x.high,bodyLow:x.low,wickHigh:byId.get(x.id).high,wickLow:byId.get(x.id).low,potentialLiquidityObjective:true,standaloneEntry:false}));
  const nearby=[];
  for(const w of completed)for(const field of ['bodyHigh','bodyLow','wickHigh','wickLow'])if(Number.isFinite(report.price)&&Math.abs(report.price-w[field])/w[field]<=.005)nearby.push({id:w.id,window:w.name,date:w.date,basis:field,level:w[field],distancePercent:100*Math.abs(report.price-w[field])/w[field],observationOnly:true});
  return {...report,context:{...report.context,marketHoursExtremes:{completed,nearby,proximityPercent:.5,basisRequiresNarrativeReview:true,changesTradeTargetsAutomatically:false,
   note:'Завершённые сессии; тела и тени показаны отдельно. Это потенциальные цели ликвидности, а не самостоятельные сигналы.'}}};
 }catch{return {...report,issues:[...(report.issues||[]),{code:'market_hours_context_unavailable',message:'Сессионные экстремумы не рассчитаны; самостоятельный вход по ним не формируется.'}]};}
}
