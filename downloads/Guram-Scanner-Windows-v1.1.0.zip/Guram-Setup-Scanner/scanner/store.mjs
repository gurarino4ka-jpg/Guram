/** Local analysis state only. No credentials, broker access or execution. */
import fs from 'node:fs/promises';
import {constants} from 'node:fs';
import {resolve} from 'node:path';
import {createHash,randomUUID} from 'node:crypto';
import {isSupportedSymbol} from './symbols.mjs';

const hash=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const digest=value=>typeof value==='string'&&/^[a-f0-9]{64}$/.test(value);
const object=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const fail=code=>Object.assign(new Error(code),{code});
const blank=()=>({schemaVersion:1,sequence:0,symbols:{},seenSignalIds:[],history:[]});
const id=value=>typeof value==='string'&&value.length>0&&value.length<=500;

export class ScannerStore{
 constructor(directory,{now=Date.now,pid=process.pid,compactEvery=32,cacheOwnedState=false}={}){
  if(typeof directory!=='string'||!directory.trim()||typeof now!=='function'||!Number.isSafeInteger(pid)||pid<1||!Number.isSafeInteger(compactEvery)||compactEvery<2||typeof cacheOwnedState!=='boolean')throw new TypeError('Storage directory, clock and process ID required.');
  this.directory=resolve(directory);this.now=now;this.pid=pid;this.compactEvery=compactEvery;this.cacheOwnedState=cacheOwnedState;this.ownedHead=null;this.token=null;this.tail=Promise.resolve();
 }
 async initialize(){
  await fs.mkdir(this.directory,{recursive:true,mode:0o700});const stat=await fs.lstat(this.directory);
  if(!stat.isDirectory()||stat.isSymbolicLink())throw fail('unsafe_store_directory');
 }
 enqueue(action){const next=this.tail.catch(()=>{}).then(action);this.tail=next;return next;}
 async readFile(name){
  const path=resolve(this.directory,name);let handle;
  try{const stat=await fs.lstat(path);if(!stat.isFile()||stat.isSymbolicLink())throw fail('unsafe_store_file');
   handle=await fs.open(path,constants.O_RDONLY|(constants.O_NOFOLLOW||0));return await handle.readFile('utf8');
  }catch(error){if(error.code==='ENOENT')return null;throw error;}finally{await handle?.close();}
 }
 async atomic(name,value){
  const path=resolve(this.directory,name),tmp=path+'.tmp-'+randomUUID();let handle;
  try{const existing=await fs.lstat(path).catch(e=>{if(e.code==='ENOENT')return null;throw e;});if(existing&&(!existing.isFile()||existing.isSymbolicLink()))throw fail('unsafe_store_file');
   handle=await fs.open(tmp,'wx',0o600);await handle.writeFile(JSON.stringify(value,null,2)+'\n');await handle.sync();await handle.close();handle=null;await fs.rename(tmp,path);
  }finally{await handle?.close();await fs.unlink(tmp).catch(e=>{if(e.code!=='ENOENT')throw e;});}
 }
 async acquire(){
  this.ownedHead=null;
  await this.initialize();if(this.token)throw fail('store_already_locked');
  const token=randomUUID(),body=JSON.stringify({schemaVersion:1,pid:this.pid,token,createdAt:this.now()})+'\n',path=resolve(this.directory,'scanner.lock');
  for(let attempt=0;attempt<2;attempt++){
   let handle;
   try{handle=await fs.open(path,'wx',0o600);await handle.writeFile(body);await handle.sync();await handle.close();this.token=token;return {pid:this.pid,token};}
   catch(error){await handle?.close();if(error.code!=='EEXIST')throw error;
    const original=await this.readFile('scanner.lock');let lock;try{lock=JSON.parse(original);}catch{throw fail('invalid_store_lock');}
    if(lock?.schemaVersion!==1||!Number.isSafeInteger(lock.pid)||lock.pid<1||!id(lock.token)||!Number.isSafeInteger(lock.createdAt))throw fail('invalid_store_lock');
    let alive=true;try{process.kill(lock.pid,0);}catch(e){if(e.code==='ESRCH')alive=false;else if(e.code!=='EPERM')throw e;}
    if(alive)throw fail('scanner_already_running');
    if(await this.readFile('scanner.lock')!==original)throw fail('store_lock_changed');
    await fs.unlink(path);
   }
  }
  throw fail('store_lock_changed');
 }
 async assertOwned(){if(!this.token)throw fail('store_lock_required');const text=await this.readFile('scanner.lock');let lock;try{lock=JSON.parse(text);}catch{throw fail('store_lock_lost');}if(lock?.token!==this.token||lock.pid!==this.pid)throw fail('store_lock_lost');}
 async release(){return this.enqueue(async()=>{this.ownedHead=null;if(!this.token)return;await this.assertOwned();await fs.unlink(resolve(this.directory,'scanner.lock'));this.token=null;});}
 inspectRecord(record,previous,{anchor=false}={}){
  const s=record?.state;
  if(!object(record)||!Number.isSafeInteger(record.sequence)||record.sequence<1||!object(s)||s.schemaVersion!==1||s.sequence!==record.sequence||!object(s.symbols)||Object.keys(s.symbols).some(k=>!isSupportedSymbol(k))||
   !Array.isArray(s.seenSignalIds)||s.seenSignalIds.length>10000||s.seenSignalIds.some(x=>!id(x))||new Set(s.seenSignalIds).size!==s.seenSignalIds.length||
   !Array.isArray(s.history)||s.history.length>500||s.history.some(x=>!object(x)||!id(x.id))||!object(record.snapshot)||!digest(record.stateHash)||!digest(record.recordHash))throw fail('invalid_store_record');
  if(hash(s)!==record.stateHash)throw fail('store_state_integrity_mismatch');
  const {recordHash,...content}=record;if(hash(content)!==recordHash)throw fail('store_record_integrity_mismatch');
  if(previous){if(record.sequence!==previous.sequence+1||record.previousHash!==previous.recordHash)throw fail('store_journal_chain_invalid');}
  else if(!anchor&&(record.sequence!==1||record.previousHash!==null))throw fail('store_journal_origin_invalid');
  else if(anchor&&record.previousHash!==null&&!digest(record.previousHash))throw fail('store_journal_origin_invalid');
 }
 async load(){
  try{
   const loaded=await this.loadDisk();
   this.ownedHead=this.cacheOwnedState&&this.token?structuredClone(loaded):null;
   return loaded;
  }catch(error){this.ownedHead=null;throw error;}
 }
 async loadDisk(){
  await this.initialize();const text=await this.readFile('journal.jsonl'),checkpointText=await this.readFile('state.json');
  if(text===null||text===''){if(checkpointText!==null)throw fail('store_checkpoint_without_journal');return {state:blank(),snapshot:null,record:null,records:0};}
  if(!text.endsWith('\n'))throw fail('store_journal_incomplete');
  let checkpoint=null;try{if(checkpointText!==null)checkpoint=JSON.parse(checkpointText);}catch{throw fail('invalid_store_checkpoint');}
  let latest=null,found=false,count=0;
  for(const line of text.slice(0,-1).split('\n')){
   let parsed;try{parsed=JSON.parse(line);}catch{throw fail('invalid_store_journal');}
   const anchor=count===0&&parsed?.kind==='retained_checkpoint';const record=anchor?parsed.record:parsed;
   this.inspectRecord(record,latest,{anchor});latest=record;count++;
   if(checkpoint&&JSON.stringify(record)===JSON.stringify(checkpoint))found=true;
  }
  if(checkpoint&&!found)throw fail('store_checkpoint_not_in_journal');
  if(!checkpoint||checkpoint.recordHash!==latest.recordHash){await this.atomic('state.json',latest);await this.atomic('latest.json',latest.snapshot);}
  return {state:structuredClone(latest.state),snapshot:structuredClone(latest.snapshot),record:latest,records:count};
 }
 readState(){return this.enqueue(async()=>structuredClone((await this.load()).state));}
 latestSnapshot(){return this.enqueue(async()=>structuredClone((await this.load()).snapshot));}
 commit({symbolStates={},signals=[],snapshot}={}){return this.enqueue(async()=>{
  try{
  await this.assertOwned();if(!object(symbolStates)||Object.keys(symbolStates).some(k=>!isSupportedSymbol(k))||!Array.isArray(signals)||!object(snapshot))throw fail('invalid_store_commit');
  // The exclusive process lock protects this validated head. A restart still
  // verifies the complete retained journal before it can populate the cache.
  const current=this.cacheOwnedState&&this.ownedHead?this.ownedHead:await this.load(),state=current.state,seen=new Set(state.seenSignalIds),newSignals=[];
  for(const signal of signals){if(!object(signal)||!id(signal.id))throw fail('invalid_signal_id');if(!seen.has(signal.id)){seen.add(signal.id);newSignals.push(structuredClone(signal));}}
  const next={schemaVersion:1,sequence:state.sequence+1,symbols:{...state.symbols,...structuredClone(symbolStates)},seenSignalIds:[...seen].slice(-10000),history:[...state.history,...newSignals].slice(-500)};
  const latest={...structuredClone(snapshot),history:structuredClone(next.history),newSignals:structuredClone(newSignals)};
  const record={sequence:next.sequence,previousHash:current.record?.recordHash??null,state:next,stateHash:hash(next),snapshot:latest};record.recordHash=hash(record);
  this.inspectRecord(record,current.record);
  const handle=await fs.open(resolve(this.directory,'journal.jsonl'),constants.O_APPEND|constants.O_CREAT|constants.O_WRONLY|(constants.O_NOFOLLOW||0),0o600);
  try{if(!(await handle.stat()).isFile())throw fail('unsafe_store_file');await handle.writeFile(JSON.stringify(record)+'\n');await handle.sync();}finally{await handle.close();}
  await this.atomic('state.json',record);await this.atomic('latest.json',latest);
  // The bounded checkpoint retains the exact latest record, so a crash before
  // or after atomic journal compaction is recoverable with the same checkpoint.
  let records=current.records+1;
  if(records>=this.compactEvery){const tmp=resolve(this.directory,'journal.jsonl.tmp-'+randomUUID());let file;
   try{file=await fs.open(tmp,'wx',0o600);await file.writeFile(JSON.stringify({kind:'retained_checkpoint',record})+'\n');await file.sync();await file.close();file=null;await fs.rename(tmp,resolve(this.directory,'journal.jsonl'));}
   finally{await file?.close();await fs.unlink(tmp).catch(e=>{if(e.code!=='ENOENT')throw e;});}
   records=1;
  }
  if(this.cacheOwnedState)this.ownedHead={state:next,snapshot:latest,record,records};
  return {state:structuredClone(next),snapshot:structuredClone(latest),newSignals:structuredClone(newSignals)};
  }catch(error){this.ownedHead=null;throw error;}
 });}
}
