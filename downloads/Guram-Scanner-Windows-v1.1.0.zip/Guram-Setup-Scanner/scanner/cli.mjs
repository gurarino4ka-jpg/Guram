#!/usr/bin/env node
/** Local analysis only: public prices -> strategy -> persistent signals.
 * No credentials, model requests, broker account access or order execution. */
import fs from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {spawn,spawnSync} from 'node:child_process';
import {randomUUID} from 'node:crypto';
import {ScannerStore} from './store.mjs';
import {startDashboard} from './server.mjs';
import {appendMarketHoursContext} from './market-hours.mjs';
import {isSupportedSymbol,validateSymbolList} from './symbols.mjs';

const ROOT=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const authority={publicReadOnly:true,accountAccess:false,automaticExecution:false,ordersSubmitted:0,pollingLLMRequests:0};
const failedStatuses=new Set(['offline','stale','error','data_error','unavailable']);
const iso=ms=>new Date(ms).toISOString();
const clone=structuredClone;
const errorCode=e=>typeof e?.code==='string'&&/^[a-zA-Z0-9_:-]{1,100}$/.test(e.code)?e.code:'scan_failed';
const reason=e=>({code:errorCode(e),message:'Не удалось обновить публичные данные или завершить проверку. Предыдущие сигналы не считаются актуальными.'});

export function parseOptions(argv){
 const options={once:false,demo:false,selfTest:false,open:false,noServer:false,help:false,config:resolve(ROOT,'scanner.config.json'),dataDir:null,port:null},seen=new Set();
 const switches={'--once':'once','--demo':'demo','--self-test':'selfTest','--open':'open','--no-server':'noServer','--help':'help'};
 for(let i=0;i<argv.length;i++){
  const flag=argv[i];if(seen.has(flag))throw Error('Повторный параметр: '+flag);seen.add(flag);
  if(switches[flag]){options[switches[flag]]=true;continue;}
  if(!['--config','--data-dir','--port'].includes(flag)||!argv[i+1]||argv[i+1].startsWith('--'))throw Error('Неизвестный или неполный параметр: '+flag);
  const value=argv[++i];
  if(flag==='--config')options.config=resolve(value);
  if(flag==='--data-dir')options.dataDir=resolve(value);
  if(flag==='--port'){if(!/^\d+$/.test(value)||Number(value)<1024||Number(value)>65535)throw Error('Порт должен быть от 1024 до 65535.');options.port=Number(value);}
 }
 if(options.once&&options.open)throw Error('--open применяется к непрерывному режиму.');
 return options;
}

export function abortableWait(ms,signal){
 if(signal?.aborted)return Promise.resolve();
 return new Promise(resolve=>{const finish=()=>{clearTimeout(timer);signal?.removeEventListener('abort',finish);resolve();};const timer=setTimeout(finish,ms);signal?.addEventListener('abort',finish,{once:true});});
}

export function openLocalDashboard(url,{platform=process.platform,spawnImpl=spawn}={}){
 const parsed=new URL(url);if(parsed.protocol!=='http:'||parsed.hostname!=='127.0.0.1'||parsed.pathname!=='/'||parsed.username||parsed.password||parsed.search||parsed.hash||!/^\d+$/.test(parsed.port))throw Error('Открывается только локальная панель.');
 let child;
 if(platform==='win32')child=spawnImpl('cmd.exe',['/d','/c','start','',url],{detached:true,stdio:'ignore',windowsHide:true});
 else if(platform==='darwin')child=spawnImpl('open',[url],{detached:true,stdio:'ignore'});
 else child=spawnImpl('xdg-open',[url],{detached:true,stdio:'ignore'});
 child.on?.('error',()=>{});child.unref?.();
}

async function saveHtml(directory,html){
 const file=resolve(directory,'latest-report.html'),tmp=file+'.tmp-'+randomUUID();
 await fs.writeFile(tmp,html,{mode:0o600,flag:'wx'});await fs.rename(tmp,file);
}

function unavailable(symbol,asOf,issue){return {symbol,status:'offline',asOf,price:null,direction:null,context:{},confirmed:[],watch:[],rejected:[],zones:[],issues:[issue]};}

/** Dependencies make all runtime paths testable without live prices. The CLI
 * uses the fixed public provider and course engine; there is no trading adapter. */
export async function runScanner({settings,dataDir,once=false,demoCapture=null,serve=!once,openBrowser=false,signal,maximumCycles=null}={},dependencies={}){
 if(!settings||!(settings.symbols==='all_crypto'||Array.isArray(settings.symbols))||!dataDir||!Number.isFinite(settings.pollSeconds)||settings.pollSeconds<1)throw new TypeError('Параметры сканера и папка данных обязательны.');
 if(Array.isArray(settings.symbols))validateSymbolList(settings.symbols);
 const now=dependencies.now||Date.now,wait=dependencies.wait||abortableWait;
 const capture=dependencies.captureMarket,analyze=dependencies.analyzeSymbol,render=dependencies.renderDashboard;
 if(typeof analyze!=='function'||typeof render!=='function'||!demoCapture&&typeof capture!=='function')throw new TypeError('Provider, engine and dashboard required.');
 const store=dependencies.store||new ScannerStore(dataDir,{now,compactEvery:8,cacheOwnedState:true}),controller=new AbortController();
 const stop=()=>controller.abort();signal?.addEventListener('abort',stop,{once:true});if(signal?.aborted)stop();
 const runtimeSignal=controller.signal,started=now(),mode=demoCapture?'demo':'live';let dashboard=null,cycles=0,failureStreak=0,latest=null,state,lastResult=null,handoffRunning=null;
 let selectedSymbols=demoCapture?validateSymbolList((demoCapture.markets||[]).map(m=>m.symbol)):Array.isArray(settings.symbols)?[...settings.symbols]:[];
 let universe={mode:mode==='demo'?'demo':settings.symbols==='all_crypto'?'all_crypto':'manual',status:mode==='demo'?'fixture':'pending',selectedCount:selectedSymbols.length};
 const handoff=mode==='live'&&!once?dependencies.handoff:null;
 const handoffStatus=async()=>{try{return handoff?await handoff.status():{status:mode==='demo'?'disabled_in_demo':once?'disabled_in_check':'disabled',mode:settings.codex?.mode||'review'};}catch{return {status:'unavailable',mode:settings.codex?.mode||'review'};}};
 const publish=async snapshot=>{latest=snapshot;await dependencies.onUpdate?.(clone(snapshot));await dependencies.onStatus?.({status:snapshot.status,cycle:snapshot.cycle,confirmedCount:snapshot.confirmedCount||0,progress:clone(snapshot.progress)});};
 // A long universe scan must not extend a previous pair's quote or setup TTL.
 const freshReport=report=>{
  if(mode==='demo'||failedStatuses.has(report.status)||report.status==='scanning')return report;
  const at=report.quote?.observedAt??report.asOf;
  if(!Number.isSafeInteger(at)||at>now()+1000||now()-at>120000)return {...report,status:'stale',confirmed:[],issues:[...(report.issues||[]),'Публичная котировка инструмента устарела.']};
  const confirmed=(report.confirmed||[]).filter(found=>{const at=found.availableAt??found.confirmedAt;return at===undefined||Number.isSafeInteger(at)&&at<=now()&&now()-at<=(settings.signalFreshnessSeconds||180)*1000;});
  return {...report,confirmed};
 };
 const startHandoff=()=>{if(handoff&&!handoffRunning&&!runtimeSignal.aborted)handoffRunning=Promise.resolve().then(()=>handoff.processNext()).catch(()=>{}).finally(()=>{handoffRunning=null;});};
 try{
  await store.acquire();state=await store.readState();
  latest={schemaVersion:1,mode,status:'starting',generatedAt:iso(now()),startedAt:iso(started),cycle:0,symbols:selectedSymbols.map(s=>unavailable(s,now(),'Первый цикл ещё не завершён.')),universe:clone(universe),progress:{completed:0,total:selectedSymbols.length,currentSymbol:null},history:state.history||[],errors:[],config:clone(settings),handoff:await handoffStatus(),...authority};
  if(serve){dashboard=await (dependencies.startDashboard||startDashboard)({port:settings.port,getSnapshot:()=>latest,renderDashboard:render,now,staleAfterMs:Math.max(180000,settings.pollSeconds*3000)});await dependencies.onReady?.(dashboard.url);if(openBrowser)(dependencies.openLocalDashboard||openLocalDashboard)(dashboard.url);}
  while(!runtimeSignal.aborted){
   cycles++;let marketCapture=null,retryAfterMs=0,currentSymbol=null,callbackQueue=Promise.resolve(),callbackFailure=null,universePublished=false,lastPersistAt=now(),pendingCompleted=0;
   const reports=new Map(latest.symbols.filter(r=>selectedSymbols.includes(r.symbol)).map(r=>[r.symbol,freshReport(r)])),completed=new Set(),cycleNewSignals=[],errors=[];
   let pendingSymbolStates={},pendingSignals=new Map();
   const seenSignalIds=new Set(state.seenSignalIds||[]);
   const addErrors=items=>{for(const e of items||[]){const safe={...(isSupportedSymbol(e?.symbol)?{symbol:e.symbol}:{}),code:errorCode(e),message:typeof e?.message==='string'?e.message:'Источник недоступен'};if(!errors.some(x=>x.symbol===safe.symbol&&x.code===safe.code&&x.message===safe.message))errors.push(safe);if(Number.isFinite(e?.retryAfterMs))retryAfterMs=Math.max(retryAfterMs,Math.min(3600000,Math.max(0,e.retryAfterMs)));}};
   const snapshotOf=status=>{
    const visible=selectedSymbols.map(symbol=>freshReport(reports.get(symbol)||{...unavailable(symbol,now(),'Ожидается чтение инструмента.'),status:'scanning'}));
    return {schemaVersion:1,mode,status,generatedAt:iso(now()),startedAt:iso(started),cycle:cycles,asOf:marketCapture?.asOf??null,symbols:visible,universe:clone(universe),progress:{completed:completed.size,total:selectedSymbols.length,currentSymbol},confirmedCount:visible.reduce((n,r)=>n+(r.confirmed?.length||0),0),history:state.history||[],errors:clone(errors),config:clone(settings),handoff:latest.handoff,...authority};
   };
   const persist=async({symbolStates={},signals=[],report=null,market=null,status='scanning',force=false}={})=>{
    Object.assign(pendingSymbolStates,symbolStates);Object.assign(state.symbols,symbolStates);
    for(const found of signals)if(!seenSignalIds.has(found.id))pendingSignals.set(found.id,found);
    // Full-universe snapshots can be large. Progress stays live in memory;
    // batch ordinary state, while every new setup is durable before dispatch.
    const shouldCommit=force||status!=='scanning'||pendingSignals.size>0||pendingCompleted>=10||now()-lastPersistAt>=10000;
    let committed=null,snapshot=snapshotOf(status);
    if(shouldCommit){
     committed=await store.commit({symbolStates:pendingSymbolStates,signals:[...pendingSignals.values()],snapshot});state=committed.state;cycleNewSignals.push(...committed.newSignals);
     for(const found of committed.newSignals)seenSignalIds.add(found.id);
     pendingSymbolStates={};pendingSignals=new Map();pendingCompleted=0;lastPersistAt=now();
     snapshot={...committed.snapshot,history:state.history||[]};
    }
    if(handoff){
     try{if(report&&market)for(const found of report.confirmed||[])await handoff.enqueue({...found,symbol:report.symbol},{report,capture:{asOf:market.asOf,receivedAt:market.receivedAt??now(),markets:[market],universe:clone(universe)}});startHandoff();}
     catch{snapshot.handoff={status:'queue_error',mode:settings.codex?.mode||'review'};}
     snapshot.handoff=await handoffStatus();
    }
    if(shouldCommit)await saveHtml(dataDir,render(snapshot));await publish(snapshot);
    for(const found of committed?.newSignals||[])await dependencies.onSignal?.(clone(found));
    return committed;
   };
   const selectUniverse=async({selectedSymbols:selection,universe:metadata}={})=>{
    if(!Array.isArray(selection))throw Object.assign(Error('Invalid selected universe'),{code:'invalid_universe'});
    // Empty discovery is a visible failure, never a fallback to four examples.
    const nextSymbols=selection.length?validateSymbolList(selection):[];
    const nextUniverse={...clone(metadata||{}),mode:mode==='demo'?'demo':settings.symbols==='all_crypto'?'all_crypto':'manual',selectedCount:nextSymbols.length};
    if(universePublished&&JSON.stringify(nextSymbols)===JSON.stringify(selectedSymbols)&&JSON.stringify(nextUniverse)===JSON.stringify(universe))return;
    universePublished=true;selectedSymbols=nextSymbols;universe=nextUniverse;
    for(const symbol of [...reports.keys()])if(!selectedSymbols.includes(symbol))reports.delete(symbol);
    for(const symbol of [...completed])if(!selectedSymbols.includes(symbol))completed.delete(symbol);
    if(handoff?.pruneUniverse)await handoff.pruneUniverse(selectedSymbols);
    await persist({force:true});
   };
   const processMarket=async(market,meta={})=>{
    if(runtimeSignal.aborted)return;
    const symbol=market?.symbol??meta.symbol;
    if(!isSupportedSymbol(symbol)||!selectedSymbols.includes(symbol))throw Object.assign(Error('Unexpected market symbol'),{code:'invalid_capture_symbol'});
    if(completed.has(symbol))return;
    currentSymbol=symbol;addErrors(meta.errors);
    let visible,nextState;
    try{
     if(!market||failedStatuses.has(market.status)||!market.quote)throw Object.assign(Error('Unavailable market'),{code:market?.issues?.[0]?.code||'symbol_unavailable'});
     if(!demoCapture&&(!Number.isSafeInteger(market.asOf)||market.asOf>now()+1000||now()-market.asOf>Math.max(180000,settings.pollSeconds*3000)))throw Object.assign(Error('Stale symbol'),{code:'stale_symbol'});
     const report=appendMarketHoursContext(await analyze({...market,previousState:state.symbols?.[symbol]||{},settings}),market);
     if(!report||report.symbol!==symbol||!Array.isArray(report.confirmed))throw Object.assign(Error('Invalid engine result'),{code:'invalid_engine_report'});
     const {nextState:next,...rest}=report;nextState=next;
     visible={...rest,asOf:rest.asOf??market.asOf,quote:rest.quote??clone(market.quote),...((market.definition||market.market||market.descriptor)?{market:clone(market.definition||market.market||market.descriptor)}:{}),...authority};
     if(failedStatuses.has(visible.status)){visible.confirmed=[];nextState=null;}
     visible=freshReport(visible);
     if(failedStatuses.has(visible.status))nextState=null;
    }catch(e){addErrors([{symbol,...reason(e)}]);visible=unavailable(symbol,now(),'Анализ прерван: '+errorCode(e));}
    reports.set(symbol,visible);completed.add(symbol);pendingCompleted++;
    const signals=(visible.confirmed||[]).map(found=>({...found,symbol,illustrative:mode==='demo'||found.illustrative===true,observedAt:now()}));
    await persist({symbolStates:nextState?{[symbol]:nextState}:{},signals,report:visible,market});
   };
   // Provider workers may finish together. Serialize durable updates and state reads.
   const serial=action=>{const pending=callbackQueue.then(action);callbackQueue=pending.catch(e=>{callbackFailure||=e;});return pending;};
   await publish(snapshotOf('scanning'));
   try{
    marketCapture=demoCapture?clone(demoCapture):await capture({symbols:settings.symbols,timeoutMs:settings.timeoutMs,countback:settings.countback,catalogRefreshSeconds:settings.catalogRefreshSeconds,requestConcurrency:settings.requestConcurrency,requestSpacingMs:settings.requestSpacingMs,signal:runtimeSignal,onUniverse:selection=>serial(()=>selectUniverse(selection)),onMarket:(market,meta)=>serial(()=>processMarket(market,meta)),onProgress:p=>dependencies.onProgress?.(p)});
    await callbackQueue;if(callbackFailure)throw callbackFailure;
    if(runtimeSignal.aborted){await persist({status:'stopped'});lastResult={snapshot:latest,newSignals:cycleNewSignals,cycles,status:'stopped'};break;}
    if(!Array.isArray(marketCapture?.markets))throw Object.assign(Error('Invalid market capture'),{code:'invalid_capture'});
    if(Array.isArray(marketCapture.selectedSymbols)){
     const selection=marketCapture.selectedSymbols;
     if(JSON.stringify(selection)!==JSON.stringify(selectedSymbols)||marketCapture.universe&&JSON.stringify(marketCapture.universe)!==JSON.stringify(universe))await selectUniverse({selectedSymbols:selection,universe:marketCapture.universe});
    }else if(settings.symbols==='all_crypto'&&!demoCapture&&!selectedSymbols.length)throw Object.assign(Error('Universe not discovered'),{code:'invalid_universe'});
    // Legacy providers without callbacks still require a fresh aggregate receipt.
    if(!demoCapture&&!completed.size&&(!Number.isSafeInteger(marketCapture.receivedAt)||marketCapture.receivedAt>now()+1000||now()-marketCapture.receivedAt>Math.max(180000,settings.pollSeconds*3000)))throw Object.assign(Error('Stale market capture'),{code:'stale_capture'});
    addErrors(marketCapture.errors);
    for(const symbol of selectedSymbols){
     if(completed.has(symbol))continue;
     const matches=marketCapture.markets.filter(m=>m.symbol===symbol);
     if(matches.length===1)await processMarket(matches[0]);
     else{reports.set(symbol,unavailable(symbol,now(),'Нет полного свежего набора свечей для инструмента.'));completed.add(symbol);}
    }
   }catch(e){
    await callbackQueue;addErrors([reason(e)]);if(Number.isFinite(e?.retryAfterMs))retryAfterMs=Math.max(retryAfterMs,Math.min(3600000,Math.max(0,e.retryAfterMs)));
    for(const symbol of selectedSymbols)if(!completed.has(symbol)){reports.set(symbol,unavailable(symbol,now(),'Нет свежего подтверждённого чтения рынка.'));completed.add(symbol);}
   }
   if(runtimeSignal.aborted){await persist({status:'stopped'});lastResult={snapshot:latest,newSignals:cycleNewSignals,cycles,status:'stopped'};break;}
   currentSymbol=null;
   const complete=selectedSymbols.filter(symbol=>!failedStatuses.has(freshReport(reports.get(symbol)||unavailable(symbol,now(),'' )).status)).length;
   failureStreak=selectedSymbols.length&&complete===selectedSymbols.length&&!errors.length?0:failureStreak+1;
   const status=complete===0?'offline':errors.length||complete<selectedSymbols.length?'degraded':'ok';
   await persist({status});
   lastResult={snapshot:latest,newSignals:cycleNewSignals,cycles,status:latest.status};
   if(once||maximumCycles!==null&&cycles>=maximumCycles)break;
   if(demoCapture){await wait(2147483647,runtimeSignal);break;}
   const backoff=Math.min(300000,settings.pollSeconds*1000*2**Math.min(5,Math.max(0,failureStreak-1)));
   await wait(Math.max(settings.pollSeconds*1000,backoff,retryAfterMs),runtimeSignal);
  }
  return lastResult||{snapshot:latest,newSignals:[],cycles,status:'stopped'};
 }finally{
  signal?.removeEventListener('abort',stop);controller.abort();
  try{if(handoff)await handoff.stop();}finally{
   try{if(dashboard)await dashboard.close();}finally{await store.release();}
  }
 }
}

export async function main(argv=process.argv.slice(2)){
 const options=parseOptions(argv);
 if(options.help){console.log('Guram Setup Scanner\nnode scanner/cli.mjs [--once | --demo] [--open] [--config FILE] [--data-dir DIR] [--port 8787] [--no-server]\n--self-test выполняет локальные проверки без сети. Торговые заявки не отправляются.');return 0;}
 if(Number(process.versions.node.split('.')[0])<24)throw Error('Установите Node.js 24 LTS или новее: https://nodejs.org/');
 if(options.selfTest){const files=(await fs.readdir(resolve(ROOT,'test'))).filter(f=>f.endsWith('.test.mjs')).map(f=>resolve(ROOT,'test',f));if(!files.length)throw Error('Не найдены локальные проверки.');return spawnSync(process.execPath,['--test',...files],{cwd:ROOT,stdio:'inherit',env:{...process.env}}).status??1;}
 const [{loadConfig},{createPublicMarketProvider},{analyzeSymbol},{renderDashboard}]=await Promise.all([import('./config.mjs'),import('./provider.mjs'),import('./engine.mjs'),import('./report.mjs')]);
 const settings=await loadConfig(options.config);if(options.port!==null)settings.port=options.port;
 const dataDir=options.dataDir||resolve(ROOT,options.demo?'data-demo':settings.dataDir||'data');
 const demoCapture=options.demo?JSON.parse(await fs.readFile(resolve(ROOT,'examples/demo-capture.json'),'utf8')):null;
 const provider=options.demo?null:createPublicMarketProvider(settings);
 const captureMarket=provider?.captureMarket.bind(provider);
 const handoff=!options.demo&&!options.once&&settings.codex?.enabled?await (await import('./handoff.mjs')).createHandoff({directory:resolve(dataDir,'handoff'),settings:settings.codex}):null;
 const controller=new AbortController(),stop=()=>controller.abort();process.once('SIGINT',stop);process.once('SIGTERM',stop);
 let printedProgressCycle=0,printedProgress=-1;
 try{
  console.log(options.demo?'Демонстрация на учебных свечах. Живых сигналов в этом режиме нет.':'Поиск сетапов во всех доступных криптопарах Bookflow. Локальные правила; торговые заявки не отправляются.');
  if(!options.demo)console.log('Первый сбор всех криптопар может занять около двух минут. Готовые инструменты появляются в панели по мере проверки.');
  if(handoff)console.log('Подтверждённые сетапы могут передаваться в локальный Codex. Эти обращения расходуют его лимиты; регулярный сбор свечей — нет.');
  console.log('Журнал и результаты: '+dataDir+'\nДля остановки нажмите Ctrl+C.');
  const result=await runScanner({settings,dataDir,once:options.once,demoCapture,serve:!options.once&&!options.noServer,openBrowser:options.open,signal:controller.signal},
   {captureMarket,analyzeSymbol,renderDashboard,handoff,onReady:url=>console.log('Панель: '+url),onSignal:s=>console.log('\x07Новый сетап: '+s.symbol+' '+(s.side||'')+' '+s.id),onStatus:s=>{
    if(s.status!=='scanning'){console.log(new Date().toLocaleTimeString('ru-RU')+' Цикл '+s.cycle+': '+s.status+', сетапов '+s.confirmedCount);return;}
    const {completed,total,currentSymbol}=s.progress;
    if(total&&(printedProgressCycle!==s.cycle||completed!==printedProgress&&(completed%10===0||completed===total))){console.log('Криптопары: '+completed+'/'+total+(currentSymbol?' · '+currentSymbol:''));printedProgressCycle=s.cycle;printedProgress=completed;}
   }});
  if(options.once)console.log('Отчёт: '+resolve(dataDir,'latest-report.html'));
  return options.once&&result.status!=='ok'?1:0;
 }finally{process.off('SIGINT',stop);process.off('SIGTERM',stop);}
}

if(process.argv[1]&&pathToFileURL(resolve(process.argv[1])).href===import.meta.url){main().then(code=>{process.exitCode=code;}).catch(error=>{console.error('Ошибка: '+error.message);process.exitCode=1;});}
