// Preserve original decimal strings from verified metadata where possible.
// A binary-float intermediate cannot be repaired after it has already rounded.
const MAX_INPUT_DIGITS = 256;
const MAX_INTEGER_DIGITS = 2048;
const MAX_EXPONENT = 100;

function boundedInteger(value) {
  if (typeof value !== 'bigint') throw new TypeError('Rational components must be BigInt.');
  if (value.toString().replace('-', '').length > MAX_INTEGER_DIGITS) {
    throw new RangeError('Exact decimal arithmetic exceeds the supported magnitude.');
  }
  return value;
}

function gcd(a, b) {
  a = a < 0n ? -a : a;
  b = b < 0n ? -b : b;
  while (b) [a, b] = [b, a % b];
  return a;
}

function normalize(n, d) {
  if (d === 0n) throw new RangeError('Division by zero.');
  if (d < 0n) { n = -n; d = -d; }
  const divisor = gcd(n, d);
  return { n: boundedInteger(n / divisor), d: boundedInteger(d / divisor) };
}

export function fraction(value) {
  if (typeof value === 'bigint') return normalize(boundedInteger(value), 1n);
  if (value && typeof value === 'object') {
    if (value.kind === 'exact_rational') {
      if (Object.keys(value).length !== 3 || !['numerator', 'denominator'].every(key =>
          typeof value[key] === 'string' && /^(?:0|-?[1-9]\d*)$/.test(value[key]) && value[key].replace('-', '').length <= MAX_INTEGER_DIGITS)) {
        throw new TypeError('Invalid serialized exact rational.');
      }
      return normalize(BigInt(value.numerator), BigInt(value.denominator));
    }
    if (typeof value.n !== 'bigint' || typeof value.d !== 'bigint') {
      throw new TypeError('An exact fraction requires BigInt n and d.');
    }
    return normalize(boundedInteger(value.n), boundedInteger(value.d));
  }
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) throw new TypeError('Decimal input must be finite.');
    value = String(value);
  }
  if (typeof value !== 'string') throw new TypeError('Decimal input must be a string, finite number, or fraction.');
  const match = /^([+-]?)(\d*)(?:\.(\d*))?(?:[eE]([+-]?\d+))?$/.exec(value.trim());
  if (!match || !(match[2] + (match[3] || '')).length) throw new TypeError('Invalid decimal input.');
  const whole = match[2] || '';
  const decimals = match[3] || '';
  if (whole.length + decimals.length > MAX_INPUT_DIGITS) throw new RangeError('Decimal input is too long.');
  if (match[4] && match[4].replace(/^[+-]/, '').length > 3) throw new RangeError('Decimal exponent is outside the supported range.');
  const exponent = Number(match[4] || 0);
  if (!Number.isInteger(exponent) || Math.abs(exponent) > MAX_EXPONENT) throw new RangeError('Decimal exponent is outside the supported range.');
  let n = BigInt(whole + decimals || '0') * (match[1] === '-' ? -1n : 1n);
  const scale = decimals.length - exponent;
  let d = 1n;
  if (scale >= 0) d = 10n ** BigInt(scale);
  else n *= 10n ** BigInt(-scale);
  return normalize(n, d);
}

export function add(a, b) { a = fraction(a); b = fraction(b); return normalize(a.n * b.d + b.n * a.d, a.d * b.d); }
export function sub(a, b) { a = fraction(a); b = fraction(b); return normalize(a.n * b.d - b.n * a.d, a.d * b.d); }
export function mul(a, b) { a = fraction(a); b = fraction(b); return normalize(a.n * b.n, a.d * b.d); }
export function div(a, b) { a = fraction(a); b = fraction(b); return normalize(a.n * b.d, a.d * b.n); }
export function abs(value) { const r = fraction(value); return { n: r.n < 0n ? -r.n : r.n, d: r.d }; }
export function cmp(a, b) {
  a = fraction(a); b = fraction(b);
  const difference = a.n * b.d - b.n * a.d;
  return difference < 0n ? -1 : difference > 0n ? 1 : 0;
}

function floorInteger(r) {
  const result = r.n / r.d;
  return r.n < 0n && r.n % r.d !== 0n ? result - 1n : result;
}
function ceilInteger(r) { return -floorInteger({ n: -r.n, d: r.d }); }

export function floorToStep(value, step) {
  if (cmp(step, 0) <= 0) throw new RangeError('Step must be positive.');
  return mul(floorInteger(div(value, step)), step);
}
export function ceilToStep(value, step) {
  if (cmp(step, 0) <= 0) throw new RangeError('Step must be positive.');
  return mul(ceilInteger(div(value, step)), step);
}
export function isStepAligned(value, step) {
  if (cmp(step, 0) <= 0) throw new RangeError('Step must be positive.');
  const ratio = div(value, step);
  return ratio.n % ratio.d === 0n;
}

function formatScaled(absoluteInteger, digits, negative) {
  let value = absoluteInteger.toString().padStart(digits + 1, '0');
  if (digits) {
    value = value.slice(0, -digits) + '.' + value.slice(-digits);
    value = value.replace(/0+$/, '').replace(/\.$/, '');
  }
  return (negative && absoluteInteger !== 0n ? '-' : '') + value;
}

// Display-only truncation. Use exact comparisons for all limits.
export function toDecimal(value, maxDigits = 18) {
  if (!Number.isInteger(maxDigits) || maxDigits < 0 || maxDigits > 512) throw new RangeError('Display precision must be between0 and512.');
  const r = fraction(value);
  const magnitude = r.n < 0n ? -r.n : r.n;
  return formatScaled(magnitude * 10n ** BigInt(maxDigits) / r.d, maxDigits, r.n < 0n);
}

// Broker-grid prices, quantities and finite monetary products are never silently
// rounded to zero by a display precision limit.
export function toExactDecimal(value, maxFractionDigits = 512) {
  if (!Number.isInteger(maxFractionDigits) || maxFractionDigits < 0 || maxFractionDigits > 2048) {
    throw new RangeError('Exact finite precision is outside the supported range.');
  }
  const r = fraction(value);
  let denominator = r.d;
  let twos = 0;
  let fives = 0;
  while (denominator % 2n === 0n) {
    denominator /= 2n;
    if (++twos > maxFractionDigits) throw new RangeError('Exact finite decimal exceeds the supported precision.');
  }
  while (denominator % 5n === 0n) {
    denominator /= 5n;
    if (++fives > maxFractionDigits) throw new RangeError('Exact finite decimal exceeds the supported precision.');
  }
  if (denominator !== 1n) throw new RangeError('Fraction has no finite decimal representation.');
  const digits = Math.max(twos, fives);
  const magnitude = (r.n < 0n ? -r.n : r.n) * 2n ** BigInt(digits - twos) * 5n ** BigInt(digits - fives);
  return formatScaled(magnitude, digits, r.n < 0n);
}

// fp9 notional / fp9 size need not have a terminating average price. Preserve
// that value through JSON checkpoints; display truncation never sizes a trade.
export function toExactValue(value) {
  const r = fraction(value);
  let rest = r.d;
  while (rest % 2n === 0n) rest /= 2n;
  while (rest % 5n === 0n) rest /= 5n;
  if (rest === 1n) return toExactDecimal(r);
  return { kind: 'exact_rational', numerator: r.n.toString(), denominator: r.d.toString() };
}
