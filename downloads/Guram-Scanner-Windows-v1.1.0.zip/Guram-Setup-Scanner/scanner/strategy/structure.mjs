/**
 * Pure candle geometry for analysis/replay. No signal from this module authorizes
 * an order. Times are numeric UTC milliseconds; closeTime is exclusive and a bar
 * is usable only when closeTime <= asOf. No input object is mutated.
 */

function inspectBars(bars, asOf) {
  if (!Array.isArray(bars)) throw new TypeError('bars must be an array');
  if (typeof asOf !== 'number' || Number.isNaN(asOf) || asOf === -Infinity) throw new TypeError('asOf must be a numeric timestamp');
  const closed = [];
  const unresolved = [];
  for (let index = 0; index < bars.length; index += 1) {
    const bar = bars[index];
    // Do not inspect an unfinished bar's prices or allow it into any window.
    if (bar?.forming === true || bar?.frozenForming === true || bar?.formingObservation === true ||
        bar && Number.isFinite(bar.closeTime) && bar.closeTime > asOf) continue;
    if (!bar || !['openTime', 'closeTime', 'open', 'high', 'low', 'close'].every(key => typeof bar[key] === 'number' && Number.isFinite(bar[key])) ||
        !Number.isSafeInteger(bar.openTime) || !Number.isSafeInteger(bar.closeTime) || bar.closeTime <= bar.openTime ||
        bar.high < Math.max(bar.open, bar.close) || bar.low > Math.min(bar.open, bar.close) || bar.high < bar.low) {
      unresolved.push({ code: 'INVALID_BAR', index });
      continue;
    }
    const previous = closed.at(-1);
    if (previous && bar.openTime < previous.bar.closeTime) {
      unresolved.push({ code: 'UNSORTED_OR_OVERLAPPING_BAR', index });
      continue;
    }
    const item = { bar, index, bodyHigh: Math.max(bar.open, bar.close), bodyLow: Math.min(bar.open, bar.close) };
    if (previous && !consecutive(previous, item)) unresolved.push({ code: 'NON_CONSECUTIVE_BARS', previousIndex: previous.index, index });
    closed.push(item);
  }
  return { closed, unresolved };
}

function consecutive(a, b) {
  return b.index === a.index + 1 && a.bar.closeTime === b.bar.openTime &&
    a.bar.closeTime - a.bar.openTime === b.bar.closeTime - b.bar.openTime;
}

function contiguous(items) {
  return items.every((item, index) => index === 0 || consecutive(items[index - 1], item));
}

/** D199: strict Williams wick geometry, central BODY edge as the marked level.
 * The export name is retained for compatibility with earlier body-level clients.
 * Equal wick extremes exclude a pivot; equal body edges do not. */
export function detectBodyFractals(bars, { asOf = Infinity, leftBars = 2, rightBars = 2 } = {}) {
  if (leftBars !== 2 || rightBars !== 2) throw new RangeError('Only the approved wick-fractal 2+1+2 window is supported');
  const { closed, unresolved } = inspectBars(bars, asOf);
  const events = [];
  for (let center = leftBars; center < closed.length - rightBars; center += 1) {
    const window = closed.slice(center - leftBars, center + rightBars + 1);
    if (!contiguous(window)) continue;
    const pivot = closed[center];
    const neighbors = window.filter((_, index) => index !== leftBars);
    for (const type of ['high', 'low']) {
      const field = type === 'high' ? 'high' : 'low';
      const price = pivot[type === 'high' ? 'bodyHigh' : 'bodyLow'];
      const wickExtreme = pivot.bar[field];
      const better = (a, b) => type === 'high' ? a > b : a < b;
      if (!neighbors.every(item => better(wickExtreme, item.bar[field]))) continue;
      const event = {
        id: `fractal:${type}:${pivot.bar.openTime}:D199`,
        type,
        price,
        pivotIndex: pivot.index,
        pivotOpenTime: pivot.bar.openTime,
        pivotCloseTime: pivot.bar.closeTime,
        availableAt: window.at(-1).bar.closeTime,
        rawHigh: pivot.bar.high,
        rawLow: pivot.bar.low,
        hasWindowTies: false,
        geometry: 'strict-wick-2+1+2',
        geometryDecisionId: 'D199-fractal-wick-geometry-with-central-body-pool-level',
        levelBasis: 'candle_body',
        candle: { ...pivot.bar },
      };
      events.push(event);
    }
  }
  return { events, unresolved };
}

/** Strict positive three-candle wick gaps, not an impulse or merged-zone filter. */
export function detectFvgs(bars, { asOf = Infinity } = {}) {
  const { closed, unresolved } = inspectBars(bars, asOf);
  const events = [];
  for (let index = 2; index < closed.length; index += 1) {
    const window = closed.slice(index - 2, index + 1);
    if (!contiguous(window)) continue;
    const [first, , third] = window.map(item => item.bar);
    let direction;
    let lower;
    let upper;
    if (first.high < third.low) { direction = 'bullish'; lower = first.high; upper = third.low; }
    else if (first.low > third.high) { direction = 'bearish'; lower = third.high; upper = first.low; }
    else continue;
    events.push({
      id: `fvg:${direction}:${first.openTime}:${third.closeTime}`,
      direction, lower, upper, midpoint: lower + (upper - lower) / 2,
      firstOpenTime: first.openTime, thirdCloseTime: third.closeTime,
      formedAt: third.closeTime, availableAt: third.closeTime,
      firstIndex: window[0].index, thirdIndex: window[2].index,
    });
  }
  return { events, unresolved };
}

function validateFractalEvents(fractalEvents, asOf, unresolved) {
  const result = [];
  for (const [index, event] of fractalEvents.entries()) {
    if (!event || !['high', 'low'].includes(event.type) || !Number.isFinite(event.price) || !Number.isFinite(event.availableAt)) {
      unresolved.push({ code: 'INVALID_FRACTAL_EVENT', eventIndex: index });
      continue;
    }
    if (event.availableAt > asOf) continue;
    if (Number.isFinite(event.pivotCloseTime) && event.pivotCloseTime > event.availableAt) {
      unresolved.push({ code: 'BACKDATED_FRACTAL_EVENT', eventIndex: index });
      continue;
    }
    result.push({ ...event, id: event.id ?? `fractal:${event.type}:${event.pivotOpenTime ?? event.availableAt}:${index}` });
  }
  return result.sort((a, b) => a.availableAt - b.availableAt || (a.pivotOpenTime ?? 0) - (b.pivotOpenTime ?? 0));
}

/**
 * One completed-close break per reference fractal. Latest confirmed references
 * update while waiting. A simultaneous newly-confirmed pivot is not silently
 * prioritized when it changes whether a break would be reported.
 */
export function detectStructureBreaks(bars, { asOf = Infinity, fractalEvents } = {}) {
  const inspected = inspectBars(bars, asOf);
  const unresolved = [...inspected.unresolved];
  const detected = fractalEvents === undefined ? detectBodyFractals(bars, { asOf }) : null;
  if (fractalEvents !== undefined && !Array.isArray(fractalEvents)) throw new TypeError('fractalEvents must be an array');
  if (detected) unresolved.push(...detected.unresolved.filter(item => !['INVALID_BAR', 'UNSORTED_OR_OVERLAPPING_BAR', 'NON_CONSECUTIVE_BARS'].includes(item.code)));
  const pivots = validateFractalEvents(fractalEvents ?? detected.events, asOf, unresolved);
  const events = [];
  const emitted = new Set();
  const latest = { high: null, low: null };
  let cursor = 0;
  let previousBar = null;
  let segmentStart = -Infinity;
  for (const item of inspected.closed) {
    const { bar, index } = item;
    if (previousBar && !consecutive(previousBar, item)) {
      // Missing candles could hide a newer structural reference. Keep the gap
      // explicit and wait for a reference confirmed in the new contiguous run.
      latest.high = null; latest.low = null;
      segmentStart = bar.openTime;
    }
    const eligibleInSegment = pivot => segmentStart === -Infinity ||
      (Number.isFinite(pivot.pivotOpenTime) && pivot.pivotOpenTime >= segmentStart);
    while (cursor < pivots.length && pivots[cursor].availableAt < bar.closeTime) {
      const pivot = pivots[cursor++];
      if (eligibleInSegment(pivot)) latest[pivot.type] = pivot;
    }
    const sameClose = [];
    while (cursor < pivots.length && pivots[cursor].availableAt === bar.closeTime) {
      const pivot = pivots[cursor++];
      if (eligibleInSegment(pivot)) sameClose.push(pivot);
    }
    for (const type of ['high', 'low']) {
      const oldReference = latest[type];
      const sameType = sameClose.filter(pivot => pivot.type === type);
      const newReference = sameType.at(-1) ?? oldReference;
      const broken = reference => Boolean(reference && !emitted.has(reference.id) &&
        (type === 'high' ? bar.close > reference.price : bar.close < reference.price));
      const oldBreak = broken(oldReference);
      const newBreak = broken(newReference);
      if (sameType.length > 1 && new Set(sameType.map(pivot => pivot.price)).size > 1) {
        unresolved.push({ code: 'SIMULTANEOUS_REFERENCE_SELECTION', type, availableAt: bar.closeTime, barIndex: index, candidateIds: sameType.map(pivot => pivot.id) });
        continue;
      }
      if (sameType.length && oldReference?.id !== newReference?.id && (oldBreak || newBreak)) {
        unresolved.push({
          code: 'SAME_CLOSE_REFERENCE_PRIORITY', type, availableAt: bar.closeTime, barIndex: index,
          priorReferenceId: oldReference?.id ?? null, newReferenceId: newReference.id,
          priorReferencePrice: oldReference?.price ?? null, newReferencePrice: newReference.price,
          wouldBreakPriorReference: oldBreak, wouldBreakNewReference: newBreak,
        });
        continue;
      }
      if (!oldBreak) continue;
      emitted.add(oldReference.id);
      events.push({
        id: `break:${type === 'high' ? 'up' : 'down'}:${bar.closeTime}:${oldReference.id}`,
        direction: type === 'high' ? 'up' : 'down',
        availableAt: bar.closeTime, closeTime: bar.closeTime, barIndex: index,
        closePrice: bar.close, referenceFractalId: oldReference.id,
        referencePrice: oldReference.price, referenceAvailableAt: oldReference.availableAt,
      });
    }
    for (const pivot of sameClose) latest[pivot.type] = pivot;
    previousBar = item;
  }
  return { events, unresolved };
}

/**
 * An observed-price test, not OHLC reconstruction of when the sweep happened.
 * pool accepts {side:'upper'|'lower',bodyEdge,rawHigh/rawLow}; a detected fractal
 * ({type:'high'|'low',price,candle,rawHigh,rawLow}) is also accepted.
 * qualified:null means that the zero-wick case has no approved interpretation.
 */
export function classifySweep(pool, price) {
  if (!pool || typeof pool !== 'object' || typeof price !== 'number' || !Number.isFinite(price)) throw new TypeError('A pool and finite observed price are required');
  const side = pool.side ?? (pool.type === 'high' ? 'upper' : pool.type === 'low' ? 'lower' : null);
  if (!['upper', 'lower'].includes(side)) throw new TypeError('pool.side must be upper or lower');
  const edge = pool.bodyEdge ?? pool.price ?? (side === 'upper' ? pool.bodyTop : pool.bodyBottom) ??
    (pool.candle ? (side === 'upper' ? Math.max(pool.candle.open, pool.candle.close) : Math.min(pool.candle.open, pool.candle.close)) : undefined);
  const tip = side === 'upper' ? (pool.rawHigh ?? pool.candle?.high) : (pool.rawLow ?? pool.candle?.low);
  if (![edge, tip].every(value => typeof value === 'number' && Number.isFinite(value)) || (side === 'upper' ? tip < edge : tip > edge)) throw new TypeError('Pool wick geometry is invalid');
  if (pool.swept === true || pool.state === 'swept' || pool.status === 'swept') return { qualified: false, kind: null, reason: 'already-swept', unresolved: [] };
  const full = side === 'upper' ? price > tip : price < tip;
  const midpoint = edge + (tip - edge) / 2;
  if (full) return { qualified: true, kind: 'full', side, midpoint, unresolved: [] };
  if (tip === edge) return { qualified: null, kind: null, side, midpoint, unresolved: [{ code: 'ZERO_LENGTH_WICK', side }] };
  const partial = side === 'upper' ? price >= midpoint : price <= midpoint;
  return { qualified: partial, kind: partial ? 'half-wick' : null, side, midpoint, unresolved: [] };
}
