/**
 * Full session windows for the course's local-clock profile. These are analysis
 * windows, not exchange opening hours or kill zones. Dates are calendar dates;
 * this profile does not silently impose a holiday/weekend calendar.
 *
 * Intervals are [start, end), in UTC milliseconds. IANA zones independently
 * determine each day's offsets; Moscow is only a display zone in the course.
 */
const DAY = 86_400_000;
const SOURCE = 'course-amd:full-session-local-clock-v1';

export const SESSION_DEFINITIONS = Object.freeze([
  Object.freeze({ session: 'tokyo', timeZone: 'Asia/Tokyo', openHour: 9, closeHour: 18 }),
  Object.freeze({ session: 'london', timeZone: 'Europe/London', openHour: 8, closeHour: 17 }),
  Object.freeze({ session: 'new-york', timeZone: 'America/New_York', openHour: 8, closeHour: 17 }),
]);

const formatters = new Map(SESSION_DEFINITIONS.map(({ timeZone }) => [
  timeZone,
  new Intl.DateTimeFormat('en-GB', {
    timeZone, year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23',
  }),
]));

function timestamp(value, name) {
  if (!Number.isSafeInteger(value) || !Number.isFinite(new Date(value).getTime())) {
    throw new TypeError(`${name} must be an integer UTC timestamp in milliseconds`);
  }
  return value;
}

function localParts(value, timeZone) {
  const parts = formatters.get(timeZone).formatToParts(value);
  return Object.fromEntries(parts.filter(({ type }) => type !== 'literal')
    .map(({ type, value: part }) => [type, Number(part)]));
}

function localClockToUtc(date, hour, timeZone) {
  const [year, month, day] = date.split('-').map(Number);
  const wallClock = Date.UTC(year, month - 1, day, hour);
  let candidate = wallClock;
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const part = localParts(candidate, timeZone);
    const wallAtCandidate = Date.UTC(part.year, part.month - 1, part.day,
      part.hour, part.minute, part.second);
    const next = candidate + wallClock - wallAtCandidate;
    if (next === candidate) return next;
    candidate = next;
  }
  // These session boundaries (08/09/17/18 local) avoid DST's ambiguous hours.
  // Refuse a future timezone change that makes that assumption invalid.
  throw new RangeError(`Cannot resolve unambiguous local session boundary: ${date} ${hour}:00 ${timeZone}`);
}

/** Return full windows that intersect [from,to), ordered by start then id. */
export function buildSessionWindows({ from, to } = {}) {
  timestamp(from, 'from');
  timestamp(to, 'to');
  if (to < from) throw new RangeError('to must be greater than or equal to from');
  if (to === from) return [];
  // Iterate one day beyond either end to catch sessions crossing UTC midnight.
  const firstDate = Math.floor(from / DAY) * DAY - DAY;
  const lastDate = Math.floor((to - 1) / DAY) * DAY + DAY;
  const windows = [];
  for (let dateMs = firstDate; dateMs <= lastDate; dateMs += DAY) {
    const date = new Date(dateMs).toISOString().slice(0, 10);
    for (const definition of SESSION_DEFINITIONS) {
      const { session, timeZone, openHour, closeHour } = definition;
      const start = localClockToUtc(date, openHour, timeZone);
      const end = localClockToUtc(date, closeHour, timeZone);
      if (start < to && end > from) windows.push({
        id: `${session}:${date}`, session, date, timeZone,
        start, end, availableAt: end, source: SOURCE,
        calendar: 'daily-no-holiday-filter',
      });
    }
  }
  return windows.sort((a, b) => a.start - b.start || a.id.localeCompare(b.id));
}

function validatedBars(bars) {
  if (!Array.isArray(bars)) throw new TypeError('bars must be an array');
  return bars.map((bar, index) => {
    if (!bar || typeof bar !== 'object') throw new TypeError(`bars[${index}] must be an object`);
    timestamp(bar.openTime, `bars[${index}].openTime`);
    timestamp(bar.closeTime, `bars[${index}].closeTime`);
    if (bar.closeTime <= bar.openTime) throw new RangeError(`bars[${index}] has a non-positive duration`);
    for (const field of ['open', 'high', 'low', 'close']) {
      if (!Number.isFinite(bar[field])) throw new TypeError(`bars[${index}].${field} must be finite`);
    }
    if (bar.high < Math.max(bar.open, bar.close) || bar.low > Math.min(bar.open, bar.close)
        || bar.low > bar.high) {
      throw new RangeError(`bars[${index}] has inconsistent OHLC values`);
    }
    return bar;
  }).sort((a, b) => a.openTime - b.openTime || a.closeTime - b.closeTime);
}

/**
 * Final extrema are returned only after the full session has ended and bars
 * cover it exactly, without gaps, overlaps, or boundary-straddling candles.
 * `basis` is mandatory: no unconfirmed wick/body convention is chosen silently.
 * The range is inferred from visible input bars; future-open bars cannot extend
 * it or change past extrema. Unresolved entries intentionally omit high/low.
 */
export function completedSessionLevels(bars, { asOf, basis } = {}) {
  timestamp(asOf, 'asOf');
  if (basis !== 'body' && basis !== 'wick') {
    throw new TypeError('basis must explicitly be body or wick');
  }
  const visibleBars = validatedBars(bars).filter(bar => bar.openTime < asOf);
  const result = { levels: [], unresolved: [] };
  if (visibleBars.length === 0) return result;
  const from = visibleBars[0].openTime;
  const to = Math.min(asOf, Math.max(...visibleBars.map(bar => bar.closeTime)));
  for (const window of buildSessionWindows({ from, to })) {
    const contributing = visibleBars.filter(bar => bar.openTime < window.end && bar.closeTime > window.start);
    const reject = (reason) => result.unresolved.push({
      ...window, basis, status: 'unresolved', reason, barCount: contributing.length,
    });
    if (window.end > asOf) {
      reject('session-not-ended');
      continue;
    }
    if (contributing.length === 0) {
      reject('missing-coverage');
      continue;
    }
    if (contributing.some(bar => bar.closeTime > asOf || bar.closed === false || bar.isClosed === false)) {
      reject('unclosed-bars');
      continue;
    }
    if (contributing.some(bar => bar.openTime < window.start || bar.closeTime > window.end)) {
      reject('boundary-crossing-bars');
      continue;
    }
    let cursor = window.start;
    let coverageError;
    for (const bar of contributing) {
      if (bar.openTime !== cursor) {
        coverageError = bar.openTime < cursor ? 'overlapping-bars'
          : cursor === window.start ? 'truncated-start' : 'missing-bars';
        break;
      }
      cursor = bar.closeTime;
    }
    if (!coverageError && cursor !== window.end) coverageError = 'truncated-end';
    if (coverageError) {
      reject(coverageError);
      continue;
    }
    const high = Math.max(...contributing.map(bar => basis === 'wick' ? bar.high : Math.max(bar.open, bar.close)));
    const low = Math.min(...contributing.map(bar => basis === 'wick' ? bar.low : Math.min(bar.open, bar.close)));
    result.levels.push({
      ...window, high, low, basis, status: 'complete', barCount: contributing.length,
    });
  }
  return result;
}
