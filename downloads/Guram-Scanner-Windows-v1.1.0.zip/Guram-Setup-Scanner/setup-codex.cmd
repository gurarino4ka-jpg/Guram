@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 goto node_missing
where codex >nul 2>nul
if errorlevel 1 goto install
goto login
:install
where npm >nul 2>nul
if errorlevel 1 goto node_missing
echo Установка официального Codex CLI из npm: @openai/codex.
call npm install -g @openai/codex
if errorlevel 1 goto failed
:login
echo Вход в Codex через ваш аккаунт ChatGPT.
echo Подтвердите вход в открывшемся браузере.
call codex login
if errorlevel 1 goto failed
call codex login status
if errorlevel 1 goto failed
call codex login status 2>&1 | findstr /i "ChatGPT" >nul
if errorlevel 1 goto chatgpt_required
echo.
echo Codex подключён. Теперь запустите start-scanner.cmd.
echo Найденные сетапы передаются для проверки, максимум 8 обращений в день.
echo Эти обращения расходуют лимиты Codex. Программа не подключает демо-браузер.
set "scanner_exit=0"
goto finish
:node_missing
echo Установите Node.js 24 LTS с https://nodejs.org/ и повторите запуск.
set "scanner_exit=1"
goto finish
:chatgpt_required
echo Требуется вход именно через ChatGPT, а не API-ключ.
echo Смотрите CODEX-HANDOFF.md для переключения способа входа.
set "scanner_exit=1"
goto finish
:failed
echo Не удалось установить Codex или завершить вход. Сохраните текст ошибки.
echo Сканер может работать без Codex; заявки останутся в локальной очереди.
set "scanner_exit=1"
:finish
echo.
pause
endlocal & exit /b %scanner_exit%
