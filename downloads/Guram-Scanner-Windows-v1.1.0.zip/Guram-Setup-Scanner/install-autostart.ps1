$ErrorActionPreference = 'Stop'
$scannerDirectory = $PSScriptRoot
$scannerNode = (Get-Command node.exe -ErrorAction Stop).Source
$scannerCli = Join-Path $scannerDirectory 'scanner\cli.mjs'
if (-not (Test-Path -LiteralPath $scannerCli -PathType Leaf)) { throw 'Extract the whole ZIP before installing autostart.' }
$scannerMajor = & $scannerNode -p "Number(process.versions.node.split('.')[0])"
if ([int]$scannerMajor -lt 24) { throw 'Node.js 24 or newer is required.' }
$scannerUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$scannerAction = New-ScheduledTaskAction -Execute $scannerNode -Argument ('"' + $scannerCli + '"') -WorkingDirectory $scannerDirectory
$scannerTrigger = New-ScheduledTaskTrigger -AtLogOn -User $scannerUser
$scannerPrincipal = New-ScheduledTaskPrincipal -UserId $scannerUser -LogonType Interactive -RunLevel Limited
$scannerSettings = New-ScheduledTaskSettingsSet -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew
Register-ScheduledTask -TaskName 'GuramSetupScanner' -Action $scannerAction -Trigger $scannerTrigger -Principal $scannerPrincipal -Settings $scannerSettings -Description 'Local public-market setup scanner; no direct trading requests.' -Force | Out-Null
Write-Host 'Autostart installed for the current Windows user: GuramSetupScanner.'
Write-Host 'The program will start at the next Windows sign-in. Run start-scanner.cmd to start now.'
