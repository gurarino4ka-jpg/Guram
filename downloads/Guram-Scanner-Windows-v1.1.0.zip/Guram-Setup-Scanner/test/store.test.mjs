import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {ScannerStore} from '../scanner/store.mjs';

async function fixture(t,options={}){
 const directory=await fs.mkdtemp(join(tmpdir(),'guram scanner store '));
 t.after(()=>fs.rm(directory,{recursive:true,force:true}));
 return {directory,store:new ScannerStore(directory,options),read:name=>fs.readFile(join(directory,name),'utf8'),write:(name,value)=>fs.writeFile(join(directory,name),value)};
}
const snapshot=(status='ready')=>({status,generatedAt:12345,markets:[]});

test('state and signal deduplication survive restart without losing per-symbol strategy state',async t=>{
 const f=await fixture(t);await f.store.acquire();
 const first=await f.store.commit({symbolStates:{BTC:{lastSweepId:'sweep-1'}},signals:[{id:'signal-1',symbol:'BTC'}],snapshot:snapshot()});
 assert.equal(first.newSignals.length,1);assert.equal(first.state.sequence,1);await f.store.release();
 const restart=new ScannerStore(f.directory);await restart.acquire();
 const second=await restart.commit({symbolStates:{ETH:{ready:true}},signals:[{id:'signal-1',symbol:'BTC'},{id:'signal-2',symbol:'ETH'}],snapshot:snapshot()});
 assert.deepEqual(second.newSignals.map(s=>s.id),['signal-2']);assert.equal(second.state.symbols.BTC.lastSweepId,'sweep-1');assert.equal(second.state.symbols.ETH.ready,true);
 assert.equal(second.state.history.length,2);assert.equal((await restart.latestSnapshot()).history.length,2);await restart.release();
});

test('expanded crypto state survives restart alongside prior state and historical signals',async t=>{
 const f=await fixture(t);await f.store.acquire();
 await f.store.commit({symbolStates:{BTC:{lastSweepId:'prior'}},signals:[{id:'old-btc',symbol:'BTC'}],snapshot:snapshot()});
 await f.store.commit({symbolStates:{BNB:{lastSweepId:'bnb'},ADA:{lastSweepId:'ada'},'0G':{lastSweepId:'zero'}},signals:[{id:'new-0g',symbol:'0G'}],snapshot:snapshot()});
 await f.store.release();
 const restart=new ScannerStore(f.directory);await restart.acquire();const state=await restart.readState();
 assert.deepEqual(Object.keys(state.symbols).sort(),['0G','ADA','BNB','BTC']);
 assert.equal(state.symbols.BTC.lastSweepId,'prior');assert.equal(state.symbols.BNB.lastSweepId,'bnb');assert.equal(state.symbols.ADA.lastSweepId,'ada');assert.equal(state.symbols['0G'].lastSweepId,'zero');
 assert.deepEqual(state.history.map(s=>s.id),['old-btc','new-0g']);
 assert.equal((await restart.commit({signals:[{id:'new-0g',symbol:'0G'}],snapshot:snapshot()})).newSignals.length,0);
 for(const key of ['../BTC','BTC/USD','btc','__proto__'])await assert.rejects(restart.commit({symbolStates:JSON.parse(JSON.stringify({[key]:{}})),snapshot:snapshot()}),{code:'invalid_store_commit'});
 await restart.release();
});

test('journal append newer than checkpoint is recovered after interrupted checkpoint replacement',async t=>{
 const f=await fixture(t);await f.store.acquire();await f.store.commit({signals:[{id:'old'}],snapshot:snapshot()});const old=await f.read('state.json');
 await f.store.commit({signals:[{id:'new'}],snapshot:snapshot('updated')});await f.write('state.json',old);await f.store.release();
 const recovered=await new ScannerStore(f.directory).readState();assert.equal(recovered.sequence,2);assert.deepEqual(recovered.seenSignalIds,['old','new']);
 assert.equal(JSON.parse(await f.read('state.json')).sequence,2);
});

test('durable first append restores absent checkpoint',async t=>{
 const f=await fixture(t);await f.store.acquire();await f.store.commit({snapshot:snapshot()});await fs.unlink(join(f.directory,'state.json'));await f.store.release();
 assert.equal((await new ScannerStore(f.directory).readState()).sequence,1);
});

test('torn trailing append blocks state use instead of treating the journal as empty',async t=>{
 const f=await fixture(t);await f.store.acquire();await f.store.commit({snapshot:snapshot()});await fs.appendFile(join(f.directory,'journal.jsonl'),'\u007b"sequence":2');
 await assert.rejects(f.store.readState(),{code:'store_journal_incomplete'});await f.store.release();
});

test('checkpoint without its authoritative journal is rejected',async t=>{
 const f=await fixture(t);await f.store.acquire();await f.store.commit({snapshot:snapshot()});await fs.unlink(join(f.directory,'journal.jsonl'));
 await assert.rejects(f.store.readState(),{code:'store_checkpoint_without_journal'});await f.store.release();
});

test('changed snapshot content in a journal record fails integrity validation',async t=>{
 const f=await fixture(t);await f.store.acquire();await f.store.commit({snapshot:snapshot()});const r=JSON.parse((await f.read('journal.jsonl')).trim());r.snapshot.status='forged';await f.write('journal.jsonl',JSON.stringify(r)+'\n');
 await assert.rejects(f.store.readState(),{code:'store_record_integrity_mismatch'});await f.store.release();
});

test('live process lock blocks a second scanner and cannot be released by a different store',async t=>{
 const f=await fixture(t);await f.store.acquire();const other=new ScannerStore(f.directory);await assert.rejects(other.acquire(),{code:'scanner_already_running'});
 await other.release();assert.ok(await f.read('scanner.lock'));await f.store.release();
});

test('a stale dead-process lock is recovered without deleting analysis state',async t=>{
 const f=await fixture(t);await f.store.acquire();await f.store.commit({signals:[{id:'keep-me'}],snapshot:snapshot()});await f.store.release();
 // Node supports at most signed 32-bit process IDs; this unused PID must be
 // established as absent before the fixture can represent a stale process.
 const dead=2_147_483_646;assert.throws(()=>process.kill(dead,0),e=>e.code==='ESRCH');
 await f.write('scanner.lock',JSON.stringify({schemaVersion:1,pid:dead,token:'dead-process',createdAt:0}));
 const restart=new ScannerStore(f.directory);await restart.acquire();assert.deepEqual((await restart.readState()).seenSignalIds,['keep-me']);await restart.release();
});

test('malformed locks and symlink data files are not removed or followed',async t=>{
 const f=await fixture(t);await f.write('scanner.lock','not-json');await assert.rejects(f.store.acquire(),{code:'invalid_store_lock'});assert.equal(await f.read('scanner.lock'),'not-json');
 await fs.unlink(join(f.directory,'scanner.lock'));await f.write('outside','[]');
 try{await fs.symlink(join(f.directory,'outside'),join(f.directory,'journal.jsonl'));}
 catch(error){if(process.platform==='win32'&&['EPERM','EACCES'].includes(error.code)){t.diagnostic('Windows does not permit creating a test symlink without Developer Mode; malformed-lock assertion still passed.');return;}throw error;}
 await assert.rejects(f.store.readState(),{code:'unsafe_store_file'});
});

test('periodic compaction bounds the journal while preserving restart deduplication',async t=>{
 const f=await fixture(t,{compactEvery:3});await f.store.acquire();
 for(let i=1;i<=8;i++)await f.store.commit({signals:[{id:'s'+i}],snapshot:snapshot()});
 const lines=(await f.read('journal.jsonl')).trim().split('\n');assert.ok(lines.length<3);assert.equal(JSON.parse(lines[0]).kind,'retained_checkpoint');await f.store.release();
 const restart=new ScannerStore(f.directory,{compactEvery:3});await restart.acquire();const r=await restart.commit({signals:[{id:'s1'},{id:'s9'}],snapshot:snapshot()});
 assert.deepEqual(r.newSignals.map(x=>x.id),['s9']);assert.equal(r.state.sequence,9);await restart.release();
});

test('owned state caching preserves bounded journal recovery and deduplication after restart',async t=>{
 const f=await fixture(t,{cacheOwnedState:true,compactEvery:8});await f.store.acquire();await f.store.readState();
 let journalReads=0;const originalRead=f.store.readFile.bind(f.store);f.store.readFile=async name=>{if(name==='journal.jsonl')journalReads++;return originalRead(name);};
 for(let i=1;i<=19;i++){
  const committed=await f.store.commit({symbolStates:{'0G':{visits:i}},signals:[{id:'cached-signal-'+i,symbol:'0G'}],snapshot:snapshot()});
  // Callers may annotate results without changing the durable cached head.
  committed.newSignals[0].id='caller-only';committed.state.symbols['0G'].visits=-1;
  assert.ok((await f.read('journal.jsonl')).trim().split('\n').length<8);
 }
 assert.equal(journalReads,0);await f.store.release();
 // Simulate an interruption after the journal append but before the latest
 // checkpoint replacement: startup must validate and recover the journal head.
 const lines=(await f.read('journal.jsonl')).trim().split('\n'),older=JSON.parse(lines[0]);
 await f.write('state.json',JSON.stringify(older.kind==='retained_checkpoint'?older.record:older));
 const restart=new ScannerStore(f.directory,{cacheOwnedState:true,compactEvery:8});await restart.acquire();
 const recovered=await restart.readState();assert.equal(recovered.sequence,19);assert.equal(recovered.symbols['0G'].visits,19);assert.equal(recovered.history.length,19);assert.equal(recovered.history[0].id,'cached-signal-1');
 const next=await restart.commit({signals:[{id:'cached-signal-1',symbol:'0G'},{id:'cached-signal-20',symbol:'0G'}],snapshot:snapshot()});
 assert.deepEqual(next.newSignals.map(signal=>signal.id),['cached-signal-20']);assert.equal(next.state.sequence,20);assert.equal(next.state.history.length,20);await restart.release();
});

test('owned cache invalidates after failed writes and reloads authoritative journal state',async t=>{
 const f=await fixture(t,{cacheOwnedState:true,compactEvery:8});await f.store.acquire();await f.store.commit({signals:[{id:'before-failure'}],snapshot:snapshot()});
 const originalAtomic=f.store.atomic.bind(f.store);let failOnce=true;
 f.store.atomic=async(name,value)=>{if(name==='state.json'&&failOnce){failOnce=false;throw Object.assign(new Error('local simulated interruption'),{code:'EIO'});}return originalAtomic(name,value);};
 await assert.rejects(f.store.commit({signals:[{id:'journal-recovered'}],snapshot:snapshot()}),{code:'EIO'});
 const next=await f.store.commit({signals:[{id:'journal-recovered'},{id:'after-failure'}],snapshot:snapshot()});
 assert.deepEqual(next.newSignals.map(signal=>signal.id),['after-failure']);assert.equal(next.state.sequence,3);assert.deepEqual(next.state.history.map(signal=>signal.id),['before-failure','journal-recovered','after-failure']);await f.store.release();
});

test('failed network cycle replaces active confirmed snapshot while signal history remains separately recorded',async t=>{
 const f=await fixture(t);await f.store.acquire();await f.store.commit({signals:[{id:'prior-signal'}],snapshot:{status:'ready',markets:[{symbol:'BTC',confirmed:[{id:'prior-signal'}]}]}});
 await f.store.commit({snapshot:{status:'offline',markets:[{symbol:'BTC',confirmed:[],issues:['network_error']}]}});
 const latest=await f.store.latestSnapshot();assert.equal(latest.status,'offline');assert.equal(latest.markets[0].confirmed.length,0);assert.equal(latest.history[0].id,'prior-signal');await f.store.release();
});
