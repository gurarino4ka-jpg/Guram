import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {renderDashboard} from '../scanner/report.mjs';
const snapshot = overrides => ({mode:'live',status:'ok',generatedAt:Date.now(),cycle:1,config:{pollSeconds:60,balanceUSD:10000,riskPercent:1},symbols:[{symbol:'BTC',status:'confirmed',asOf:Date.now(),price:74000,direction:'up',context:{daily:{direction:'up'},weekly:{direction:'down'}},confirmed:[{id:'btc-1',symbol:'BTC',side:'long',route:'midpoint',entry:74000,stopLoss:73900,takeProfit:74250,rr:2.5,riskUSD:100,quantity:1,evidence:{reference:'strict-wick-2+1+2'}}],watch:[],rejected:[],issues:[]}],history:[],...overrides});

test('fresh technical signal includes risk geometry and labels it as analysis rather than execution',()=>{
 const html=renderDashboard(snapshot());
 for(const text of ['BTC','74\u00a0000','Стоп','Тейк','RR','Расчётный риск','Середина FVG','не означает, что сделка открыта','Сканер формирует сигналы, а не ордера'])assert.ok(html.includes(text),text);
 assert.match(html,/<strong data-confirmed-count>1<\/strong><small>Совпадения/);
 assert.ok(!/https?:\/\/[^<\s]+\.(?:js|css)/.test(html));
});

for(const [name,overrides] of [['offline',{status:'offline'}],['stale',{generatedAt:Date.now()-600000}],['stopped',{status:'stopped'}]])test(`${name} data never renders an active green confirmation`,()=>{
 const html=renderDashboard(snapshot(overrides));
 assert.match(html,/<body data-unavailable="true"/);
 assert.ok(html.includes('Сохранённый сигнал · актуальность не подтверждена'));
 assert.ok(!html.includes('class="pill found"'));
 assert.ok(html.includes('<strong data-confirmed-count>0</strong><small>Совпадения'));
});

test('malicious instrument names, evidence and signal IDs cannot inject HTML or close inline script',()=>{
 const data=snapshot();data.symbols[0].symbol='</script><img src=x onerror=alert(1)>';data.symbols[0].confirmed[0].id='</script><script>alert(1)</script>';data.symbols[0].confirmed[0].evidence={note:'<svg onload=alert(1)>'};
 const html=renderDashboard(data),scripts=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)];
 assert.equal(scripts.length,1);assert.ok(!html.includes('<img src=x'));assert.ok(!html.includes('<svg onload='));assert.ok(html.includes('&lt;svg'));
 assert.doesNotThrow(()=>new vm.Script(scripts[0][1]));
});

test('embedded client is valid JavaScript and reads only local report/status endpoints',()=>{
 const html=renderDashboard(snapshot()),script=html.match(/<script>([\s\S]*?)<\/script>/)[1];
 assert.doesNotThrow(()=>new vm.Script(script));assert.ok(script.includes("fetch('/status'"));assert.ok(script.includes("fetch('/'"));
 assert.ok(script.includes("Notification.permission==='default'"));assert.ok(script.includes("button.addEventListener('click'"));
 assert.ok(script.includes('checkAge();'));assert.ok(script.includes("storage.get('guram:seen')"));
});

test('demo signals and history do not become executed trades',()=>{
 const s=snapshot({mode:'demo'});s.history=[s.symbols[0].confirmed[0]];const html=renderDashboard(s);
 assert.ok(html.includes('Учебный режим: искусственные свечи'));assert.ok(html.includes('Учебный пример · не реальный сигнал'));
 assert.ok(html.includes('Ранее найдено · не исполнено'));assert.ok(html.includes('полученную прибыль'));
});

test('Codex handoff status clearly distinguishes review from demo execution',()=>{
 const html=renderDashboard(snapshot({handoff:{mode:'review',status:'queued',queuedCount:2,callsToday:1,error:'CLI <not found>'}}));
 assert.ok(html.includes('Проверка в Codex'));assert.ok(html.includes('CLI &lt;not found&gt;'));assert.ok(html.includes('отдельно нужен настроенный доступ к браузеру UpScale'));
});

test('all venue pairs remain searchable with dynamic counts, native tickers and exclusions',()=>{
 const data=snapshot(),base=data.symbols[0];
 data.config.symbols='all_crypto';
 data.symbols=Array.from({length:103},(_,i)=>({...base,symbol:i===102?'0G':`COIN${i}`,confirmed:[],status:'watching'}));
 data.universe={status:'ready',observedAt:Date.now(),totalCrypto:106,symbols:data.symbols.map(r=>r.symbol),markets:data.symbols.map(r=>({symbol:r.symbol,ticker:r.symbol==='0G'?'0G/USD':`${r.symbol}/USDT`,displayName:r.symbol==='0G'?'Zero Gravity':r.symbol})),excluded:[{symbol:'CLOSED',ticker:'CLOSED/USDT',reason:'closed'},{symbol:'PAUSED',reason:'paused'},{symbol:'EXIT',reason:'closeOnly'}]};
 data.progress={completed:51,total:103,currentSymbol:'COIN51'};
 const html=renderDashboard(data);
 assert.equal([...html.matchAll(/<details class="market-card[^\"]*" data-symbol=/g)].length,103);
 for(const text of ['Вся доступная криптовалюта','Доступно для поиска: 103','Криптоинструментов в каталоге: 106','Исключено: 3','Проверено в цикле <b>51 / 103','COIN51','Все пары · 103','0G/USD','Zero Gravity','Закрыт','Приостановлен','Только закрытие позиций'])assert.ok(html.includes(text),text);
 assert.ok(!html.includes('0G/USDT'));
 assert.ok(html.indexOf('<section class="fresh-setups">')<html.indexOf('<section class="pair-list">'));
 for(const id of ['pair-search','pair-filter','page-info'])assert.ok(html.includes(`id="${id}"`));
});

test('a fresh snapshot does not promote a stale pair while other pairs are scanning',()=>{
 const data=snapshot({status:'scanning'}),old={...data.symbols[0],asOf:Date.now()-600000};
 data.symbols=[old,{...data.symbols[0],symbol:'ETH',confirmed:[{...old.confirmed[0],id:'eth-fresh',symbol:'ETH'}]}];
 const html=renderDashboard(data);
 assert.match(html,/<body data-unavailable="false"/);
 assert.match(html,/<strong data-confirmed-count>1<\/strong>/);
 assert.match(html,/class="market-card data-stale" data-symbol="BTC" data-state="unavailable"/);
 assert.match(html,/data-current-symbol="BTC" hidden/);
 assert.match(html,/data-current-symbol="ETH">/);
 assert.ok(html.includes('Сохранённый сигнал · актуальность не подтверждена'));
});

test('missing observations and future pair snapshots cannot count as current signals',()=>{
 for(const asOf of [null,undefined,Date.now()+60000]){
  const data=snapshot();data.symbols[0].asOf=asOf;
  const html=renderDashboard(data);
  assert.match(html,/<strong data-confirmed-count>0<\/strong>/);
  assert.match(html,/data-symbol="BTC" data-state="unavailable"/);
 }
});

test('the catalog includes pending pairs before their first capture finishes',()=>{
 const data=snapshot({symbols:[],universe:{status:'ready',observedAt:Date.now(),symbols:['NEW'],markets:[{symbol:'NEW',ticker:'NEW/USD'}]},progress:{completed:0,total:1,currentSymbol:'NEW'}});
 const html=renderDashboard(data);
 assert.match(html,/data-symbol="NEW" data-state="unavailable"/);
 assert.ok(html.includes('NEW/USD'));
 assert.ok(html.includes('Ожидает проверки'));
 assert.ok(html.includes('ещё не проверена'));
 assert.ok(!html.includes('01.01,'));
});

test('small crypto prices retain distinct entry, stop and target levels',()=>{
 const data=snapshot(),base=data.symbols[0];
 data.symbols[0]={...base,symbol:'FLOKI',price:0.000020464,market:{ticker:'FLOKI/USD'},confirmed:[{...base.confirmed[0],symbol:'FLOKI',entry:0.000020464,stopLoss:0.000020319,takeProfit:0.0000208265}]};
 const html=renderDashboard(data);
 for(const value of ['0,000020464','0,000020319','0,0000208265'])assert.ok(html.includes(value),value);
});
