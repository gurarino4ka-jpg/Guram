import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {createHandoff,resolveCodexCommand,runCodexProcess} from '../scanner/handoff.mjs';

const T=Date.parse('2026-11-11T18:00:00Z'),hash=x=>createHash('sha256').update(JSON.stringify(x)).digest('hex');
function fixture(id='BTC-sweep-1',at=T){const signal={id,symbol:'BTC',route:'sweep_m30',side:'long',entry:100,stopLoss:99,takeProfit:103,rr:3,riskUSD:100,quantity:100,availableAt:at,evidence:{sweep:{at},break:{at}}};return{signal,report:{symbol:'BTC',asOf:at,price:100,direction:'up',confirmed:[signal],sourceHashes:['a'.repeat(64)],quote:{price:100,observedAt:at}}};}
function capturedFixture(){
 const f=fixture(),bars=Array.from({length:5},(_,i)=>({openTime:T-(5-i)*3600000,closeTime:T-(4-i)*3600000,open:100,high:i===2?120:101,low:99,close:100,volume:1}));
 f.signal.evidence.sweep.pool={id:'fractal:high:'+bars[2].openTime+':D199',timeframe:'60',pivotOpenTime:bars[2].openTime,availableAt:T,geometry:'strict-wick-2+1+2',price:100,rawHigh:120,rawLow:99};
 f.capture={asOf:T,receivedAt:T,markets:[{symbol:'BTC',asOf:T,sourceHashes:f.report.sourceHashes,quote:f.report.quote,streams:{'60':bars},forming:{'5':{openTime:T,closeTime:T+300000,open:100,high:101,low:99,close:100,observedAt:T,forming:true,frozenForming:true}}},{symbol:'ETH',asOf:T,privateAccount:'OTHER_SYMBOL_PRIVATE'}]};return f;
}
async function setup(t,changes={}){
 const directory=await fs.mkdtemp(join(tmpdir(),'scanner-handoff-'));t.after(()=>fs.rm(directory,{recursive:true,force:true}));let at=T,calls=[];
 const runCommand=async spec=>{calls.push(spec);if(spec.kind==='auth_status')return{started:true,exitCode:0,stdout:'Logged in using ChatGPT'};return{started:true,exitCode:0,lastMessage:JSON.stringify({status:'candidate_confirmed',reason:'Matched the enclosed source evidence; no order placed.',freshDataChecked:true,ordersSubmitted:0})};};
 const options={directory,settings:{enabled:true,cooldownSeconds:0,...changes.settings},now:()=>at,runCommand:changes.runCommand||runCommand,resolveCommand:changes.resolveCommand||(async()=>({file:'codex',prefixArgs:[]}))};
 const handoff=await createHandoff(options);return{directory,handoff,options,calls,setNow:x=>{at=x;}};
}

test('matching confirmed source signal is queued once, including after restart',async t=>{
 const f=await setup(t),{signal,report}=fixture();assert.equal((await f.handoff.enqueue(signal,{report})).status,'queued');
 const restarted=await createHandoff(f.options);assert.equal((await restarted.enqueue(signal,{report})).status,'duplicate');assert.equal((await restarted.status()).queued,1);
});
test('parallel scanner instances preserve queue entries and deduplicate the same signal',async t=>{
 const f=await setup(t),other=await createHandoff(f.options),a=fixture('parallel-a'),b=fixture('parallel-b');
 const results=await Promise.all([f.handoff.enqueue(a.signal,{report:a.report}),other.enqueue(a.signal,{report:a.report}),other.enqueue(b.signal,{report:b.report})]);
 assert.deepEqual(results.map(x=>x.status).sort(),['duplicate','queued','queued']);assert.equal((await f.handoff.status()).queued,2);
});
test('demonstration data and a signal outside current confirmed report never call Codex',async t=>{
 const f=await setup(t),{signal,report}=fixture();assert.equal((await f.handoff.enqueue(signal,{report:{...report,mode:'demo'}})).reason,'demonstration_cannot_request_codex');
 assert.equal((await f.handoff.enqueue(signal,{report:{...report,confirmed:[]}})).reason,'signal_not_in_current_confirmed_report');assert.equal((await f.handoff.status()).queued,0);assert.equal(f.calls.length,0);
});
test('stale signal, absent source hashes and invalid SL/TP are rejected before queue',async t=>{
 const f=await setup(t),a=fixture('old',T-181000);assert.equal((await f.handoff.enqueue(a.signal,{report:a.report})).reason,'signal_not_fresh');
 const b=fixture('hash');b.report.sourceHashes=[];assert.equal((await f.handoff.enqueue(b.signal,{report:b.report})).reason,'public_source_hashes_required');
 const c=fixture('stop');c.signal.stopLoss=101;assert.equal((await f.handoff.enqueue(c.signal,{report:c.report})).reason,'invalid_signal_geometry');
});
test('private account/session siblings never enter public job data',async t=>{
 const f=await setup(t),{signal,report}=fixture();signal.evidence.accessToken='not-for-job';signal.evidence.accountId='private-account';report.context={direction:'up',refreshToken:'not-for-job'};
 const r=await f.handoff.enqueue(signal,{report});const body=await fs.readFile(join(f.directory,r.jobId,'signal.json'),'utf8');assert.ok(body.includes('direction'));assert.ok(!body.includes('not-for-job'));assert.ok(!body.includes('private-account'));
});
test('review evidence contains only matching market candles, frozen snapshot and exact five-bar proof',async t=>{
 const f=await setup(t),x=capturedFixture();x.capture.markets[0].accountId='DO_NOT_COPY';x.capture.markets[0].streams['60'][0].accessToken='DO_NOT_COPY';
 const queued=await f.handoff.enqueue(x.signal,{report:x.report,capture:x.capture});assert.equal(queued.status,'queued');
 const text=await fs.readFile(join(f.directory,queued.jobId,'signal.json'),'utf8'),payload=JSON.parse(text);assert.equal(payload.market.symbol,'BTC');assert.equal(payload.market.streams['60'].length,5);assert.equal(payload.market.proofWindows[0].bars.length,5);assert.equal(payload.market.proofWindows[0].timeframe,'60');assert.equal(payload.market.forming['5'].frozenForming,true);assert.ok(!text.includes('OTHER_SYMBOL_PRIVATE'));assert.ok(!text.includes('DO_NOT_COPY'));
 await f.handoff.processNext();assert.ok((await f.handoff.status()).latest[0].reviewReason.includes('no order placed'));
});

test('new crypto symbols require matching focused public candles and retain symbol evidence',async t=>{
 const f=await setup(t);
 for(const symbol of ['BNB','ADA','0G','1000PEPE']){
  const x=capturedFixture();x.signal={...x.signal,id:symbol+'-new-signal',symbol};x.report={...x.report,symbol,confirmed:[x.signal]};x.capture.markets[0].symbol=symbol;
  assert.equal((await f.handoff.enqueue(x.signal,{report:x.report})).reason,'public_source_market_required');
  const wrong=structuredClone(x.capture);wrong.markets[0].symbol='BTC';assert.equal((await f.handoff.enqueue(x.signal,{report:x.report,capture:wrong})).reason,'public_source_market_required');
  const queued=await f.handoff.enqueue(x.signal,{report:x.report,capture:x.capture});assert.equal(queued.status,'queued');
  const payload=JSON.parse(await fs.readFile(join(f.directory,queued.jobId,'signal.json'),'utf8'));assert.equal(payload.market.symbol,symbol);assert.equal(payload.signal.symbol,symbol);assert.equal(payload.market.streams['60'].length,5);
 }
 assert.equal((await f.handoff.status()).callsToday,0);
});

test('retiring symbols preserves queue history and deduplication across restart without model calls',async t=>{
 const f=await setup(t),sources=[];
 for(const symbol of ['BNB','0G']){
  const x=capturedFixture();x.signal={...x.signal,id:symbol+'-retire-signal',symbol};x.report={...x.report,symbol,confirmed:[x.signal]};x.capture.markets[0].symbol=symbol;
  assert.equal((await f.handoff.enqueue(x.signal,{report:x.report,capture:x.capture})).status,'queued');sources.push(x);
 }
 await assert.rejects(f.handoff.pruneUniverse(['../BNB']));
 assert.deepEqual(await f.handoff.pruneUniverse(['BNB']),{status:'pruned',retired:1,ordersSubmitted:0});
 let status=await f.handoff.status();assert.equal(status.queued,1);assert.equal(status.counts.retired,1);assert.equal(status.callsToday,0);assert.equal(f.calls.length,0);
 assert.equal(status.latest.find(job=>job.symbol==='BNB').status,'queued');assert.equal(status.latest.find(job=>job.symbol==='0G').status,'retired');
 const restarted=await createHandoff(f.options);status=await restarted.status();assert.equal(status.counts.retired,1);assert.equal(status.queued,1);assert.equal(status.callsToday,0);
 const retired=sources[1];assert.equal((await restarted.enqueue(retired.signal,{report:retired.report,capture:retired.capture})).status,'duplicate');
 const index=JSON.parse(await fs.readFile(join(f.directory,'queue.json'),'utf8')).state;assert.equal(index.jobs.find(job=>job.symbol==='0G').reason,'symbol_no_longer_in_active_universe');assert.deepEqual(index.callsByDay,{});
 assert.equal((await restarted.pruneUniverse([])).retired,1);assert.equal((await restarted.status()).queued,0);assert.equal(f.calls.length,0);
 const events=(await fs.readFile(join(f.directory,'events.jsonl'),'utf8')).trim().split('\n').map(line=>JSON.parse(line));assert.equal(events.filter(event=>event.type==='retired'&&event.ordersSubmitted===0).length,2);
});

test('unsafe and noncanonical symbols cannot enter the review queue',async t=>{
 const f=await setup(t);
 for(const symbol of ['../BTC','BTC/USD','btc','0g','BTC;echo','BTC\n','__proto__']){
  const x=capturedFixture();x.signal={...x.signal,symbol};x.report={...x.report,symbol,confirmed:[x.signal]};x.capture.markets[0].symbol=symbol;
  assert.equal((await f.handoff.enqueue(x.signal,{report:x.report,capture:x.capture})).reason,'confirmed_signal_required');
 }
 assert.equal((await f.handoff.status()).queued,0);assert.equal(f.calls.length,0);
});
test('a partial snapshot remains frozen when its scheduled close passes during capture',async t=>{
 const f=await setup(t),x=capturedFixture(),partial=x.capture.markets[0].forming['5'];partial.openTime=T-300000;partial.closeTime=T;partial.observedAt=T-1000;
 const queued=await f.handoff.enqueue(x.signal,{report:x.report,capture:x.capture});assert.equal(queued.status,'queued');const payload=JSON.parse(await fs.readFile(join(f.directory,queued.jobId,'signal.json'),'utf8'));assert.equal(payload.market.forming['5'].frozenForming,true);assert.equal(payload.market.forming['5'].observedAt,T-1000);assert.equal(payload.market.streams['5'],undefined);
});
test('wrong market, stale source, lookahead candles and excess candle arrays cannot enter a job',async t=>{
 const f=await setup(t);let x=capturedFixture();x.capture.markets=x.capture.markets.filter(m=>m.symbol==='ETH');assert.equal((await f.handoff.enqueue(x.signal,{report:x.report,capture:x.capture})).reason,'public_source_market_required');
 x=capturedFixture();x.capture.markets[0].asOf=T-181000;assert.equal((await f.handoff.enqueue(x.signal,{report:x.report,capture:x.capture})).reason,'source_market_not_fresh');
 x=capturedFixture();x.capture.markets[0].streams['60'].at(-1).closeTime=T+3600000;assert.equal((await f.handoff.enqueue(x.signal,{report:x.report,capture:x.capture})).reason,'invalid_source_candle');
 x=capturedFixture();x.capture.markets[0].forming['5'].observedAt=T+1;assert.equal((await f.handoff.enqueue(x.signal,{report:x.report,capture:x.capture})).reason,'source_candle_lookahead');
 x=capturedFixture();x.capture.markets[0].streams['60']=Array(1001).fill(x.capture.markets[0].streams['60'][0]);assert.equal((await f.handoff.enqueue(x.signal,{report:x.report,capture:x.capture})).reason,'public_source_candles_too_large');
 x=capturedFixture();x.capture.markets[0].sourceHashes=['b'.repeat(64)];assert.equal((await f.handoff.enqueue(x.signal,{report:x.report,capture:x.capture})).reason,'source_market_hashes_mismatch');assert.equal((await f.handoff.status()).queued,0);
});
test('read-only review invokes CLI through stdin with no shell or bypass flags and stores result',async t=>{
 const f=await setup(t),{signal,report}=fixture('BTC; echo dangerous $(anything)');await f.handoff.enqueue(signal,{report});const result=await f.handoff.processNext();
 assert.equal(result.status,'completed');assert.equal(result.ordersSubmitted,0);const spec=f.calls.find(x=>x.kind==='review');assert.ok(spec.args.includes('read-only'));assert.ok(spec.args.includes('--ignore-user-config'));assert.equal(spec.args.at(-1),'-');
 assert.ok(!spec.args.join(' ').includes('dangerous'));assert.ok(!spec.args.join(' ').includes('bypass'));assert.ok(spec.input.includes('REVIEW ONLY'));assert.equal((await f.handoff.status()).callsToday,1);
});
test('a model cannot confirm a metadata-only job without verifiable candle evidence',async t=>{
 const f=await setup(t),x=fixture();await f.handoff.enqueue(x.signal,{report:x.report});const result=await f.handoff.processNext();assert.equal(result.status,'completed');assert.equal(result.response.status,'insufficient_data');assert.equal(result.response.freshDataChecked,false);assert.equal((await f.handoff.status()).latest[0].reviewStatus,'insufficient_data');
});
test('missing CLI preserves queue and never spends a model call',async t=>{
 const f=await setup(t,{resolveCommand:async()=>null}),x=fixture();await f.handoff.enqueue(x.signal,{report:x.report});assert.equal((await f.handoff.processNext()).status,'cli_missing');assert.equal((await f.handoff.status()).queued,1);assert.equal((await f.handoff.status()).callsToday,0);assert.equal(f.calls.length,0);
});
test('API-key login is not silently used for paid model calls',async t=>{
 const f=await setup(t,{runCommand:async()=>({started:true,exitCode:0,stdout:'Logged in using an API key'})}),x=fixture();await f.handoff.enqueue(x.signal,{report:x.report});assert.equal((await f.handoff.processNext()).status,'chatgpt_login_required');assert.equal((await f.handoff.status()).callsToday,0);
});
test('ChatGPT login reported on stderr is accepted even when stdout contains a banner',async t=>{
 const f=await setup(t,{runCommand:async spec=>spec.kind==='auth_status'?{exitCode:0,stdout:'Codex CLI status\n',stderr:'Logged in using ChatGPT'}:{started:true,exitCode:0,lastMessage:JSON.stringify({status:'wait',reason:'reviewed',freshDataChecked:true,ordersSubmitted:0})}}),x=fixture();
 await f.handoff.enqueue(x.signal,{report:x.report});assert.equal((await f.handoff.processNext()).status,'completed');assert.equal((await f.handoff.status()).callsToday,1);
});
test('failed login output mentioning ChatGPT cannot authorize a model call',async t=>{
 let reviews=0;const f=await setup(t,{runCommand:async spec=>{if(spec.kind==='review')reviews++;return{exitCode:0,stdout:'Not logged in. Use ChatGPT to log in.'};}}),x=fixture();
 await f.handoff.enqueue(x.signal,{report:x.report});assert.equal((await f.handoff.processNext()).status,'chatgpt_login_required');assert.equal(reviews,0);
});
test('queue expiry is terminal and does not request a stale review',async t=>{
 const f=await setup(t),x=fixture();await f.handoff.enqueue(x.signal,{report:x.report});f.setNow(T+181000);assert.equal((await f.handoff.processNext()).status,'idle');assert.equal((await f.handoff.status()).counts.expired,1);assert.equal(f.calls.length,0);
});
test('daily dispatch budget is persisted across restart and resets at 03:00 Moscow',async t=>{
 const f=await setup(t,{settings:{maxCallsPerDay:1}});let x=fixture('first');await f.handoff.enqueue(x.signal,{report:x.report});await f.handoff.processNext();
 f.setNow(T+1000);x=fixture('second',T+1000);const restarted=await createHandoff(f.options);await restarted.enqueue(x.signal,{report:x.report});assert.equal((await restarted.processNext()).status,'daily_call_limit');
 const nextDay=Date.parse('2026-11-12T00:00:00Z');f.setNow(nextDay);x=fixture('next-day',nextDay);await restarted.enqueue(x.signal,{report:x.report});assert.equal((await restarted.processNext()).status,'completed');assert.equal((await restarted.status()).callsToday,1);
});
test('cooldown does not dispatch second simultaneous opportunity',async t=>{
 const f=await setup(t,{settings:{cooldownSeconds:900}}),a=fixture('a'),b=fixture('b');await f.handoff.enqueue(a.signal,{report:a.report});await f.handoff.processNext();await f.handoff.enqueue(b.signal,{report:b.report});assert.equal((await f.handoff.processNext()).status,'cooldown');assert.equal((await f.handoff.status()).callsToday,1);
});
test('altered evidence and corrupted queue never authorize a model invocation',async t=>{
 const f=await setup(t),x=fixture(),job=await f.handoff.enqueue(x.signal,{report:x.report});await fs.appendFile(join(f.directory,job.jobId,'signal.json'),' ');const result=await f.handoff.processNext();assert.equal(result.status,'blocked');assert.equal(result.reason,'handoff_evidence_integrity_mismatch');assert.equal((await f.handoff.status()).callsToday,0);
});
test('source freshness uses the stored asOf field and rejects an absent timestamp',async t=>{
 const f=await setup(t),x=fixture(),job=await f.handoff.enqueue(x.signal,{report:x.report}),path=join(f.directory,job.jobId,'signal.json');
 const payload=JSON.parse(await fs.readFile(path,'utf8'));delete payload.source.asOf;const body=JSON.stringify(payload);await fs.writeFile(path,body);
 const indexPath=join(f.directory,'queue.json'),record=JSON.parse(await fs.readFile(indexPath,'utf8'));record.state.jobs[0].evidenceSHA256=createHash('sha256').update(body).digest('hex');record.sha256=hash(record.state);await fs.writeFile(indexPath,JSON.stringify(record));
 const result=await f.handoff.processNext();assert.equal(result.status,'blocked');assert.equal(result.reason,'handoff_source_expired');assert.equal((await f.handoff.status()).callsToday,0);assert.equal(f.calls.filter(c=>c.kind==='review').length,0);
});
test('demo execution mode is explicitly blocked, not converted to unrestricted Codex',async t=>{
 const f=await setup(t,{settings:{mode:'demo-ui'}}),x=fixture();await f.handoff.enqueue(x.signal,{report:x.report});assert.equal((await f.handoff.processNext()).status,'blocked_executor_not_configured');assert.equal(f.calls.length,0);assert.equal((await f.handoff.status()).executionEnabled,false);
});
test('crashed dispatched job is retained as unknown and never resubmitted',async t=>{
 const f=await setup(t),x=fixture(),job=await f.handoff.enqueue(x.signal,{report:x.report});const path=join(f.directory,'queue.json'),record=JSON.parse(await fs.readFile(path,'utf8'));record.state.jobs[0].status='dispatched';record.state.callsByDay['2026-11-11']=1;record.sha256=hash(record.state);await fs.writeFile(path,JSON.stringify(record));
 const restarted=await createHandoff(f.options);assert.equal((await restarted.processNext()).status,'idle');assert.equal((await restarted.status()).counts.outcome_unknown,1);assert.equal((await restarted.enqueue(x.signal,{report:x.report})).status,'duplicate');assert.equal(f.calls.length,0);
});
test('a model response that expires in flight cannot remain a current confirmation',async t=>{
 let f;f=await setup(t,{runCommand:async spec=>{if(spec.kind==='auth_status')return{exitCode:0,stdout:'Logged in using ChatGPT'};f.setNow(T+181000);return{started:true,exitCode:0,lastMessage:JSON.stringify({status:'candidate_confirmed',reason:'review',freshDataChecked:true,ordersSubmitted:0})};}});const x=fixture();await f.handoff.enqueue(x.signal,{report:x.report});const r=await f.handoff.processNext();assert.equal(r.response.status,'wait');assert.equal(r.response.freshDataChecked,false);
});
test('Windows npm shim resolves to fixed JS entry, without cmd.exe shell interpretation',async t=>{
 const f=await setup(t),bin=join(f.directory,'space folder');await fs.mkdir(join(bin,'node_modules','@openai','codex','bin'),{recursive:true});await fs.writeFile(join(bin,'codex.cmd'),'@echo off');await fs.writeFile(join(bin,'node_modules','@openai','codex','bin','codex.js'),'');
 const r=await resolveCodexCommand('codex',{platform:'win32',env:{PATH:bin}});assert.equal(r.file,process.execPath);assert.ok(r.prefixArgs[0].endsWith('codex.js'));assert.equal(await resolveCodexCommand('codex & evil',{platform:'win32',env:{PATH:bin}}),null);
 const quoted=await resolveCodexCommand('codex',{platform:'win32',env:{pAtH:'"'+bin+'"'}});assert.deepEqual(quoted,r);
 assert.deepEqual(await resolveCodexCommand('"'+join(bin,'codex.cmd')+'"',{platform:'win32',env:{}}),r);
});
test('real child-process plumbing accepts a local CLI stub and captures its schema response',async t=>{
 const directory=await fs.mkdtemp(join(tmpdir(),'scanner-cli-stub-'));t.after(()=>fs.rm(directory,{recursive:true,force:true}));
 const stub=join(directory,'codex-stub.mjs');await fs.writeFile(stub,`import fs from 'node:fs/promises';
const args=process.argv.slice(2);
if(args[0]==='login'){process.stdout.write('Codex status banner\\n');process.stderr.write('Logged in using ChatGPT\\n');}
else{let input='';for await(const b of process.stdin)input+=b;await fs.writeFile('stub-observed.json',JSON.stringify({args,input,cwd:process.cwd()}));await fs.writeFile(args[args.indexOf('--output-last-message')+1],JSON.stringify({status:'candidate_confirmed',reason:'Local process stub; no model or broker call.',freshDataChecked:true,ordersSubmitted:0}));}
`);
 const handoff=await createHandoff({directory:join(directory,'queue'),now:()=>T,runCommand:runCodexProcess,resolveCommand:async()=>({file:process.execPath,prefixArgs:[stub]})}),x=fixture('stub; $(never-run)');
 const job=await handoff.enqueue(x.signal,{report:x.report}),result=await handoff.processNext();assert.equal(result.status,'completed');assert.equal(result.ordersSubmitted,0);
 const observed=JSON.parse(await fs.readFile(join(directory,'queue',job.jobId,'stub-observed.json'),'utf8'));assert.equal(observed.cwd,join(directory,'queue',job.jobId));assert.ok(observed.input.includes('REVIEW ONLY'));assert.ok(observed.args.includes('read-only'));assert.ok(!observed.args.some(x=>x.includes('never-run')));
});
test('stop aborts only the owned local child and never retries its outcome',async t=>{
 let started;const ready=new Promise(resolve=>{started=resolve;});
 const f=await setup(t,{runCommand:async spec=>{if(spec.kind==='auth_status')return{exitCode:0,stdout:'Logged in using ChatGPT'};started();return new Promise(resolve=>spec.signal.addEventListener('abort',()=>resolve({started:true,exitCode:null,aborted:true}),{once:true}));}}),x=fixture();
 await f.handoff.enqueue(x.signal,{report:x.report});const running=f.handoff.processNext();await ready;assert.equal((await f.handoff.stop()).status,'stopped');assert.equal((await running).status,'outcome_unknown');assert.equal((await f.handoff.status()).counts.outcome_unknown,1);assert.equal((await f.handoff.enqueue(x.signal,{report:x.report})).status,'duplicate');
});
test('default process runner terminates a bounded local process without a model call',async()=>{
 const r=await runCodexProcess({launcher:{file:process.execPath,prefixArgs:[]},args:['-e','setInterval(()=>{},1000)'],cwd:tmpdir(),timeoutMs:50});assert.equal(r.timedOut,true);assert.equal(r.started,true);
});
