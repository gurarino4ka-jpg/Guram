import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {discoverCryptoMarkets} from '../scanner/provider.mjs';

const T=Date.parse('2026-11-12T12:00:00Z');
const SOURCE='https://app.bookflow.sh/api/v2/markets';
let nextId=1;
const market=(symbol,overrides={})=>({
 id:`00000000-0000-4000-8000-${String(nextId++).padStart(12,'0')}`,
 config:{baseAsset:symbol,quoteAsset:'USD',settlementToken:'USD',type:'base',category:'crypto',name:`${symbol}/USD`,ticker:`${symbol}/USDT`,...overrides.config},
 settings:{isClosed:false,isPaused:false,isCloseOnly:false,...overrides.settings},
 ...Object.fromEntries(Object.entries(overrides).filter(([key])=>!['config','settings'].includes(key)))
});
function responseFor(value){return {ok:true,status:200,text:async()=>JSON.stringify(value)};}
const reason=entry=>entry.code??entry.reason??entry.reasons?.[0];

test('discovery uses the authoritative category and USD linear contract fields, preserving source evidence',async()=>{
 const rows=[
  market('BTC'),market('0G'),market('1000PEPE'),market('ASTER',{config:{ticker:'ASTER/USD'}}),
  market('STOCK',{config:{category:'rwa',tags:['Crypto'],name:'Crypto/USD'}}),
  market('MISSING',{config:{category:undefined,tags:['Crypto']}}),
  market('EURPAIR',{config:{quoteAsset:'EUR'}}),
  market('USDTSETTLED',{config:{settlementToken:'USDT'}}),
  market('INVERSE',{config:{type:'inverse'}})
 ];
 const body=JSON.stringify(rows),calls=[];
 const result=await discoverCryptoMarkets({now:()=>T,fetchImpl:async(url,options)=>{
  calls.push({url:String(url),options});return {ok:true,status:200,text:async()=>body};
 }});
 assert.deepEqual(new Set(result.symbols),new Set(['BTC','0G','1000PEPE','ASTER']));
 assert.equal(result.totalMarkets,rows.length);
 assert.equal(result.totalCrypto,7);
 assert.equal(result.markets.length,4);
 assert.equal(result.observedAt,T);
 assert.equal(result.source,SOURCE);
 assert.equal(result.bodySHA256,createHash('sha256').update(body).digest('hex'));
 assert.equal(result.markets.find(m=>m.symbol==='BTC').id,rows[0].id);
 assert.equal(result.markets.find(m=>m.symbol==='ASTER').name,'ASTER/USD');
 assert.equal(result.markets.find(m=>m.symbol==='ASTER').ticker,'ASTER/USD');
 assert.equal(result.excluded.length,5);
 assert.ok(result.excluded.every(entry=>typeof reason(entry)==='string'&&reason(entry).length));
 assert.equal(calls.length,1);
 assert.equal(calls[0].url,SOURCE);
 assert.equal(calls[0].options.method,'GET');
 assert.equal(calls[0].options.credentials,'omit');
 assert.equal(calls[0].options.redirect,'error');
 assert.equal(calls[0].options.headers.authorization,undefined);
});

test('closed, paused, close-only and unknown statuses are excluded with a visible reason',async()=>{
 const rows=[market('OPEN'),market('CLOSED',{settings:{isClosed:true}}),market('PAUSED',{settings:{isPaused:true}}),market('CLOSEONLY',{settings:{isCloseOnly:true}}),market('UNKNOWN',{settings:{isPaused:undefined}}),market('STRINGFLAG',{settings:{isClosed:'false'}})];
 const result=await discoverCryptoMarkets({now:()=>T,fetchImpl:async()=>responseFor(rows)});
 assert.deepEqual(result.symbols,['OPEN']);
 assert.equal(result.totalCrypto,6);
 assert.equal(result.excluded.length,5);
 assert.ok(result.excluded.every(entry=>typeof reason(entry)==='string'&&reason(entry).length));
 for(const symbol of ['CLOSED','PAUSED','CLOSEONLY','UNKNOWN','STRINGFLAG'])assert.ok(result.excluded.some(entry=>entry.symbol===symbol));
});

test('discovery deduplicates both source identities and symbols and rejects malformed or unsafe symbols',async()=>{
 const original=market('BTC');
 const malformed=['btc','BTC/USDT',' BTC','ETH ','','A\\B','A\nB','__proto__','constructor','CONSTRUCTOR','PROTOTYPE','💰'];
 const rows=[original,market('ETH',{id:original.id}),market('BTC'),...malformed.map(symbol=>market(symbol)),market('A.B'),market('A_B'),market('A-B')];
 const result=await discoverCryptoMarkets({now:()=>T,fetchImpl:async()=>responseFor(rows)});
 assert.deepEqual(new Set(result.symbols),new Set(['BTC','A.B','A_B','A-B']));
 assert.equal(new Set(result.markets.map(m=>m.id)).size,result.markets.length);
 assert.equal(new Set(result.symbols).size,result.symbols.length);
 assert.equal(result.excluded.length,malformed.length+2);
 assert.ok(result.excluded.every(entry=>typeof reason(entry)==='string'&&reason(entry).length));
});

test('discovery has no fixed universe cap and includes additions on the next observation',async()=>{
 const rows=Array.from({length:115},(_,index)=>market(`COIN${index}`));
 let current=rows;
 const args={now:()=>T,fetchImpl:async()=>responseFor(current)};
 const before=await discoverCryptoMarkets(args);
 assert.equal(before.symbols.length,115);
 current=[...rows.slice(1),market('NEWPAIR')];
 const after=await discoverCryptoMarkets(args);
 assert.equal(after.symbols.length,115);
 assert.ok(after.symbols.includes('NEWPAIR'));
 assert.ok(!after.symbols.includes('COIN0'));
});

test('catalog HTTP failures and malformed bodies reject instead of returning a fixed fallback universe',async()=>{
 await assert.rejects(discoverCryptoMarkets({now:()=>T,fetchImpl:async()=>({ok:false,status:429,headers:{get:()=> '120'}})}),error=>error.status===429&&error.retryAfterMs===120000);
 for(const body of ['not-json','{}','null'])await assert.rejects(discoverCryptoMarkets({now:()=>T,fetchImpl:async()=>({ok:true,status:200,text:async()=>body})}),error=>typeof error.code==='string');
 await assert.rejects(discoverCryptoMarkets({now:()=>T,fetchImpl:async()=>{throw new Error('offline');}}));
});

