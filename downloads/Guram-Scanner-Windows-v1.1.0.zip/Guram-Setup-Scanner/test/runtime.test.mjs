import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import {join} from 'node:path';
import {runScanner,parseOptions,openLocalDashboard} from '../scanner/cli.mjs';
import {ScannerStore} from '../scanner/store.mjs';
import {startDashboard,currentSnapshot} from '../scanner/server.mjs';

const T=Date.parse('2026-11-11T18:00:00Z');
const settings={symbols:['BTC','ETH'],pollSeconds:1,port:0,balanceUSD:10000,riskPercent:1,timeoutMs:1000,countback:300};
const render=s=>'<html><body>'+s.status+'</body></html>';
const market=(symbol,at=T)=>({symbol,asOf:at,quote:{price:100,observedAt:at},streams:{},sourceHashes:[]});
const captured=(at=T)=>({asOf:at,receivedAt:at,markets:settings.symbols.map(s=>market(s,at)),errors:[]});
const analyze=({symbol,asOf,previousState})=>({symbol,asOf,status:'watching',price:100,direction:'up',confirmed:[{id:symbol+':signal-1',side:'long',entry:100,stop:95,target:110}],watch:[],rejected:[],issues:[],nextState:{visits:(previousState.visits||0)+1}});
async function temp(t){const d=await fs.mkdtemp(join(os.tmpdir(),'guram-runtime-'));t.after(()=>fs.rm(d,{recursive:true,force:true}));return d;}

test('restart restores engine state and does not duplicate signal history',async t=>{
 const dataDir=await temp(t),deps={now:()=>T,captureMarket:async()=>captured(),analyzeSymbol:analyze,renderDashboard:render};
 const first=await runScanner({settings,dataDir,once:true},deps),second=await runScanner({settings,dataDir,once:true},deps);
 assert.equal(first.newSignals.length,2);assert.equal(second.newSignals.length,0);assert.equal(second.snapshot.history.length,2);
 const state=await new ScannerStore(dataDir).readState();assert.equal(state.symbols.BTC.visits,2);assert.equal(await fs.readFile(join(dataDir,'latest-report.html'),'utf8'),'<html><body>ok</body></html>');
});

test('internet failure removes active confirmations while retaining historical signals',async t=>{
 const dataDir=await temp(t);let now=T,reads=0;
 const result=await runScanner({settings,dataDir,serve:false,maximumCycles:2},{now:()=>now,wait:async ms=>{now+=ms;},captureMarket:async()=>{if(reads++)throw Object.assign(Error('transport body must not leak'),{code:'network_error'});return captured(now);},analyzeSymbol:analyze,renderDashboard:render});
 assert.equal(result.status,'offline');assert.equal(result.snapshot.confirmedCount,0);assert.equal(result.snapshot.history.length,2);
 assert.ok(result.snapshot.symbols.every(s=>s.confirmed.length===0));assert.ok(!JSON.stringify(result.snapshot).includes('transport body must not leak'));
 assert.equal((await new ScannerStore(dataDir).latestSnapshot()).status,'offline');
});

test('partial source failure cannot reuse a previous signal for the missing pair',async t=>{
 const dataDir=await temp(t),source=captured();source.markets=source.markets.slice(0,1);source.errors=[{symbol:'ETH',code:'http_error',message:'Публичный источник недоступен'}];
 const result=await runScanner({settings,dataDir,once:true},{now:()=>T,captureMarket:async()=>source,analyzeSymbol:analyze,renderDashboard:render});
 assert.equal(result.status,'degraded');assert.equal(result.snapshot.symbols.find(s=>s.symbol==='ETH').confirmed.length,0);assert.equal(result.snapshot.confirmedCount,1);
});

test('stale capture never reaches the strategy or handoff',async t=>{
 const dataDir=await temp(t);let calls=0;
 const result=await runScanner({settings,dataDir,once:true},{now:()=>T+200000,captureMarket:async()=>captured(),analyzeSymbol:()=>{calls++;return analyze({});},renderDashboard:render});
 assert.equal(result.status,'offline');assert.equal(calls,0);assert.equal(result.snapshot.errors[0].code,'stale_capture');
});

test('one failed engine result does not hide a valid report for another market',async t=>{
 const dataDir=await temp(t);
 const result=await runScanner({settings,dataDir,once:true},{now:()=>T,captureMarket:async()=>captured(),analyzeSymbol:input=>{if(input.symbol==='ETH')throw Error('bad geometry');return analyze(input);},renderDashboard:render});
 assert.equal(result.status,'degraded');assert.equal(result.snapshot.symbols[0].confirmed.length,1);assert.equal(result.snapshot.symbols[1].status,'offline');
});

test('data_error report cannot reset persisted strategy state or expose stale confirmations',async t=>{
 const dataDir=await temp(t),deps={now:()=>T,captureMarket:async()=>captured(),analyzeSymbol:analyze,renderDashboard:render};
 await runScanner({settings,dataDir,once:true},deps);
 const result=await runScanner({settings,dataDir,once:true},{...deps,analyzeSymbol:input=>({symbol:input.symbol,status:'data_error',confirmed:[{id:'stale'}],nextState:{visits:0},issues:['missing_history']})});
 assert.equal(result.status,'offline');assert.equal(result.snapshot.confirmedCount,0);
 const state=await new ScannerStore(dataDir).readState();assert.equal(state.symbols.BTC.visits,1);assert.equal(state.history.length,2);
});

test('Codex processing runs asynchronously without blocking the next market cycle',async t=>{
 const dataDir=await temp(t);let now=T,reads=0,processed=0,enqueued=0,stopped=0,resolveJob;
 const handoff={status:async()=>({status:'queued'}),enqueue:async()=>{enqueued++;},processNext:async()=>{processed++;await new Promise(r=>{resolveJob=r;});},stop:async()=>{stopped++;resolveJob?.();}};
 const result=await runScanner({settings,dataDir,serve:false,maximumCycles:2},{now:()=>now,handoff,wait:async ms=>{now+=ms;},captureMarket:async()=>{reads++;return captured(now);},analyzeSymbol:analyze,renderDashboard:render});
 assert.equal(reads,2);assert.equal(processed,1);assert.equal(enqueued,4);assert.equal(stopped,1);assert.equal(result.status,'ok');
});

for(const mode of ['check','demo'])test(mode+' mode never dispatches Codex tasks',async t=>{
 const dataDir=await temp(t);let calls=0;
 const handoff={status:async()=>{calls++;return {};},enqueue:async()=>{calls++;},processNext:async()=>{calls++;},stop:async()=>{calls++;}};
 const result=await runScanner({settings,dataDir,once:true,...(mode==='demo'?{demoCapture:captured()}:{}),serve:false},{now:()=>T,handoff,captureMarket:async()=>captured(),analyzeSymbol:analyze,renderDashboard:render});
 assert.equal(calls,0);assert.equal(result.snapshot.handoff.status,mode==='demo'?'disabled_in_demo':'disabled_in_check');
 if(mode==='demo')assert.ok(result.snapshot.history.every(s=>s.illustrative));
});

test('rate-limit Retry-After controls the next retry instead of a busy loop',async t=>{
 const dataDir=await temp(t);let now=T;const waits=[];
 await runScanner({settings,dataDir,serve:false,maximumCycles:2},{now:()=>now,wait:async ms=>{waits.push(ms);now+=ms;},captureMarket:async()=>{throw Object.assign(Error('rate'),{code:'http_error',retryAfterMs:60000});},analyzeSymbol:analyze,renderDashboard:render});
 assert.deepEqual(waits,[60000]);
});

test('stale dashboard view clears active signals but preserves the journal history',()=>{
 const s=currentSnapshot({mode:'live',status:'ok',generatedAt:new Date(T).toISOString(),symbols:[{symbol:'BTC',confirmed:[{id:'old'}]}],history:[{id:'old'}]},{now:T+180001});
 assert.equal(s.status,'stale');assert.equal(s.symbols[0].confirmed.length,0);assert.equal(s.history.length,1);
});

test('local server exposes GET-only dashboard and blocks unrelated paths',async t=>{
 const dashboard=await startDashboard({port:0,getSnapshot:()=>({mode:'demo',status:'ok',generatedAt:new Date(T).toISOString(),symbols:[]}),renderDashboard:render});t.after(()=>dashboard.close());
 const response=await fetch(dashboard.url+'/status');assert.equal(response.status,200);assert.equal(response.headers.get('cache-control'),'no-store, max-age=0');assert.equal((await response.json()).publicReadOnly,undefined);
 assert.equal((await fetch(dashboard.url+'/',{method:'POST'})).status,405);assert.equal((await fetch(dashboard.url+'/etc/passwd')).status,404);
 assert.equal((await fetch(dashboard.url+'/',{headers:{origin:'https://example.com'}})).status,403);
 assert.equal((await fetch(dashboard.url+'/')).headers.get('x-content-type-options'),'nosniff');
 await assert.rejects(startDashboard({port:dashboard.port,getSnapshot:()=>({}),renderDashboard:render}),{code:'EADDRINUSE'});
});

test('browser launch uses a fixed local URL and literal Windows arguments',()=>{
 let args;openLocalDashboard('http://127.0.0.1:8787',{platform:'win32',spawnImpl:(...x)=>{args=x;return {on(){},unref(){}};}});
 assert.equal(args[0],'cmd.exe');assert.deepEqual(args[1],['/d','/c','start','','http://127.0.0.1:8787']);
 assert.throws(()=>openLocalDashboard('https://example.com/'));assert.throws(()=>openLocalDashboard('http://127.0.0.1:8787/?x=1&calc'));assert.throws(()=>parseOptions(['--port','8787&exit']));
});

test('103 discovered pairs persist and hand off the first completed market before the final market arrives',async t=>{
 const dataDir=await temp(t),symbols=['BNB','ADA','0G',...Array.from({length:100},(_,i)=>'A'+String(i).padStart(3,'0'))];
 const allSettings={...settings,symbols:'all_crypto',catalogRefreshSeconds:900,requestConcurrency:3,requestSpacingMs:200};
 const universe={status:'ready',symbols,availableCrypto:103,totalCrypto:109,totalMarkets:156,observedAt:T,bodySHA256:'c'.repeat(64)};
 let firstPublished=false,firstPersisted=false,finalMarketReturned=false,processing=0,finishJob;
 const queued=[],updates=[];
 const handoff={status:async()=>({status:'ready'}),enqueue:async(signal,evidence)=>{queued.push({signal,evidence});},processNext:async()=>{processing++;await new Promise(r=>{finishJob=r;});},stop:async()=>finishJob?.()};
 const captureMarket=async options=>{
  assert.equal(options.symbols,'all_crypto');
  await options.onUniverse({selectedSymbols:symbols,universe});
  const markets=[];
  for(const [index,symbol] of symbols.entries()){
   const item={...market(symbol),definition:{symbol,name:symbol+'/USD',ticker:symbol+'USD'}};markets.push(item);
   await options.onMarket(item,{completed:index+1,total:symbols.length,symbol,errors:[]});
   if(index===0){
    assert.equal(finalMarketReturned,false);
    assert.equal(queued.length,1);assert.equal(queued[0].signal.symbol,'BNB');
    assert.deepEqual(queued[0].evidence.capture.markets.map(m=>m.symbol),['BNB']);
    const stored=await new ScannerStore(dataDir).latestSnapshot();
    firstPersisted=stored.history.some(s=>s.symbol==='BNB');
    assert.equal(stored.progress.completed,1);assert.equal(stored.progress.total,103);
    assert.equal(stored.symbols.length,103);assert.equal(stored.universe.totalCrypto,109);
    firstPublished=updates.some(s=>s.progress.completed===1&&s.symbols.find(m=>m.symbol==='BNB')?.confirmed.length===1);
    assert.equal(processing,1);
   }
  }
  finalMarketReturned=true;
  return {asOf:T,receivedAt:T,markets,selectedSymbols:symbols,universe,errors:[]};
 };
 const result=await runScanner({settings:allSettings,dataDir,serve:false,maximumCycles:1},{now:()=>T,captureMarket,analyzeSymbol:analyze,renderDashboard:render,handoff,onUpdate:s=>updates.push(s)});
 assert.ok(firstPublished);assert.ok(firstPersisted);assert.equal(result.status,'ok');
 assert.equal(result.snapshot.symbols.length,103);assert.equal(result.snapshot.progress.completed,103);assert.equal(result.snapshot.progress.currentSymbol,null);
 assert.equal(result.snapshot.config.symbols,'all_crypto');assert.equal(result.newSignals.length,103);assert.equal(queued.length,103);
 assert.equal(result.snapshot.symbols[0].market.name,'BNB/USD');
});

test('catalog refresh adds and retires active pairs while keeping prior state and history',async t=>{
 const dataDir=await temp(t),allSettings={...settings,symbols:'all_crypto'};let clock=T,reads=0;
 const retiredChecks=[];
 const handoff={status:async()=>({status:'ready'}),enqueue:async()=>{},processNext:async()=>{},stop:async()=>{},pruneUniverse:async active=>retiredChecks.push([...active])};
 const result=await runScanner({settings:allSettings,dataDir,serve:false,maximumCycles:2},{now:()=>clock,wait:async ms=>{clock+=ms;},handoff,analyzeSymbol:analyze,renderDashboard:render,captureMarket:async options=>{
  const symbols=reads++?['ADA','0G']:['BNB','ADA'],universe={status:'ready',symbols,observedAt:clock};
  await options.onUniverse({selectedSymbols:symbols,universe});
  const markets=symbols.map(s=>market(s,clock));
  for(const m of markets)await options.onMarket(m,{symbol:m.symbol,errors:[]});
  return {asOf:clock,receivedAt:clock,selectedSymbols:symbols,universe,markets,errors:[]};
 }});
 assert.equal(result.status,'ok');assert.deepEqual(result.snapshot.symbols.map(s=>s.symbol),['ADA','0G']);
 assert.deepEqual(result.snapshot.universe.symbols,['ADA','0G']);assert.equal(result.snapshot.config.symbols,'all_crypto');
 const state=await new ScannerStore(dataDir).readState();assert.equal(state.symbols.BNB.visits,1);assert.equal(state.symbols.ADA.visits,2);assert.equal(state.symbols['0G'].visits,1);
 assert.deepEqual(new Set(state.history.map(s=>s.symbol)),new Set(['BNB','ADA','0G']));
 assert.deepEqual(retiredChecks.slice(0,2),[['BNB','ADA'],['ADA','0G']]);
});

test('a partial pair failure keeps its prior state and another pair fresh during progressive collection',async t=>{
 const dataDir=await temp(t);let clock=T,reads=0,observedPartial=false;
 const result=await runScanner({settings,dataDir,serve:false,maximumCycles:2},{now:()=>clock,wait:async ms=>{clock+=ms;},analyzeSymbol:analyze,renderDashboard:render,onUpdate:s=>{
  if(s.cycle===2&&s.progress.completed===1){const b=s.symbols.find(m=>m.symbol==='BTC'),e=s.symbols.find(m=>m.symbol==='ETH');if(b.confirmed.length===1&&e.confirmed.length===0&&e.status==='offline')observedPartial=true;}
 },captureMarket:async options=>{
  if(!reads++)return captured(clock);
  const failed={symbol:'ETH',asOf:clock,status:'unavailable',quote:null,streams:{},issues:[{code:'http_error'}]};
  await options.onMarket(failed,{symbol:'ETH',errors:[{symbol:'ETH',code:'http_error',message:'Unavailable'}]});
  const good=market('BTC',clock);await options.onMarket(good,{symbol:'BTC',errors:[]});
  return {asOf:clock,receivedAt:clock,markets:[good,failed],errors:[{symbol:'ETH',code:'http_error',message:'Unavailable'}]};
 }});
 assert.ok(observedPartial);assert.equal(result.status,'degraded');assert.equal(result.snapshot.symbols.find(s=>s.symbol==='BTC').confirmed.length,1);
 const state=await new ScannerStore(dataDir).readState();assert.equal(state.symbols.BTC.visits,2);assert.equal(state.symbols.ETH.visits,1);assert.equal(state.history.length,2);
});

test('progress ages each pair independently while a later market remains fresh',async t=>{
 const dataDir=await temp(t);let clock=T;const updates=[];
 const result=await runScanner({settings,dataDir,once:true},{now:()=>clock,analyzeSymbol:analyze,renderDashboard:render,onUpdate:s=>updates.push(s),captureMarket:async options=>{
  const first=market('BTC',clock);await options.onMarket(first,{symbol:'BTC',errors:[]});
  clock+=121000;
  const second=market('ETH',clock);await options.onMarket(second,{symbol:'ETH',errors:[]});
  return {asOf:clock,receivedAt:clock,markets:[first,second],errors:[]};
 }});
 assert.equal(result.status,'degraded');assert.equal(result.snapshot.symbols.find(m=>m.symbol==='BTC').status,'stale');assert.equal(result.snapshot.symbols.find(m=>m.symbol==='BTC').confirmed.length,0);
 assert.equal(result.snapshot.symbols.find(m=>m.symbol==='ETH').confirmed.length,1);assert.equal(result.snapshot.history.length,2);
 assert.ok(updates.some(s=>s.progress.completed===1&&s.symbols.find(m=>m.symbol==='BTC').confirmed.length===1));
});

test('all_crypto discovery failure stays empty and offline instead of scanning four fixture pairs',async t=>{
 const dataDir=await temp(t);let analyzed=0;
 const result=await runScanner({settings:{...settings,symbols:'all_crypto'},dataDir,once:true},{now:()=>T,analyzeSymbol:()=>{analyzed++;},renderDashboard:render,captureMarket:async options=>{
  const universe={status:'unavailable',symbols:[],error:{code:'catalog_unavailable'}};
  await options.onUniverse({selectedSymbols:[],universe});
  return {asOf:T,receivedAt:T,markets:[],selectedSymbols:[],universe,errors:[{code:'catalog_unavailable',message:'Catalog unavailable'}]};
 }});
 assert.equal(result.status,'offline');assert.equal(analyzed,0);assert.deepEqual(result.snapshot.symbols,[]);assert.equal(result.snapshot.progress.total,0);
 assert.equal(result.snapshot.universe.status,'unavailable');
});

test('demo ignores all_crypto discovery and runs only the frozen fixture symbols',async t=>{
 const dataDir=await temp(t);let reads=0;const fixture={...captured(),markets:['BTC','ETH','SOL','ZEC'].map(s=>market(s))};
 const result=await runScanner({settings:{...settings,symbols:'all_crypto'},dataDir,once:true,demoCapture:fixture},{now:()=>T+86400000,captureMarket:async()=>{reads++;throw Error('must not request catalog');},analyzeSymbol:analyze,renderDashboard:render});
 assert.equal(reads,0);assert.equal(result.status,'ok');assert.deepEqual(result.snapshot.symbols.map(s=>s.symbol),['BTC','ETH','SOL','ZEC']);assert.equal(result.snapshot.universe.mode,'demo');assert.equal(result.snapshot.handoff.status,'disabled_in_demo');
});

test('runtime rejects unsafe manual symbol identifiers before requesting data',async t=>{
 for(const symbols of [['../BTC'],['BTC/USD'],['BTC;echo'],['btc'],['BTC','BTC']]){
  let calls=0;await assert.rejects(runScanner({settings:{...settings,symbols},dataDir:await temp(t),once:true},{captureMarket:async()=>{calls++;},analyzeSymbol:analyze,renderDashboard:render}));assert.equal(calls,0);
 }
});

test('103 no-signal progress updates use bounded durable batches and always flush the final states',async t=>{
 const dataDir=await temp(t),symbols=Array.from({length:103},(_,i)=>'A'+String(i).padStart(3,'0'));
 const store=new ScannerStore(dataDir,{now:()=>T,compactEvery:8,cacheOwnedState:true}),originalCommit=store.commit.bind(store);let commits=0,renders=0,progressUpdates=0;
 store.commit=async value=>{commits++;return originalCommit(value);};
 const result=await runScanner({settings:{...settings,symbols:'all_crypto'},dataDir,once:true},{store,now:()=>T,renderDashboard:s=>{renders++;return render(s);},analyzeSymbol:input=>({...analyze(input),confirmed:[]}),onUpdate:s=>{if(s.status==='scanning'&&s.progress.completed>0)progressUpdates++;},captureMarket:async options=>{
  const universe={status:'ready',symbols};await options.onUniverse({selectedSymbols:symbols,universe});
  const markets=symbols.map(symbol=>market(symbol));
  for(const item of markets)await options.onMarket(item,{symbol:item.symbol,errors:[]});
  return {asOf:T,receivedAt:T,markets,selectedSymbols:symbols,universe,errors:[]};
 }});
 assert.equal(result.status,'ok');assert.equal(result.snapshot.progress.completed,103);assert.equal(progressUpdates,103);
 assert.ok(commits<=15,'large snapshots must be batched');assert.equal(renders,commits);
 const state=await new ScannerStore(dataDir).readState();assert.equal(Object.keys(state.symbols).length,103);assert.equal(state.symbols.A102.visits,1);
 assert.ok((await fs.readFile(join(dataDir,'journal.jsonl'),'utf8')).trim().split('\n').length<8);
});

test('aborting a partially completed universe flushes uncommitted strategy state',async t=>{
 const dataDir=await temp(t),controller=new AbortController(),symbols=['BNB','ADA','0G'];
 const result=await runScanner({settings:{...settings,symbols:'all_crypto'},dataDir,signal:controller.signal,serve:false},{now:()=>T,renderDashboard:render,analyzeSymbol:input=>({...analyze(input),confirmed:[]}),captureMarket:async options=>{
  const universe={status:'ready',symbols};await options.onUniverse({selectedSymbols:symbols,universe});
  const markets=symbols.map(symbol=>market(symbol));
  for(const item of markets)await options.onMarket(item,{symbol:item.symbol,errors:[]});
  controller.abort();return {asOf:T,receivedAt:T,markets,selectedSymbols:symbols,universe,errors:[]};
 }});
 assert.equal(result.status,'stopped');assert.equal(result.snapshot.progress.completed,3);
 const state=await new ScannerStore(dataDir).readState();assert.deepEqual(Object.keys(state.symbols),symbols);assert.equal(state.symbols['0G'].visits,1);
 assert.equal((await new ScannerStore(dataDir).latestSnapshot()).status,'stopped');
});
