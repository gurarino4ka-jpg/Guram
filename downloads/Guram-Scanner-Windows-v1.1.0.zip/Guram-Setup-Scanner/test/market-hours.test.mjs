import test from 'node:test';
import assert from 'node:assert/strict';
import {appendMarketHoursContext} from '../scanner/market-hours.mjs';
import {buildSessionWindows} from '../scanner/strategy/sessions.mjs';
const H=3600000,day=Date.parse('2026-11-02T00:00:00Z');
const bars=Array.from({length:9},(_,i)=>({openTime:day+i*H,closeTime:day+(i+1)*H,open:100+i,high:102+i,low:99+i,close:101+i}));
test('only complete market hours are shown, body and wick remain distinct and do not create signals',()=>{
 const input={symbol:'ETH',status:'watching',price:109.5,confirmed:[],context:{}};
 const r=appendMarketHoursContext(input,{asOf:day+9*H,streams:{'60':bars}}),m=r.context.marketHoursExtremes;
 assert.equal(m.completed.length,1);assert.equal(m.completed[0].name,'tokyo');assert.equal(m.completed[0].bodyHigh,109);assert.equal(m.completed[0].wickHigh,110);
 assert.equal(m.basisRequiresNarrativeReview,true);assert.equal(m.changesTradeTargetsAutomatically,false);assert.deepEqual(r.confirmed,[]);assert.ok(m.nearby.length>0);
 assert.equal(input.context.marketHoursExtremes,undefined);
 assert.equal(appendMarketHoursContext(input,{asOf:day+9*H-1,streams:{'60':bars}}).context.marketHoursExtremes.completed.length,0);
});
test('London and New York have independent DST changes rather than one fixed Moscow offset',()=>{
 const from=Date.parse('2026-03-16T00:00:00Z'),to=from+86400000,windows=buildSessionWindows({from,to});
 assert.equal(new Date(windows.find(w=>w.session==='london').start).getUTCHours(),8);
 assert.equal(new Date(windows.find(w=>w.session==='new-york').start).getUTCHours(),12);
});
