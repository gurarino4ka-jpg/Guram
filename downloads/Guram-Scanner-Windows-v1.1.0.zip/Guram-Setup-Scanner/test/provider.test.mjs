import test from 'node:test';
import assert from 'node:assert/strict';
import {normalizeHistory,deriveWeekly,captureMarket,parseRetryAfter} from '../scanner/provider.mjs';
import {validateConfig} from '../scanner/config.mjs';
const DAY=86400000,T=Date.parse('2026-11-11T18:00:00Z');
function data(times){return {s:'ok',t:times.map(t=>t/1000),o:times.map(()=>100),h:times.map(()=>102),l:times.map(()=>99),c:times.map(()=>101),v:times.map(()=>10)};}
test('crossing a close boundary while receiving never completes the request-start forming candle',()=>{
 const times=[T-900000,T-600000,T-300000,T];
 const r=normalizeHistory(data(times),{symbol:'BTC',timeframe:'5',requestStartedAt:T+299000,receivedAt:T+301000,source:'test'});
 assert.equal(r.forming.length,1);assert.equal(r.forming[0].openTime,T);assert.equal(r.forming[0].frozenForming,true);assert.equal(r.closed.at(-1).closeTime,T);
});
test('a history gap retains provenance and uses only the contiguous suffix',()=>{
 const r=normalizeHistory(data([T-1500000,T-1200000,T-600000,T-300000]),{symbol:'BTC',timeframe:'5',requestStartedAt:T,receivedAt:T+1});
 assert.equal(r.closed.length,2);assert.equal(r.closed[0].openTime,T-600000);assert.ok(r.issues.some(i=>i.code==='history_gap'));
});
for(const [name,mutate] of [['future',d=>d.t.push(T/1000+300)],['duplicate',d=>d.t[1]=d.t[0]],['low above body',d=>d.l[0]=103],['volume mismatch',d=>d.v.pop()]])test('malformed source blocks '+name,()=>{
 const d=data([T-600000,T-300000]);mutate(d);
 assert.throws(()=>normalizeHistory(d,{symbol:'BTC',timeframe:'5',requestStartedAt:T,receivedAt:T+1}));
});
test('W1 is Monday UTC and requires every constituent closed D1 bar',()=>{
 const monday=Date.parse('2026-10-26T00:00:00Z'),daily=Array.from({length:14},(_,i)=>({openTime:monday+i*DAY,closeTime:monday+(i+1)*DAY,open:100,high:110,low:90,close:105,volume:1}));
 const w=deriveWeekly(daily,{asOf:monday+14*DAY});assert.equal(w.bars.length,2);assert.equal(w.bars[0].openTime,monday);assert.equal(w.bars[0].volume,7);
 assert.equal(deriveWeekly(daily.filter((_,i)=>i!==3),{asOf:monday+14*DAY}).bars.length,1);
 assert.equal(deriveWeekly(daily,{asOf:monday+13*DAY}).bars.length,1);
});
test('public capture only performs GET and isolates one failed symbol without importing old data',async()=>{
 let n=T;const calls=[];
 const r=await captureMarket({symbols:['BTC','ETH'],requestSpacingMs:0,now:()=>n++,fetchImpl:async(url,options)=>{
  calls.push({url:String(url),options});const u=new URL(url);if(u.searchParams.get('symbol')==='ETH')return {ok:false,status:503,headers:{get:()=> '120'}};
  const tf=u.searchParams.get('resolution'),p={'5':300000,'15':900000,'30':1800000,'60':3600000,'1D':DAY}[tf],end=Math.floor(T/p)*p;
  return {ok:true,status:200,text:async()=>JSON.stringify(data(Array.from({length:40},(_,i)=>end-(39-i)*p)))};
 }});
 assert.equal(r.markets.length,2);assert.equal(r.markets[0].streams['5'].length,39);assert.equal(r.markets[1].status,'unavailable');assert.equal(r.markets[1].quote,null);
 assert.ok(r.errors.every(e=>e.retryAfterMs===120000));assert.ok(calls.length>5&&calls.length<=10);
 assert.ok(calls.every(({url,options})=>url.startsWith('https://app.bookflow.sh/api/datafeed-api/history?')&&options.method==='GET'&&options.credentials==='omit'&&options.redirect==='error'&&!options.headers.authorization));
});
test('retry-after is bounded and supports seconds and dates',()=>{
 assert.equal(parseRetryAfter('30',T),30000);assert.equal(parseRetryAfter(new Date(T+60000).toUTCString(),T),60000);assert.equal(parseRetryAfter('999999999999',T),3600000);assert.equal(parseRetryAfter('invalid',T),null);
});
test('config accepts balance changes but preserves agreed risk and rejects invalid loop or Codex settings',()=>{
 assert.equal(validateConfig({balanceUSD:5000}).balanceUSD,5000);
 for(const settings of [{riskPercent:2},{minimumRR:1},{maxDailyLossPercent:5},{maximumExtendedRR:10},{pollSeconds:1},{codex:{maxCallsPerDay:0}},{symbols:['BTC','BTC']},{dataDir:''},{unrecognised:true}])assert.throws(()=>validateConfig(settings));
});
