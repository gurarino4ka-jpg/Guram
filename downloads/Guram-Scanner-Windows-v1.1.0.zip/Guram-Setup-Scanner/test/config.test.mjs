import test from 'node:test';
import assert from 'node:assert/strict';
import {DEFAULT_CONFIG,validateConfig} from '../scanner/config.mjs';

test('default universe discovers all crypto with bounded request settings and unchanged model budget',()=>{
 const config=validateConfig();
 assert.equal(config.symbols,'all_crypto');
 assert.equal(config.catalogRefreshSeconds,900);
 assert.equal(config.requestConcurrency,3);
 assert.equal(config.requestSpacingMs,200);
 assert.equal(config.codex.maxCallsPerDay,8);
 assert.equal(DEFAULT_CONFIG.symbols,'all_crypto');
});

test('manual symbols support catalog-shaped uppercase bases without admitting unsafe paths',()=>{
 assert.deepEqual(validateConfig({symbols:['BNB','ADA','0G','1000PEPE']}).symbols,['BNB','ADA','0G','1000PEPE']);
 for(const symbols of [[],['BTC','BTC'],['btc'],['../BTC'],['BTC/USD'],['BTC;echo'],['BTC\n'],['__proto__'],'all',null])assert.throws(()=>validateConfig({symbols}));
});

test('catalog and request configuration rejects unbounded or noninteger values',()=>{
 for(const [key,values] of Object.entries({catalogRefreshSeconds:[0,29,86401,900.5],requestConcurrency:[0,4,1.5],requestSpacingMs:[-1,5001,0.5]}))for(const value of values)assert.throws(()=>validateConfig({[key]:value}));
 assert.equal(validateConfig({requestConcurrency:1,requestSpacingMs:0}).requestSpacingMs,0);
});
