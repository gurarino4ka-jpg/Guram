import test from 'node:test';
import assert from 'node:assert/strict';
import {currentSnapshot} from '../scanner/server.mjs';
const T=Date.parse('2026-11-12T07:00:00Z');
test('a new late-pair update cannot keep an older pair signal fresh',()=>{
 const s={status:'scanning',mode:'live',generatedAt:T,config:{signalFreshnessSeconds:180},symbols:[
  {symbol:'BNB',asOf:T-240000,status:'setups_found',quote:{observedAt:T-240000},confirmed:[{id:'old',availableAt:T-240000}]},
  {symbol:'ADA',asOf:T,status:'setups_found',quote:{observedAt:T},confirmed:[{id:'new',availableAt:T}]}]};
 const c=currentSnapshot(s,{now:T});assert.equal(c.symbols[0].status,'stale');assert.equal(c.symbols[0].confirmed.length,0);assert.equal(c.symbols[1].confirmed.length,1);assert.equal(c.confirmedCount,1);assert.equal(s.symbols[0].confirmed.length,1);
});
test('a fresh price does not extend the lifetime of its old structure confirmation',()=>{
 const s={status:'ok',mode:'live',generatedAt:T,config:{signalFreshnessSeconds:180},symbols:[{symbol:'0G',asOf:T,status:'setups_found',quote:{observedAt:T},confirmed:[{id:'old',availableAt:T-181000}]}]};
 const c=currentSnapshot(s,{now:T});assert.equal(c.confirmedCount,0);assert.equal(c.symbols[0].status,'watching');assert.equal(c.symbols[0].watch.at(-1).code,'signal_expired');
});
test('pairs not yet scanned are never presented with prior confirmed entries',()=>{
 const c=currentSnapshot({status:'scanning',mode:'live',generatedAt:T,symbols:[{symbol:'DOGE',status:'pending',asOf:T,confirmed:[{id:'not-scanned',availableAt:T}]}]},{now:T});
 assert.equal(c.symbols[0].confirmed.length,0);
});
