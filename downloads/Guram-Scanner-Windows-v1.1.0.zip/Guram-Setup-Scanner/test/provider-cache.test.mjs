import test from 'node:test';
import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import {createPublicMarketProvider} from '../scanner/provider.mjs';

const T=Date.parse('2026-11-12T12:01:00Z');
const PERIODS={'5':300000,'15':900000,'30':1800000,'60':3600000,'1D':86400000};
const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const deferred=()=>{let resolve;const promise=new Promise(r=>{resolve=r;});return {promise,resolve};};
function candles(timeframe,at,price=101){
 const p=PERIODS[timeframe],end=Math.floor(at/p)*p,t=Array.from({length:40},(_,i)=>(end-(39-i)*p)/1000);
 return {s:'ok',t,o:t.map(()=>100),h:t.map(()=>Math.max(102,price)),l:t.map(()=>99),c:t.map(()=>price),v:t.map(()=>10)};
}
const json=value=>({ok:true,status:200,text:async()=>JSON.stringify(value)});
function descriptor(symbol){return {id:`id-${symbol}`,config:{category:'crypto',type:'base',baseAsset:symbol,quoteAsset:'USD',settlementToken:'USD',name:`${symbol}/USD`,ticker:`${symbol}/USDT`},settings:{isClosed:false,isPaused:false,isCloseOnly:false}};}
function recorder(clock,{beforeResponse=async()=>{},price=()=>101}={}){
 const calls=[];
 const fetchImpl=async url=>{
  const u=new URL(url),call={symbol:u.searchParams.get('symbol'),timeframe:u.searchParams.get('resolution'),at:clock(),wall:performance.now()};calls.push(call);
  await beforeResponse(call);
  return json(candles(call.timeframe,clock(),price(call)));
 };
 return {calls,fetchImpl};
}
const higherHashes=market=>market.sourceHashes.filter(h=>h.timeframe!=='5');

test('a provider instance caches higher streams and preserves their exact frozen observations while fetching M5 each cycle',async()=>{
 let clock=T,quote=101;
 const recorded=recorder(()=>clock,{price:call=>call.timeframe==='5'?quote:101});
 const provider=createPublicMarketProvider({symbols:['BTC'],now:()=>clock,fetchImpl:recorded.fetchImpl,requestSpacingMs:0});
 const first=(await provider.captureMarket()).markets[0];
 assert.deepEqual(recorded.calls.map(c=>c.timeframe),['60','1D','30','15','5']);
 assert.equal(first.forming['60'].observedAt,T);
 const provenance=structuredClone(higherHashes(first));
 const originalForming=structuredClone(first.forming['60']);
 clock+=60000;quote=102;
 const progress=[];
 const second=(await provider.captureMarket({onProgress:event=>progress.push(event)})).markets[0];
 assert.deepEqual(recorded.calls.slice(5).map(c=>c.timeframe),['5']);
 assert.deepEqual(higherHashes(second),provenance);
 assert.deepEqual(second.forming['60'],originalForming);
 assert.equal(second.forming['60'].frozenForming,true);
 assert.equal(second.quote.observedAt,clock);
 assert.equal(second.quote.price,102);
 assert.ok(progress.filter(p=>p.timeframe!=='5').every(p=>p.cached));
 assert.equal(progress.find(p=>p.timeframe==='5').cached,false);
 // A caller changing a returned object cannot alter the cached evidence.
 second.forming['60'].observedAt=0;
 second.streams['60'][0].close=999;
 second.sourceHashes.find(h=>h.timeframe==='60').observedAt=0;
 clock+=1000;
 const third=(await provider.captureMarket()).markets[0];
 assert.deepEqual(higherHashes(third),provenance);
 assert.deepEqual(third.forming['60'],originalForming);
 assert.equal(third.streams['60'][0].close,101);
});

test('cached M15 and H1 records are refetched at their own next boundaries without retiming D1',async()=>{
 let clock=Date.parse('2026-11-12T12:14:59Z');
 const recorded=recorder(()=>clock);
 const provider=createPublicMarketProvider({symbols:['BTC'],now:()=>clock,fetchImpl:recorded.fetchImpl,requestSpacingMs:0});
 const first=(await provider.captureMarket()).markets[0];
 clock=Date.parse('2026-11-12T12:15:01Z');
 const second=(await provider.captureMarket()).markets[0];
 assert.deepEqual(recorded.calls.slice(5).map(c=>c.timeframe),['15','5']);
 assert.equal(second.streams['15'].at(-1).closeTime,Date.parse('2026-11-12T12:15:00Z'));
 assert.equal(second.forming['60'].observedAt,first.forming['60'].observedAt);
 const dailyHash=structuredClone(first.sourceHashes.find(h=>h.timeframe==='1D'));
 const beforeHour=recorded.calls.length;
 clock=Date.parse('2026-11-12T13:00:01Z');
 const third=(await provider.captureMarket()).markets[0];
 assert.deepEqual(recorded.calls.slice(beforeHour).map(c=>c.timeframe),['60','30','15','5']);
 assert.equal(third.streams['60'].at(-1).closeTime,Date.parse('2026-11-12T13:00:00Z'));
 assert.equal(third.forming['60'].observedAt,clock);
 assert.deepEqual(third.sourceHashes.find(h=>h.timeframe==='1D'),dailyHash);
 assert.equal(first.forming['60'].frozenForming,true);
 assert.equal(first.forming['60'].observedAt,Date.parse('2026-11-12T12:14:59Z'));
});

test('a higher-stream boundary crossed by the M5 response is refreshed before the symbol is delivered',async()=>{
 let clock=Date.parse('2026-11-12T12:59:59Z'),crossed=false;
 const calls=[];
 const provider=createPublicMarketProvider({symbols:['BTC'],now:()=>clock,requestSpacingMs:0,requestConcurrency:1,fetchImpl:async url=>{
  const u=new URL(url),timeframe=u.searchParams.get('resolution'),requestAt=Number(u.searchParams.get('to'))*1000;
  calls.push(timeframe);const body=candles(timeframe,requestAt);
  if(timeframe==='5'&&!crossed){clock=Date.parse('2026-11-12T13:00:01Z');crossed=true;}
  return json(body);
 }});
 const result=await provider.captureMarket();
 const market=result.markets[0];
 assert.deepEqual(calls,['60','1D','30','15','5','60','30','15','5']);
 assert.equal(market.streams['60'].at(-1).closeTime,Date.parse('2026-11-12T13:00:00Z'));
 assert.equal(market.forming['60'].observedAt,clock);
 assert.equal(market.forming['1D'].observedAt,Date.parse('2026-11-12T12:59:59Z'));
 assert.equal(market.quote.observedAt,clock);
 assert.equal(market.asOf,clock);
});

test('onMarket receives a complete symbol immediately with its own asOf before a slower symbol finishes',async()=>{
 let clock=T,finished=false;
 const ethM5=deferred(),firstCallback=deferred(),callbacks=[];
 const recorded=recorder(()=>clock,{beforeResponse:async call=>{if(call.symbol==='ETH'&&call.timeframe==='5')await ethM5.promise;}});
 const provider=createPublicMarketProvider({symbols:['BTC','ETH'],now:()=>clock,fetchImpl:recorded.fetchImpl,requestSpacingMs:0,requestConcurrency:2});
 const pending=provider.captureMarket({onMarket:(market,progress)=>{
  callbacks.push({market,progress,finished});
  if(market.symbol==='BTC')firstCallback.resolve();
 }}).then(result=>{finished=true;return result;});
 await firstCallback.promise;
 assert.equal(finished,false);
 assert.equal(callbacks.length,1);
 assert.equal(callbacks[0].market.symbol,'BTC');
 assert.equal(callbacks[0].market.asOf,T);
 assert.equal(callbacks[0].market.asOf-callbacks[0].market.quote.observedAt,0);
 assert.equal(callbacks[0].progress.completed,1);
 assert.equal(callbacks[0].progress.total,2);
 clock+=60000;ethM5.resolve();
 const result=await pending;
 assert.equal(callbacks.length,2);
 assert.ok(result.markets.find(m=>m.symbol==='BTC').asOf<result.asOf);
 assert.equal(result.markets.find(m=>m.symbol==='BTC').asOf,T);
 assert.equal(result.markets.find(m=>m.symbol==='ETH').asOf,clock);
 for(const symbol of ['BTC','ETH'])assert.deepEqual(recorded.calls.filter(c=>c.symbol===symbol).map(c=>c.timeframe),['60','1D','30','15','5']);
});

test('actual HTTP requests obey both concurrency and spacing limits',async()=>{
 let active=0,maxActive=0;
 const recorded=recorder(()=>T,{beforeResponse:async()=>{active++;maxActive=Math.max(maxActive,active);await wait(20);active--;}});
 const provider=createPublicMarketProvider({symbols:['BTC','ETH','SOL','ZEC','0G'],now:()=>T,fetchImpl:recorded.fetchImpl,requestSpacingMs:10,requestConcurrency:3});
 const result=await provider.captureMarket();
 assert.equal(result.markets.length,5);
 assert.equal(recorded.calls.length,25);
 assert.ok(maxActive>=2&&maxActive<=3,`maximum active requests was ${maxActive}`);
 for(let i=1;i<recorded.calls.length;i++)assert.ok(recorded.calls[i].wall-recorded.calls[i-1].wall>=8,`request ${i} started less than the configured spacing after its predecessor`);
 for(const symbol of result.selectedSymbols)assert.equal(recorded.calls.filter(c=>c.symbol===symbol).at(-1).timeframe,'5');
});

test('a 429 stops queued requests, keeps the global cooldown across captures and rotates the next starting symbol',async()=>{
 let clock=T,limited=true;
 const calls=[];
 const provider=createPublicMarketProvider({symbols:['BTC','ETH','SOL','ZEC'],now:()=>clock,requestSpacingMs:0,requestConcurrency:1,fetchImpl:async url=>{
  const u=new URL(url),symbol=u.searchParams.get('symbol'),tf=u.searchParams.get('resolution');calls.push({symbol,tf});
  if(limited)return {ok:false,status:429,headers:{get:()=> '30'}};
  return json(candles(tf,clock));
 }});
 const first=await provider.captureMarket();
 assert.equal(calls.length,1);
 assert.equal(calls[0].symbol,'BTC');
 assert.equal(first.cooldownUntil,T+30000);
 assert.ok(first.markets.every(m=>m.status==='unavailable'&&m.quote===null));
 assert.ok(first.errors.some(e=>e.status===429&&e.retryAfterMs===30000));
 await provider.captureMarket();
 assert.equal(calls.length,1);
 limited=false;clock=T+30001;
 const resumed=await provider.captureMarket();
 assert.equal(calls[1].symbol,'ETH');
 assert.ok(resumed.markets.every(m=>m.quote!==null));
 assert.equal(resumed.errors.length,0);
});

test('in-flight workers stop submitting further timeframes after another worker reports a 429',async()=>{
 const calls=[],slow=deferred();
 const provider=createPublicMarketProvider({symbols:['BTC','ETH','SOL','ZEC','0G'],now:()=>T,requestSpacingMs:0,requestConcurrency:3,fetchImpl:async url=>{
  const u=new URL(url),symbol=u.searchParams.get('symbol'),tf=u.searchParams.get('resolution');calls.push({symbol,tf});
  if(symbol==='BTC')return {ok:false,status:429,headers:{get:()=> '60'}};
  await slow.promise;return json(candles(tf,T));
 }});
 const pending=provider.captureMarket();
 // Let the initial starts and the 429 response reach their await continuations.
 await Promise.resolve();await Promise.resolve();await Promise.resolve();await Promise.resolve();
 slow.resolve();
 const result=await pending;
 assert.ok(calls.length<=3);
 assert.ok(calls.every(c=>c.tf==='60'));
 assert.equal(result.markets.length,5);
 assert.ok(result.markets.every(m=>m.status==='unavailable'));
});

test('catalog TTL discovers additions and removals and a failed refresh blocks capture without using stale symbols',async()=>{
 let clock=T,rows=[descriptor('BTC'),descriptor('ETH')],catalogFailure=false;
 const calls=[],universes=[];
 const provider=createPublicMarketProvider({symbols:'all_crypto',catalogRefreshSeconds:900,now:()=>clock,requestSpacingMs:0,requestConcurrency:1,fetchImpl:async url=>{
  const u=new URL(url);calls.push({path:u.pathname,symbol:u.searchParams.get('symbol')});
  if(u.pathname==='/api/v2/markets')return catalogFailure?{ok:false,status:503,headers:{get:()=>null}}:json(rows);
  return json(candles(u.searchParams.get('resolution'),clock));
 }});
 const first=await provider.captureMarket({onUniverse:u=>universes.push(u)});
 assert.deepEqual(first.selectedSymbols,['BTC','ETH']);
 assert.equal(first.universe.cacheHit,false);
 assert.equal(first.markets[0].definition.id,'id-BTC');
 assert.deepEqual(universes[0].selectedSymbols,['BTC','ETH']);
 rows=[descriptor('ETH'),descriptor('NEWPAIR')];clock=T+899000;
 const cached=await provider.captureMarket();
 assert.deepEqual(cached.selectedSymbols,['BTC','ETH']);
 assert.equal(cached.universe.cacheHit,true);
 assert.equal(calls.filter(c=>c.path==='/api/v2/markets').length,1);
 clock=T+900000;
 const beforeRefresh=calls.length;
 const refreshed=await provider.captureMarket();
 assert.deepEqual(refreshed.selectedSymbols,['ETH','NEWPAIR']);
 assert.equal(refreshed.universe.cacheHit,false);
 assert.equal(calls.filter(c=>c.path==='/api/v2/markets').length,2);
 assert.ok(calls.slice(beforeRefresh).filter(c=>c.symbol).every(c=>c.symbol!=='BTC'));
 assert.equal(refreshed.markets.find(m=>m.symbol==='NEWPAIR').definition.name,'NEWPAIR/USD');
 catalogFailure=true;clock+=900000;
 const beforeFailure=calls.length;
 const failed=await provider.captureMarket();
 assert.deepEqual(failed.selectedSymbols,[]);
 assert.deepEqual(failed.markets,[]);
 assert.equal(failed.universe.status,'unavailable');
 assert.ok(failed.errors.some(e=>e.status===503));
 assert.equal(calls.length,beforeFailure+1);
});

test('a changed source market ID invalidates every cached stream for the same symbol',async()=>{
 let clock=T,row=descriptor('BTC');
 const calls=[];
 const provider=createPublicMarketProvider({symbols:'all_crypto',now:()=>clock,requestSpacingMs:0,requestConcurrency:1,fetchImpl:async url=>{
  const u=new URL(url);
  if(u.pathname==='/api/v2/markets')return json([row]);
  const timeframe=u.searchParams.get('resolution');calls.push(timeframe);
  return json(candles(timeframe,clock));
 }});
 await provider.captureMarket();
 row={...row,id:'replacement-BTC'};clock+=900000;
 const result=await provider.captureMarket();
 assert.deepEqual(calls.slice(5),['60','1D','30','15','5']);
 assert.equal(result.markets[0].definition.id,'replacement-BTC');
 assert.equal(result.markets[0].forming['60'].observedAt,clock);
});
