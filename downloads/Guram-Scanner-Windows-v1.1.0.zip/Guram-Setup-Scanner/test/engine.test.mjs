import test from 'node:test';
import assert from 'node:assert/strict';
import {analyzeSymbol,analyzeMarket,analyzeScale,observeSweeps,planLevels,fvgTraversal,targetsFor,recoveryRatio} from '../scanner/engine.mjs';
import {detectBodyFractals,detectStructureBreaks} from '../scanner/strategy/structure.mjs';
import {fixture,reflect,flatFixture} from '../examples/demo-fixtures.mjs';
const H=3600000;
const bar=(i,o,h,l,c,p=H)=>({openTime:i*p,closeTime:(i+1)*p,open:o,high:h,low:l,close:c});
const routes=[[178,'sweep_m30','short'],[6665,'fvg_midpoint_m5','long'],[6852,'fvg_m30','long'],[9127,'h1_only','long'],[3843,'fvg_retest_m5','short']];
test('expanded crypto codes use the same strategy while unsafe symbols fail validation',()=>{
 for(const symbol of ['BNB','ADA','0G','1000PEPE']){
  const input=fixture(178);input.symbol=symbol;const report=analyzeSymbol(input);
  assert.equal(report.symbol,symbol);assert.notEqual(report.status,'data_error');assert.ok(report.confirmed.some(signal=>signal.symbol===symbol&&signal.route==='sweep_m30'));
 }
 for(const symbol of ['../BTC','BTC/USD','btc','BTC;echo','__proto__']){const input=fixture(178);input.symbol=symbol;assert.equal(analyzeSymbol(input).status,'data_error');}
});
for(const [seed,route,side] of routes)for(const mirrored of [false,true])test(`${route} full coherent ${mirrored?'mirrored ':''}OHLC route`,()=>{
 const input=mirrored?reflect(fixture(seed)):fixture(seed),before=structuredClone(input),result=analyzeSymbol(input),c=result.confirmed.find(c=>c.route===route);
 assert.deepEqual(result.issues,[]);assert.ok(c,JSON.stringify(result.rejected.map(c=>c.reasons)));
 assert.equal(c.side,mirrored?(side==='long'?'short':'long'):side);assert.ok(c.rr>=2);assert.equal(c.ordersSubmitted,0);assert.equal(c.executionEnabled,false);
 assert.equal(c.break.bodyCloseBeyondLevel,true);assert.ok(c.break.reference.availableAt<c.break.availableAt);
 assert.equal(c.requiresHumanNarrativeReview,true);assert.equal(result.context.discretionaryNarrativeAutomated,false);
 assert.equal(c.confirmedAt,input.asOf);assert.ok(c.quoteObservedAt<=input.asOf);
 const reaction=c.evidence.reaction||c.evidence.retest;if(reaction)assert.ok(reaction.closeTime<c.confirmedAt);
 assert.deepEqual(input,before,'pure engine does not mutate capture');
});
test('strict five-bar wick fractal only becomes available at fifth close and marks central body',()=>{
 const bars=[bar(0,100,103,98,101),bar(1,101,104,99,102),bar(2,101,110,97,103),bar(3,102,105,99,103),bar(4,102,104,98,103)];
 assert.equal(detectBodyFractals(bars,{asOf:5*H-1}).events.length,0);
 const high=detectBodyFractals(bars,{asOf:5*H}).events.find(p=>p.type==='high');assert.equal(high.price,103);assert.equal(high.rawHigh,110);assert.equal(high.availableAt,5*H);
 const tied=structuredClone(bars);tied[0].high=110;assert.equal(detectBodyFractals(tied,{asOf:5*H}).events.some(p=>p.type==='high'),false);
 const forming=structuredClone(bars);forming[4].formingObservation=true;assert.equal(detectBodyFractals(forming,{asOf:5*H}).events.length,0);
});
test('a wick is no structure break; close crosses body, not wick tip',()=>{
 const bars=[bar(0,100,103,98,101),bar(1,101,104,99,102),bar(2,101,110,97,103),bar(3,102,105,99,103),bar(4,102,104,98,103),bar(5,102,112,100,103),bar(6,103,106,101,104)];
 const events=detectStructureBreaks(bars,{asOf:7*H}).events;assert.equal(events.length,1);assert.equal(events[0].availableAt,7*H);assert.equal(events[0].referencePrice,103);
});
test('fresh quote and fresh confirmation are independent gates',()=>{
 const f=fixture(178);const stale=structuredClone(f);stale.quote.observedAt-=120001;assert.equal(analyzeSymbol(stale).status,'data_error');
 const future=structuredClone(f);future.quote.observedAt++;assert.equal(analyzeSymbol(future).status,'data_error');
 const late=structuredClone(f);late.asOf+=180001;late.quote.observedAt=late.asOf;assert.equal(analyzeSymbol(late).confirmed.length,0);
 const missing=structuredClone(f);delete missing.quote;assert.equal(analyzeSymbol(missing).status,'data_error');
});
test('future completed bars and forming fifth candles do not add structural evidence',()=>{
 const f=fixture(178),original=analyzeSymbol(f);for(const tf of ['5','30','60']){const p=Number(tf)*60000,last=f.streams[tf].at(-1);f.streams[tf].push({...last,openTime:last.closeTime,closeTime:last.closeTime+p,high:last.high*2,close:last.close*1.5});}
 const r=analyzeSymbol(f);assert.deepEqual(r.context.h1,original.context.h1);assert.deepEqual(r.confirmed.map(c=>c.id),original.confirmed.map(c=>c.id));
});
test('H1 direction and outer range persist across intrabar sweeps and newly observed minor fractals',()=>{
 const f=fixture(178),r=analyzeSymbol(f);f.previousState=r.nextState;f.forming['5']={...f.streams['5'].at(-1),openTime:f.asOf,closeTime:f.asOf+300000,high:10000,low:100,observedAt:f.asOf};
 const next=analyzeSymbol(f);assert.equal(next.direction,r.direction);assert.deepEqual(next.context.h1.range,r.context.h1.range);
 const first=analyzeScale(f.streams['60'].slice(0,-1),{timeframe:'60',asOf:f.asOf});
 const previous={geometry:first.geometry,direction:'up',lastClosedAt:first.lastClosedAt,range:{upper:{price:1e6},lower:{price:1}}};
 const current=analyzeScale(f.streams['60'],{timeframe:'60',asOf:f.asOf,previous});assert.equal(current.direction,'up');assert.deepEqual(current.range,previous.range);
});
test('first observable sweep remains consumed across restart and truncated M5 history',()=>{
 const pool={id:'p',type:'high',price:100,rawHigh:110,rawLow:90,availableAt:5*H};
 const early=bar(5,100,106,99,102),later=bar(6,102,120,100,110);
 const a=observeSweeps([pool],{h1:[early,later],m5:[],asOf:7*H});assert.equal(a.events[0].availableAt,6*H);assert.equal(a.events[0].kind,'half-wick');
 const b=observeSweeps([pool],{h1:[later],m5:[],previousSweeps:a.state,asOf:7*H});assert.equal(b.events[0].availableAt,6*H);
 const live=observeSweeps([pool],{h1:[],m5:[],forming5:{...bar(60,100,106,99,103,300000),observedAt:5*H+1},asOf:5*H});assert.equal(live.events.length,0);
 const f=fixture(178),r=analyzeSymbol(f);assert.ok(r.nextState.usedSweepIds.length);assert.equal(analyzeSymbol({...f,previousState:r.nextState}).confirmed.some(c=>c.route==='sweep_m30'),false);
});
test('deeper FVG needs the nearer zone fully crossed by an M30 close',()=>{
 const deep={id:'deep',direction:'bullish',lower:90,upper:95,status:'active',availableAt:0},near={id:'near',direction:'bullish',lower:100,upper:105,status:'active',availableAt:0};
 const wick=bar(0,103,106,98,102,1800000);assert.equal(fvgTraversal(deep,[deep,near],[wick],1800000).allowed,false);
 const crossed={...wick,close:99};const yes=fvgTraversal(deep,[deep,near],[crossed],1800000);assert.equal(yes.allowed,true);assert.equal(yes.passed[0].acceptedAt,1800000);
 assert.equal(fvgTraversal(deep,[deep,near],[crossed],1799999).allowed,false);
 const mirror=z=>({...z,direction:'bearish',lower:200-z.upper,upper:200-z.lower});assert.equal(fvgTraversal(mirror(deep),[mirror(deep),mirror(near)],[{...crossed,open:97,close:101,high:102,low:94}],1800000).allowed,true);
});
test('inside-FVG stop adds 10 percent; outside-FVG stop uses H1 wick midpoint without reserve',()=>{
 const z={id:'z',lower:90,upper:110,status:'active'},p={id:'low',type:'low',price:85,rawLow:75,availableAt:0},target={id:'t',kind:'liquidity_pool',price:150,availableAt:0};
 const inside=planLevels({side:'long',entry:100,zone:z,h1Fractals:[p],targets:[target],asOf:1});assert.equal(inside.stopLoss,89);assert.equal(inside.stopReference.reservePercent,10);assert.ok(inside.actualIndicativeRiskUSD<=100);
 const outside=planLevels({side:'long',entry:120,zone:z,h1Fractals:[p],targets:[{...target,price:240}],asOf:1});assert.equal(outside.stopLoss,80);assert.equal(outside.stopReference.reservePercent,0);
 const short=planLevels({side:'short',entry:100,zone:z,h1Fractals:[],targets:[{...target,price:50}],asOf:1});assert.equal(short.stopLoss,111);
});
test('active nearest FVG blocks attractive farther RR; touching is not H1 acceptance',()=>{
 const zone={id:'entry',lower:90,upper:110,status:'active'},near={id:'barrier',kind:'fvg',price:115,availableAt:0},far={id:'far',kind:'liquidity_pool',price:140,availableAt:0};
 const r=planLevels({side:'long',entry:100,zone,targets:[far,near],asOf:1});assert.equal(r.status,'rejected');assert.equal(r.reasons[0].code,'unpassed_FVG_blocks_RR_extension');assert.equal(r.nearestTarget.id,'barrier');
 const ts=targetsFor('long',100,[],[{id:'z',lower:115,upper:120,status:'active',availableAt:0}],[],null);assert.equal(ts[0].price,115);
 const distant=planLevels({side:'long',entry:100,zone,targets:[{...far,price:180}],asOf:1});assert.equal(distant.status,'planned');assert.ok(distant.rr>4,'nearest real target itself above 4R remains allowed');
});
test('M30 close through a bullish protective edge cancels its ordinary long idea',()=>{
 const f=fixture(6852),base=analyzeSymbol(f),zone=base.confirmed.find(c=>c.route==='fvg_m30').zone;
 // Change an already closed M30 price, preserving its native H1 aggregate.
 const b=f.streams['30'].find(b=>b.openTime>=zone.availableAt&&b.closeTime<f.asOf);b.close=zone.lower-1;b.low=Math.min(b.low,b.close);
 const h=f.streams['60'].find(h=>h.openTime<=b.openTime&&h.closeTime>=b.closeTime),parts=f.streams['30'].filter(x=>x.openTime>=h.openTime&&x.closeTime<=h.closeTime);
 Object.assign(h,{open:parts[0].open,close:parts.at(-1).close,high:Math.max(...parts.map(x=>x.high)),low:Math.min(...parts.map(x=>x.low))});
 const r=analyzeSymbol(f);assert.notEqual(r.status,'data_error');assert.equal(r.confirmed.some(c=>c.zone?.id===zone.id&&c.side==='long'&&c.route!=='fvg_retest_m5'),false);
});
test('demo capture has one illustrative setup and three watching markets, all with zero orders',()=>{
 const capture={asOf:fixture(178).asOf,markets:[fixture(178),flatFixture('BTC',104000),flatFixture('SOL',180),flatFixture('ZEC',400)]};const r=analyzeMarket(capture);assert.equal(r.confirmed.length,1);assert.equal(r.markets.filter(m=>m.status==='watching').length,3);assert.equal(r.ordersSubmitted,0);
});

test('a zero adverse wick cannot manufacture midpoint recovery',()=>{assert.equal(recoveryRatio('long',{open:100,low:100,high:110,close:109}),0);assert.equal(recoveryRatio('short',{open:110,low:100,high:110,close:101}),0);assert.ok(recoveryRatio('long',{open:105,low:100,high:110,close:108})>=.5);});

test('inversion does not reuse an old retest after price reclaims the original zone',()=>{const r=analyzeSymbol(fixture(10179));assert.equal(r.confirmed.some(c=>c.route==='fvg_retest_m5'),false);});
